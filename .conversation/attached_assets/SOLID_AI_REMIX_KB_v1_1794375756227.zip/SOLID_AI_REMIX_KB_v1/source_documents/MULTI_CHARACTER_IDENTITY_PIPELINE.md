# Multi-character identity pipeline

## Diagnosis

`repair_video_identity_lora.py` used SDXL inpainting independently on every video frame, changed the random seed on every frame, started at denoise 0.80, and accepted identity similarity down to 0.15. That architecture produces a freshly sampled face every 1/24 second, so the output looks like facial stop motion even though the MP4 is correctly encoded at 24 fps.

The Sarah SDXL LoRA itself is not a temporal/video model. The selected production checkpoint is checkpoint 20, not the final checkpoint. Training consumed 1500 x batch 2 image exposures over 58 unique images (about 52 effective passes), so future characters should stop much earlier and select a checkpoint using held-out identity and pose tests.

## Production architecture

1. MiniMax owns performance, body motion, camera, environment, props, speech, and lipsync.
2. Face detection and tracking create one continuous face track per named character.
3. A character registry resolves the selected character to reference images, consensus InsightFace embedding, optional SDXL LoRA, trigger token, voice model, and thresholds.
4. InstantID + the selected character LoRA operate only on sparse identity anchor frames, not every frame. InstantID supplies reference identity; LoRA supplies learned character appearance. Neither is the temporal layer.
5. Identity residuals from anchor frames are propagated between anchors with optical flow/feature tracking. Mouth interiors and eyelids stay sourced from MiniMax to preserve speech and expression.
6. A segment-level gate checks identity similarity, landmark continuity, face-track continuity, and frame-to-frame perceptual delta. Failed segments fall back to the original MiniMax track or conservative InsightFace repair; they are never accepted frame-by-frame merely because a face was detected.
7. Exact UI/logo compositing runs after identity repair.

## Character package

Each character should be selectable through one manifest with:

- `id`, `display_name`, and `trigger_token`
- RVC model/index and voice reference
- 5-12 clean identity references covering front, 3/4, profile, expression, and lighting
- consensus face embedding
- optional SDXL LoRA path and compatible base checkpoint
- InstantID identity strength and LoRA strength
- identity threshold and temporal continuity threshold

The pipeline code remains generic; adding a character adds a package, not a new workflow.

## Defaults for a 16 GB GPU

- SDXL identity LoRA: rank 16-32, UNet only, 1024 buckets, batch 1-2, bf16, gradient checkpointing, cached latents/text outputs.
- Target 400-700 steps for roughly 14-24 effective passes across 58 unique images; save every 100 steps and select on held-out poses. Do not assume the final checkpoint is best.
- Anchor repair: every 8-16 frames, denoise 0.25-0.40, fixed seed per shot, LoRA 0.55-0.75, InstantID as identity reference conditioning.
- Temporal propagation between anchors; never independent diffusion on all 24 frames per second.
- Preserve mouth region for talking heads and reject tiny faces rather than hallucinating detail.

## Current safe state

The experimental LoRA worker now defaults to a fixed seed, denoise 0.38, fallback denoise 0.30/0.22, blend 0.78, and minimum identity similarity 0.32. This reduces random identity jumps but is still an image-per-frame experiment. It should not become the production identity stage until sparse anchors plus temporal propagation are implemented and pass backtests.

InstantID is not currently installed in this ComfyUI tree. Installing it is useful, but it must be integrated as the anchor identity conditioner described above; replacing LoRA inpainting with per-frame InstantID would reproduce the same temporal class of failure.