# MASTER KB INDEX — SOLID AI REMIX
Versi: 1.0 | Status: Konsolidasi awal | Penggunaan: Internal

## Tujuan
Menjadi indeks pusat bagi AI SOLID AI Remix untuk menemukan sumber, memahami status validasi, dan memilih informasi sesuai mode penggunaan.

## Modul pengetahuan
1. Company & Governance — profil, identitas, legalitas, kontak resmi, struktur tata kelola.
2. Product — Mikro, Mini, Regular; kontrak, biaya, margin, jam, ketentuan dan batas akun.
3. Trading Education — istilah, order, mekanisme, risiko, edukasi pasar.
4. Customer Service & App — registrasi, KYC, funding, withdrawal, login, OTP, troubleshooting.
5. Regulatory & Compliance — peraturan berlaku, rancangan, telaah, SOP, APU-PPT, perlindungan data.
6. Business & Strategy — blueprint, strategi digital, peran akun dan operasional internal.
7. Brand & Content — identitas visual, tone, content pillar, CTA, storytelling.
8. AI Video Engine — prompt, image-to-video, konsistensi karakter, kamera, gerakan, kualitas.

## Sumber yang tersedia
- 58 node Markdown lama di `knowledge/source_nodes/`.
- Dokumen spesifikasi Mini Mikro, FAQ CS v4, Tabel Spesifikasi Mini.
- DARVIS_NODE_SolidGroup.md.
- Strategi TikTok 2026 dan SOLID Prime Blueprint.
- Rancangan peraturan penerimaan nasabah online, ringkasan, dan telaah manajemen.
- MULTI_CHARACTER_IDENTITY_PIPELINE.md.

## Aturan retrieval
- Cari di sumber terstruktur terlebih dahulu, lalu tampilkan sumber dan versi.
- Untuk angka produk gunakan Product Facts Master yang disetujui admin; jangan menyimpulkan dari FAQ naratif jika ada konflik.
- Jika sumber tidak ditemukan, jawab bahwa data belum tersedia dan minta eskalasi.
- Jika sumber berbeda, ikuti `governance/02_CONFLICT_REGISTER.md` hanya untuk konflik yang telah diputuskan. Konflik lain harus ditahan.
- Simpan metadata: source_id, nama dokumen, tanggal dokumen (jika ada), tanggal unggah, versi, status, klasifikasi akses, dan pemilik/approver bila diketahui.
