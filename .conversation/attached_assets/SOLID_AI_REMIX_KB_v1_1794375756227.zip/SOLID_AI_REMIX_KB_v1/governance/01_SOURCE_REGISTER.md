# SOURCE REGISTER — SOLID AI REMIX
Versi 1.0 | Status: Inventarisasi awal

| Source ID | Dokumen/sumber | Kelompok | Status penggunaan |
|---|---|---|---|
| SRC-001 | 58 node Markdown dalam knowledge-solid-gold.zip | Company, product, education, CS, app, legal | Sumber awal; cek versi dan konsistensi per node |
| SRC-002 | Spesifikasi Mini Mikro.docx | Product Mini/Mikro | Acuan yang dipilih pengguna untuk empat parameter konflik; tetap perlu kontrol versi resmi |
| SRC-003 | FAQ WhatsApp CS Solid Prime Mini Account v4 | CS dan operasional Mini | Referensi operasional; angka yang konflik dengan SRC-002 tidak menjadi acuan untuk empat parameter yang diputuskan |
| SRC-004 | Tabel Spesifikasi Mini.pdf | Product Mini | Pembanding; cek kesesuaian dengan product master aktif |
| SRC-005 | DARVIS_NODE_SolidGroup.md | Company/governance | Referensi konteks publik dan governance; tidak otomatis sumber operasional |
| SRC-006 | Solid_Ecosystem_TikTok_Strategy_2026.pptx | Strategy/content | Referensi strategi internal; bukan fakta produk atau aturan resmi |
| SRC-007 | SOLID_Prime_blue_print.pptx | Business/operating model | Referensi internal; batasi akses berdasarkan role |
| SRC-008 | Rancangan Peraturan Bappebti tentang Penerimaan Nasabah Online, 30 Sep 2026 | Regulatory | RANCANGAN; bukan aturan berlaku kecuali statusnya diverifikasi kemudian |
| SRC-009 | Ringkasan Lengkap Rancangan Peraturan Penerimaan Nasabah Online | Regulatory | Ringkasan sekunder; verifikasi ke naskah resmi |
| SRC-010 | Telaah Regulasi Penerimaan Nasabah Online untuk Manajemen | Regulatory/internal analysis | Analisis internal; bukan sumber hukum primer |
| SRC-011 | MULTI_CHARACTER_IDENTITY_PIPELINE.md | AI video engineering | Proposal teknis/eksperimental; wajib diuji sebelum produksi |

## Catatan
Tanggal unggah dokumen tidak sama dengan tanggal berlaku. Replit harus mempertahankan tanggal/versi yang tertulis di dalam dokumen dan tidak mengarang tanggal efektif.
