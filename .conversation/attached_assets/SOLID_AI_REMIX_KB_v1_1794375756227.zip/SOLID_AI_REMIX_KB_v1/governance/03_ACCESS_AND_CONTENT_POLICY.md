# ACCESS & CONTENT POLICY
Versi 1.0 | Aplikasi internal

## Mode aplikasi
1. INTERNAL MODE: analisis, ringkasan, draft edukasi internal, simulasi, dan pencarian dokumen internal. Akses sesuai role.
2. PUBLIC CONTENT MODE: menyusun naskah/prompt untuk konten yang mungkin dipublikasikan. Hanya memakai fakta berstatus APPROVED_FOR_PUBLIC_CONTENT.

## Klasifikasi informasi
- INTERNAL_RESTRICTED: strategi, blueprint, data operasional, telaah internal, dan dokumen yang dibatasi.
- INTERNAL_GENERAL: pengetahuan internal yang boleh dipakai pegawai sesuai hak akses.
- APPROVED_FOR_PUBLIC_CONTENT: fakta/teks yang telah disetujui untuk konten eksternal.
- DRAFT_OR_UNVERIFIED: rancangan, bahan kerja, konflik, atau fakta yang belum diverifikasi.

## Aturan wajib
- Aplikasi internal bukan berarti semua pengguna boleh melihat semua dokumen. Terapkan role-based access control.
- Pengguna biasa tidak boleh mengakses blueprint, dokumen manajemen, atau dokumen terbatas kecuali diberi izin.
- PUBLIC CONTENT MODE tidak boleh memakai INTERNAL_RESTRICTED atau DRAFT_OR_UNVERIFIED sebagai klaim publik.
- Rancangan peraturan dan telaah atas rancangan harus diberi label rancangan/analisis, bukan peraturan berlaku.
- Jangan menjanjikan profit, hasil pasti, bebas risiko, atau memberikan rekomendasi buy/sell personal.
- Jangan menampilkan data pribadi nasabah, kredensial, password, PIN, OTP, atau rahasia perusahaan.
- Jika tidak yakin, hentikan klaim dan minta review admin/compliance.
- Setiap hasil konten perlu menyimpan daftar sumber yang dipakai dan status review.
