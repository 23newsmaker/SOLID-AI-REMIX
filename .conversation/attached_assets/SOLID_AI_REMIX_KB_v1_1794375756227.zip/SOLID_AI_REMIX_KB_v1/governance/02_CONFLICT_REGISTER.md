# CONFLICT REGISTER — KEPUTUSAN SUMBER
Versi 1.0 | Status: Keputusan pengguna dicatat

## Konflik yang telah diputuskan
Pengguna secara eksplisit memilih Sumber A, yaitu `Spesifikasi Mini Mikro.docx`, untuk empat parameter berikut. Nilai dari sumber tersebut dipakai sebagai acuan KB untuk empat item ini.

| Parameter | Nilai Sumber A | Catatan sumber |
|---|---:|---|
| Contract size Gold XUL10 | 100 “Tray Once” (ditulis demikian dalam dokumen; kemungkinan maksudnya Troy Ounce, perlu konfirmasi ejaan teknis sebelum ditampilkan ke pengguna) | Jangan diam-diam mengubah teks sumber |
| Contract size Brent BCO10_BBJ | USD 1.000 per Barrel | Pertahankan satuan sebagaimana dokumen |
| Commission Fee Mini | USD 1 / Lot | Dokumen mencantumkan VAT Commission Fee 11% terpisah |
| Minimum Price Spread Quote Gold | USD 0,20 / Troy Once / Side | Ejaan “Troy Once” mengikuti dokumen; normalisasi ke “Troy Ounce” hanya setelah validasi |

## Sumber yang tidak dipakai untuk empat parameter tersebut
FAQ CS v4 memuat angka berbeda (Gold 10 Troy Ounce; Brent 100 Barrel; fee USD 1,5/lot/side; minimum spread Gold USD 0,40/Troy Ounce/side). Untuk empat parameter di atas, angka FAQ tidak digunakan sebagai acuan. FAQ tetap disimpan sebagai dokumen historis/referensi naratif.

## Aturan perubahan
- Hanya admin berwenang dapat mengubah keputusan sumber.
- Perubahan harus mencatat sumber pengganti, versi/tanggal, approver, tanggal perubahan, dan dampak pada konten.
- Jangan menggabungkan angka dari dua dokumen.
- Untuk parameter lain yang belum diputuskan, jangan otomatis menganggap Sumber A berlaku. Tandai `NEEDS_REVIEW`.
