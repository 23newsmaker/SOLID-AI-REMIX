# PROMPT UTAMA UNTUK REPLIT AGENT — SOLID AI REMIX

Anda bertindak sebagai senior full-stack engineer dan solution architect. Bangun aplikasi internal bernama **SOLID AI REMIX** berdasarkan spesifikasi berikut. Pengguna proyek tidak memiliki kemampuan coding; karena itu implementasi harus jelas, stabil, mobile-first, dan mudah dikelola melalui panel admin.

## 1. Cara kerja yang wajib
- Kerjakan bertahap. Jangan membuat seluruh sistem sekaligus tanpa checkpoint.
- Sebelum mengubah file, periksa struktur project yang sudah ada dan pertahankan pekerjaan yang benar.
- Setelah setiap tahap, jelaskan apa yang dibuat, file yang berubah, cara menguji, dan apa yang masih membutuhkan keputusan manusia.
- Jangan mengarang data perusahaan, spesifikasi produk, status regulasi, hasil AI, atau biaya.
- Jangan menyatakan fitur berhasil jika belum benar-benar diuji.
- Jika ada kekurangan dokumen atau keputusan, buat placeholder yang aman dan catat sebagai `NEEDS_ADMIN_REVIEW`.

## 2. Tujuan produk
SOLID AI REMIX adalah aplikasi **internal** PT Solid Gold Berjangka untuk membantu tim membuat satu video TikTok dari satu foto dan instruksi teks.

Alur utama:
1. Pengguna masuk ke aplikasi.
2. Memilih mode `INTERNAL` atau `PUBLIC CONTENT` sesuai hak akses.
3. Mengunggah satu foto dari galeri atau kamera HP.
4. Memilih satu atau beberapa segmen: `Mikro`, `Mini`, `Regular`.
5. Menulis prompt bebas atau meminta AI membantu menyusun prompt.
6. Sistem membaca Knowledge Base sesuai mode dan segmen yang dipilih.
7. Sistem membuat satu prompt video final dan menampilkan ringkasan naskah/adegan untuk disetujui pengguna.
8. Setelah disetujui, backend mengirim job ke provider image-to-video yang dikonfigurasi.
9. Pengguna melihat status proses, preview hasil, dan mengunduh satu video.

Target output awal: vertikal 9:16, durasi 10–15 detik. Jika provider/model belum mendukung target ini, jangan berpura-pura; tampilkan batasan dan minta admin memilih konfigurasi.

## 3. Arsitektur yang diminta
- Web application responsif, mobile-first.
- PWA: manifest, ikon placeholder, installability, service worker dengan cache aman untuk shell aplikasi. Jangan menyimpan foto/video sensitif ke cache publik.
- Backend terpisah dari frontend.
- Database untuk user, role, jobs, metadata output, usage/cost log, KB metadata, approval, dan audit log.
- File storage privat untuk foto sumber dan hasil video; gunakan signed URL atau mekanisme akses privat.
- Buat interface/adapter `VideoGenerationProvider` agar provider GPU/API dapat diganti tanpa mengubah UI dan alur inti.
- Provider belum ditetapkan. Buat mock provider untuk pengembangan UI/testing, dengan label jelas `SIMULATION — NOT A REAL VIDEO`. Jangan mengembalikan video palsu seolah hasil AI sungguhan.
- Siapkan adapter API provider eksternal sebagai interface dan dokumentasi env var, tetapi jangan mengaktifkan layanan berbayar sampai admin memasukkan kredensial dan menyetujui provider/model.
- Simpan API key hanya di Replit Secrets/environment variables. Jangan pernah mengirim secret ke frontend, log, KB, atau repository.

## 4. Knowledge Base
Gunakan folder `knowledge/`, `governance/`, dan `source_documents/` dari paket yang diberikan.
- Baca `governance/00_MASTER_KB_INDEX.md` terlebih dahulu.
- Baca `governance/01_SOURCE_REGISTER.md`, `02_CONFLICT_REGISTER.md`, dan `03_ACCESS_AND_CONTENT_POLICY.md`.
- Jangan mengubah file sumber asli di `knowledge/source_nodes/` dan `source_documents/`.
- Buat ingestion/indexing yang mempertahankan metadata sumber: source ID, nama dokumen, versi/tanggal jika tersedia, status validasi, klasifikasi akses, dan lokasi file.
- Jangan menganggap semua dokumen sebagai fakta aktif. Bedakan `APPROVED`, `REFERENCE`, `DRAFT`, `EXPERIMENTAL`, `NEEDS_REVIEW`.
- Untuk angka produk, gunakan `knowledge/products/PRODUCT_FACTS_MASTER_INITIAL.md` sebagai nilai terpilih awal hanya pada empat konflik yang dinyatakan di sana. Jangan memperluas keputusan itu ke parameter lain.
- Bila data tidak ditemukan atau konflik belum diputuskan, tampilkan `Data belum tersedia/ perlu konfirmasi admin`; jangan menebak.
- Rancangan peraturan dan telaahnya harus selalu ditandai rancangan/analisis internal, bukan peraturan berlaku.
- Buat panel admin untuk menambah versi KB, mengubah status, menonaktifkan sumber, melihat konflik, dan mencatat siapa yang mengubahnya. Jangan izinkan pengguna biasa mengubah sumber atau status validasi.

## 5. Mode dan keamanan konten
Buat dua mode:

### INTERNAL MODE
Untuk pencarian dan analisis internal, draft edukasi internal, ringkasan dokumen, dan brainstorming. Akses dibatasi berdasarkan role. Dokumen `INTERNAL_RESTRICTED` hanya untuk role yang diizinkan.

### PUBLIC CONTENT MODE
Untuk naskah/video yang dapat dipublikasikan. Hanya gunakan fakta dan materi berstatus `APPROVED_FOR_PUBLIC_CONTENT`. Jangan memasukkan strategi rahasia, dokumen terbatas, rancangan regulasi sebagai hukum berlaku, atau informasi belum terverifikasi.

Wajib ada pemeriksaan konten sebelum generate:
- Tidak boleh menjanjikan profit/hasil pasti atau menyebut bebas risiko.
- Tidak boleh membuat rekomendasi buy/sell personal.
- Tidak boleh mengarang margin, fee, spread, contract size, trading hours, legalitas, atau data produk.
- Jika konten membutuhkan disclosure/pernyataan risiko, gunakan teks yang sudah disetujui admin; jika belum ada, tandai untuk review dan jangan mengarang disclaimer legal.
- Simpan daftar sumber yang digunakan pada setiap draft dan hasil.
- Tambahkan status `DRAFT`, `NEEDS_REVIEW`, `APPROVED`, `REJECTED`.

## 6. Segmen produk
- Multi-select Mikro, Mini, Regular.
- Setiap segmen memiliki namespace/ruang data sendiri.
- Jika pengguna memilih beberapa segmen, AI boleh membuat perbandingan atau konten gabungan, tetapi harus menyebut segmen dengan jelas dan tidak memindahkan parameter satu segmen ke segmen lain.
- Saat ini sumber Mikro belum terverifikasi lengkap. Jangan mengisi celah Mikro menggunakan data Mini atau Regular.

## 7. Halaman MVP
1. Login.
2. Dashboard.
3. Create Video: upload photo, segment multi-select, mode, prompt, generate.
4. Prompt Review: tampilkan naskah/adegan, sumber yang dipakai, warning compliance, tombol setujui.
5. Generation Status: queued/running/succeeded/failed, progress jika provider mendukung.
6. Result: preview, download, metadata, biaya estimasi/aktual bila tersedia.
7. History: daftar job milik pengguna.
8. Admin: user/role, KB sources, conflict register, provider settings, usage & cost, audit log.

## 8. Role minimum
- `SUPER_ADMIN`: seluruh konfigurasi, KB, provider, user, biaya, audit.
- `ADMIN`: kelola KB dan konten sesuai izin yang diberikan.
- `CREATOR`: membuat draft/video dan melihat riwayat sendiri.
- `REVIEWER_COMPLIANCE`: meninjau konten publik dan memberi status approval.
- `VIEWER`: akses baca terbatas.

Terapkan pemeriksaan akses di backend, bukan hanya menyembunyikan tombol di frontend.

## 9. Privasi dan keamanan
- Batasi tipe dan ukuran file upload; validasi MIME dan file sebenarnya.
- Foto/video disimpan privat, bukan public bucket.
- Berikan kebijakan retensi dan tombol hapus sesuai kewenangan.
- Jangan tampilkan dokumen internal pada URL publik.
- Audit akses dokumen terbatas, perubahan KB, persetujuan konten, dan penggunaan provider.
- Jangan menyimpan password, PIN, OTP, atau kredensial nasabah dalam prompt/log.
- Tampilkan persetujuan bahwa pengguna memiliki hak/izin atas foto yang diunggah.

## 10. Pengendalian biaya
- Catat provider, model, durasi output, waktu GPU aktif, status, dan biaya aktual yang dikembalikan provider.
- Buat limit harian/bulanan yang dapat diatur SUPER_ADMIN.
- Minta konfirmasi sebelum job berbayar dijalankan jika limit/biaya belum disetujui.
- Cegah double-click menghasilkan job ganda; gunakan idempotency key.
- Jangan mengasumsikan estimasi biaya adalah biaya aktual.
- Jika provider belum dikonfigurasi, gunakan mock/simulation mode saja.

## 11. Tahapan implementasi dan checkpoint
Kerjakan sesuai urutan ini dan berhenti untuk laporan setelah tiap tahap:

**Tahap A — Audit dan fondasi**
- Audit file project dan paket KB.
- Buat struktur aplikasi, autentikasi, role, database schema, dan audit log dasar.
- Laporkan keputusan stack dan alasan singkat.

**Tahap B — UI mobile-first dan PWA**
- Bangun halaman login, dashboard, create video, prompt review, status, result, history.
- Uji pada ukuran layar HP.
- Gunakan mock provider dengan label simulasi.

**Tahap C — KB ingestion dan governance**
- Buat indexing/retrieval dokumen dengan metadata dan permission filtering.
- Implementasikan dua mode dan multi-select segmen.
- Implementasikan conflict handling dan source citation pada jawaban/draft.

**Tahap D — Admin & compliance**
- Admin KB, source register, conflict register, approval workflow, cost limits, audit log.

**Tahap E — Video provider adapter**
- Buat adapter dan dokumentasi integrasi.
- Jangan aktifkan provider berbayar sampai admin menentukan provider, model, API key, wilayah penyimpanan, retensi, dan batas biaya.
- Setelah dikonfigurasi, lakukan test job kecil dan catat hasil aktual.

**Tahap F — PWA & acceptance testing**
- Uji install PWA, upload foto dari HP, prompt, persetujuan, job, hasil, download, akses role, dan penghapusan file.
- Buat checklist penerimaan dan daftar isu tersisa.

## 12. Kriteria penerimaan MVP
- Pengguna dapat masuk sesuai role.
- Pengguna dapat memilih Mikro, Mini, Regular secara terpisah atau kombinasi.
- Upload foto berfungsi dari browser HP.
- AI hanya mengambil KB yang boleh diakses pada mode tersebut.
- Draft menampilkan sumber dan peringatan bila data belum valid.
- Public Content Mode menolak klaim berisiko/tidak disetujui.
- Satu klik generate membuat maksimal satu job.
- Mock mode jelas ditandai simulasi.
- Provider asli hanya berjalan setelah konfigurasi dan persetujuan admin.
- Hasil dapat dipreview dan diunduh melalui akses privat.
- Semua biaya dan perubahan penting tercatat.

## Instruksi pertama
Mulai dari **Tahap A saja**. Audit paket dan project yang ada, lalu bangun fondasi minimum. Jangan lanjut ke Tahap B sebelum melaporkan struktur file, stack, database schema, role model, dan daftar keputusan yang masih membutuhkan admin. Jangan meminta pengguna melakukan coding manual; berikan instruksi operasional yang sederhana.
