# SOLID AI REMIX — Knowledge Base Package v1.0

Paket awal Knowledge Base internal untuk aplikasi SOLID AI Remix. Paket ini menggabungkan 58 node Markdown dari `knowledge-solid-gold.zip` dengan dokumen sumber tambahan yang diunggah pengguna.

## Isi paket
- `knowledge/source_nodes/` — 58 node sumber dari arsip KB lama; dipertahankan tanpa mengubah isi.
- `source_documents/` — salinan dokumen sumber utama yang diunggah terpisah.
- `governance/` — aturan prioritas sumber, klasifikasi, konflik, dan pengamanan penggunaan pengetahuan.
- `knowledge/` — kerangka modul hasil konsolidasi. Isinya tidak boleh dianggap sebagai fakta final jika masih berstatus draft atau perlu verifikasi.
- `REPLIT_MASTER_BUILD_PROMPT.md` — prompt siap copy-paste ke Replit Agent.

## Status
Ini adalah paket konsolidasi awal, bukan pengesahan seluruh isi dokumen. Parameter yang dipilih pengguna dari `Spesifikasi Mini Mikro.docx` dicatat sebagai sumber acuan untuk konflik yang telah dibahas. Perubahan parameter harus melalui admin dan pencatatan versi.

## Cara memakai di Replit
1. Buat project web app baru di Replit.
2. Unggah/ekstrak folder paket ini ke project.
3. Buka `REPLIT_MASTER_BUILD_PROMPT.md`, salin seluruh instruksinya ke Replit Agent.
4. Minta Replit mengerjakan secara bertahap dan melaporkan file yang dibuat serta tes yang dijalankan.
5. Jangan masukkan API key ke file KB atau source code. Simpan di Replit Secrets.
6. Jangan mengaktifkan provider GPU berbayar sebelum provider, model, batas biaya, dan persetujuan admin ditetapkan.

## Batas penting
- Aplikasi internal; dokumen internal tetap dilindungi berdasarkan role.
- Informasi internal tidak otomatis boleh dimasukkan ke video publik.
- Draft regulasi bukan regulasi berlaku.
- Data yang bertentangan tidak boleh ditebak atau dirata-ratakan.
- Jangan membuat klaim profit, jaminan hasil, atau rekomendasi transaksi personal.
- Jangan mengarang spesifikasi Mikro, Mini, atau Regular jika sumbernya belum tersedia/terverifikasi.
