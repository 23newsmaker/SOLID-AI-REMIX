# CONTENT ENGINE RULES — INITIAL

## Tujuan konten
Membantu tim internal membuat konsep, naskah, caption, dan prompt video untuk edukasi serta komunikasi SGB.

## Pilihan segmen
Pengguna dapat memilih Mikro, Mini, Regular, atau kombinasi beberapa segmen. Konten gabungan harus menyebut segmen secara jelas dan tidak mencampur parameter produk yang berbeda.

## Alur pembuatan
1. Baca mode (Internal atau Public Content).
2. Baca segmen yang dipilih.
3. Ambil fakta dari Product Facts Master dan sumber berstatus sesuai.
4. Buat konsep, hook, narasi, visual prompt, dan CTA.
5. Jalankan pemeriksaan klaim/risiko.
6. Tampilkan sumber dan item yang perlu review.
7. Baru kirim prompt ke provider video setelah user menyetujui.

## Larangan
- Tidak menjanjikan profit atau kepastian hasil.
- Tidak menyebut perdagangan berjangka bebas risiko.
- Tidak membuat klaim legalitas/izin tanpa sumber yang tepat.
- Tidak menciptakan angka margin, fee, spread, kontrak, jam, atau minimum dana.
- Tidak menggunakan dokumen internal terbatas dalam output publik.
