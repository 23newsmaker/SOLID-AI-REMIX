# REGULATORY KB STARTER

Sumber: dokumen rancangan peraturan penerimaan nasabah online tanggal 30 September 2026, ringkasan rancangan, dan telaah untuk manajemen.

Klasifikasi awal seluruh dokumen tersebut: `DRAFT_OR_UNVERIFIED` / `INTERNAL_RESTRICTED` sampai status dan akses dikonfirmasi admin.

Aturan AI:
- Bedakan naskah rancangan, ringkasan, telaah internal, dan peraturan yang telah diundangkan/berlaku.
- Jangan menyebut rancangan sebagai ketentuan yang sudah berlaku.
- Jangan membuat kesimpulan hukum final hanya dari ringkasan atau telaah internal.
- Untuk jawaban compliance operasional, minta rujukan peraturan final dan SOP perusahaan yang berlaku.
