# KB Node — Multilateral vs Bilateral dan Varian Kurs (Akun Reguler)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** apa beda produk Multilateral dan Bilateral di Akun Reguler, serta arti varian kurs tetap (IDR) dan kurs mengambang (USD).

| Aspek | Multilateral | Bilateral |
|---|---|---|
| Dasar | Kontrak resmi Bursa Berjangka Jakarta (JFX) | Sistem Perdagangan Alternatif (SPA) |
| Produk | Olein (OLE), Emas 250 Gram (GOL250), Emas 1 Kg (GOL), Kopi Arabika (ACF), Kopi Robusta (RCF) | Indeks Hong Kong, Indeks Jepang, Emas Loco London, Minyak Brent, GBP/USD, EUR/USD, AUD/USD, USD/CHF, USD/JPY |
| Data yang tersedia di KB | Spesifikasi kontrak resmi bursa (satuan kontrak, bulan kontrak, jam perdagangan, tik harga, batas posisi). Margin dan komisi belum tersedia | Spesifikasi kontrak plus margin, komisi, dan biaya menginap/rollover milik perusahaan |
| Penyelesaian (contoh) | Olein: penyerahan DO Terdaftar. Emas 250 Gram: penyerahan di Gudang Terdaftar | Cash Settlement |

**Varian kurs pada produk Bilateral:** produk Bilateral (contoh: Indeks Hong Kong, Emas Loco London, USD/CHF) tersedia dalam dua varian.
- **Kurs tetap (IDR):** margin, komisi, dan biaya dinyatakan dalam Rupiah. Contoh kode: HKK50_BBJ, XUL10, UC1010_BBJ.
- **Kurs mengambang (USD):** margin, komisi, dan biaya dinyatakan dalam Dolar AS. Contoh kode: HKK5U_BBJ, XULF, UC10F_BBJ.

Pilih angka sesuai varian yang ditanya user — jangan mencampur kolom IDR dan USD dalam satu jawaban.

**Jangan disamakan dengan:** [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]] (status data margin/komisi Multilateral), [[KB-Node-JenisAkun-Reguler-Overview]] (gambaran umum Akun Reguler), [[KB-Node-Perbandingan-AkunMini-vs-AkunReguler]] (beda jenis akun, bukan beda jenis produk).

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Daftar-Produk-Karakteristik]] · [[KB-Node-AkunReguler-Multilateral-Olein-OLE]] · [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]] · [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]] · [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]] · [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]] · [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]] · [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]] · [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] · [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]] · [[KB-Node-AkunReguler-Bilateral-GBPUSD]] · [[KB-Node-AkunReguler-Bilateral-EURUSD]] · [[KB-Node-AkunReguler-Bilateral-AUDUSD]] · [[KB-Node-AkunReguler-Bilateral-USDCHF]] · [[KB-Node-AkunReguler-Bilateral-USDJPY]] · [[KB-Node-Kurs-FixedRate-USD-IDR]] · [[KB-Node-Legalitas-Daftar-Izin]]
