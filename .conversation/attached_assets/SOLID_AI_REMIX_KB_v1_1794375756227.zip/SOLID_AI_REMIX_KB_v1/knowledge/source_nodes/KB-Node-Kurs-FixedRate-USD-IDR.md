# KB Node — Kurs Fixed Rate USD ke IDR (Akun Mini)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** kurs tetap (Fixed Rate) yang dipakai untuk mengonversi nominal USD ke IDR pada Akun Mini.

**Fixed Rate: 1 USD = IDR 10.000.**

Sumber: Trading Rules Akun Mini Bagian VIII.1 (deposit margin awal minimum USD 500 dengan Fixed Rate 1 USD = IDR 10.000) dan Trade Table Akun Mini Februari 2026.

**Konversi angka-angka Akun Mini (hasil kali dari Fixed Rate di atas):**

| Item | USD | IDR |
|---|---|---|
| Minimum setoran awal buka akun | 500 | 5.000.000 |
| Minimum top-up akun aktif | 1 | 10.000 |
| Batas maksimal setoran/top-up per transaksi | 1.000 | 10.000.000 |
| Batas maksimal setoran/top-up per bulan | 2.000 | 20.000.000 |
| Maks. Warning Equity | 2.300 | 23.000.000 |
| Maks. Equity | 2.500 | 25.000.000 |

**Contoh:** 800 USD x Rp10.000 = Rp8.000.000. Rp3.000.000 : Rp10.000 = USD 300.

**Cakupan rate:** Fixed Rate 1 USD = IDR 10.000 adalah satu-satunya kurs konversi yang tersedia di KB. Rate mata uang lain (misalnya EUR, GBP, JPY) tidak tersedia. Untuk Akun Reguler, varian kurs tetap (IDR) dan kurs mengambang (USD) tiap produk sudah punya angka masing-masing di node produknya — pakai angka di node produk itu, jangan dihitung ulang dari node ini.

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Minimum-SetoranAwal]] (minimum buka akun baru), [[KB-Node-AkunMini-Minimum-TopUp]] (minimum top-up akun aktif), [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] (batas atas setoran) — node ini hanya kurs dan tabel konversi, bukan sumber utama tiap ketentuan tersebut.

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Contoh-Perhitungan]] · [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]]
