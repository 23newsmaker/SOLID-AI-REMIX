# KB Node — Produk Multilateral: Kontrak Berjangka Emas 1 Kg (GOL)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak resmi Bursa Berjangka Jakarta (JFX) untuk produk Emas 1 Kg (kode kontrak GOL) — tersedia di **Akun Reguler**, kategori Multilateral.

| Item | Ketentuan |
|---|---|
| Kode Kontrak | GOL |
| Dasar Kontrak | 1 kg emas, 99,9 finest kualitas LBMA |
| Satuan Kontrak | 1 kg (1.000 gram) |
| Bulan Kontrak | 3 bulan berturut-turut |
| Hari & Jam Perdagangan | Setiap hari perdagangan, pukul 09.30–17.30 WIB |
| Perubahan Harga Minimum (Tik) | Rp 50/gram (termasuk PPN) = Rp 50.000/lot (termasuk PPN) |
| Batas Perubahan Harga | Rp 5.000/gram di atas/bawah Harga Penyelesaian hari sebelumnya (tidak berlaku untuk Bulan Berjalan/Bulan Terdekat) |
| Mutu | Kemurnian minimum 99,99%, refineri diakui LBMA |
| Tempat Penyerahan | Gudang Terdaftar di Jakarta & Surabaya |
| Satuan Penyerahan | 1 kg |
| Posisi Wajib Lapor | 150 lot |
| Batas Posisi Spekulatif | 500 lot |

**Catatan margin/komisi:** margin dan komisi khusus PT Solid Gold Berjangka untuk produk Multilateral (termasuk Emas 1 Kg) belum tercakup di data resmi yang tersedia. Kalau user tanya margin/komisi spesifik produk ini, jawab spesifikasi kontraknya saja (tabel di atas) dan eskalasikan — lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]].

**Jangan disamakan dengan:**
- **Bukan** produk Gold Akun Mini (kode XUL10, Contract Size 10 Troy Ounce menurut Trade Table resmi) — lihat [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]].
- **Bukan** produk Emas Loco London Akun Reguler Bilateral (kode XUL10/XULF, satuan 100 Troy Ons) — lihat [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]].
- **Bukan** Emas 250 Gram (kode GOL250, satuan 250 gram) — lihat [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]]. GOL (1 Kg) dan GOL250 (250 gram) adalah dua kontrak Multilateral emas yang BERBEDA, jangan tertukar meski sama-sama emas fisik JFX.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 1.3.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Multilateral-Olein-OLE]] · [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]] · [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]]
