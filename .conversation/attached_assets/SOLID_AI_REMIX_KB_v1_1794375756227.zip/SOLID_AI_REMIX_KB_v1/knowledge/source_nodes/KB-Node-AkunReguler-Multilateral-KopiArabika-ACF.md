# KB Node — Produk Multilateral: Kontrak Berjangka Kopi Arabika (ACF)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak resmi Bursa Berjangka Jakarta (JFX) untuk produk Kopi Arabika (kode kontrak ACF) — tersedia di **Akun Reguler**, kategori Multilateral.

| Item | Ketentuan |
|---|---|
| Kode Kontrak | ACF |
| Satuan Kontrak | 2 Metrik Ton (2.000 kg) |
| Bulan Kontrak | Maret, Mei, Juli, September, Desember |
| Hari & Jam Perdagangan | Senin–Jumat. Sesi 1: 08:30–11:30 WIB; Sesi 2: 16:00–02:00 WIB |
| Perubahan Harga Minimum (Tik) | Rp 50/kg = Rp 100.000/lot |
| Batas Perubahan Harga | < Rp 40.000/kg → limit Rp 2.000; ≥ Rp 40.000/kg → limit Rp 3.000 (tidak berlaku bulan spot) |
| Mutu | SNI No. 01-2907-2008, tingkat mutu 1 (BSN) |
| Tempat Penyerahan | Gudang Terdaftar Medan, Makassar, Jakarta, Surabaya |
| Satuan Penyerahan | Minimal 8 lot atau kelipatannya, masing-masing 1 lot = 2 ton bersih |
| Posisi Wajib Lapor | 300 lot |
| Batas Posisi | 1.000 lot |

**Catatan margin/komisi:** margin dan komisi khusus PT Solid Gold Berjangka untuk produk Multilateral (termasuk Kopi Arabika) belum tercakup di data resmi yang tersedia. Kalau user tanya margin/komisi spesifik produk ini, jawab spesifikasi kontraknya saja (tabel di atas) dan eskalasikan — lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]].

**Jangan disamakan dengan:**
- **Bukan** Kopi Robusta (kode RCF, satuan 5 Metrik Ton, bulan kontrak berbeda) — lihat [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]]. Dua kontrak kopi ini punya satuan kontrak, jam sesi, dan bulan kontrak yang berbeda — jangan tertukar.
- Ini produk **Akun Reguler** (Multilateral/JFX), bukan produk Akun Mini.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 1.4.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Multilateral-Olein-OLE]] · [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]] · [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]]
