# KNOWLEDGE BASE TAMBAHAN — Biaya, Storage/Rollover Fee, Margin & Spread (Akun Mini) (REDIRECT — lihat Node)

> **AUDIENCE: PUBLIC.** **Isi lengkap dokumen ini sudah dipecah menjadi node-node kecil per topik** (restrukturisasi September 2026) — termasuk pemisahan tegas antara minimum SETORAN AWAL, minimum TOP-UP, dan BATAS MAKSIMAL transaksi (tiga angka berbeda yang sebelumnya rawan tertukar). Gunakan node-node di bawah sebagai evidence utama. Peta lengkap seluruh node: [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Safe answer & aturan kapan boleh sebut angka: [[System Prompt]]

**PT Solid Gold Berjangka — Redirect Biaya/Swap/Margin (Akun Mini)**

## Node Pengganti Bagian 1 (Konsep Dasar: Storage/Rollover Fee, Margin, Spread, Komisi)
→ [[KB-Node-Istilah-Trading-Dasar]] (Margin, Spread, definisi umum)
→ [[KB-Node-AkunMini-StorageRolloverFee]] (konsep Storage/Rollover Fee & kenapa bukan "swap")

## Node Pengganti Bagian 2.1 (Spesifikasi Kontrak & Biaya per Produk)
→ [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]]
→ [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]]

## Node Pengganti Bagian 2.2 (Jam Trading & Ketentuan Produk)
→ [[KB-Node-AkunMini-JamTrading]]

## Node Pengganti Bagian 2.3 (Kebijakan Umum Akun Mini)
→ [[KB-Node-AkunMini-Minimum-SetoranAwal]] (minimum setoran awal buka akun)
→ [[KB-Node-AkunMini-Margin-Equity-CallMargin]] (Maks Equity, Warning Equity, Call Margin, ABS, CBS, Default OTP)
→ [[KB-Node-AkunMini-Komisi-Transaksi]] (komisi)

## Node Pengganti Bagian 2.4 (Biaya per Jenis Akun)
→ [[KB-Node-AkunMini-Minimum-SetoranAwal]], [[KB-Node-AkunMini-Komisi-Transaksi]]

## Node Pengganti Bagian 2.5 (Biaya Lain-lain)
→ [[KB-Node-AkunMini-BiayaLainLain]] (biaya deposit/withdrawal/inaktif — belum ada data resmi)
→ [[KB-Node-AkunMini-Minimum-TopUp]] (minimum top-up Rp10.000 — **boleh disebutkan langsung ke customer**)
→ [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] (batas maksimal Rp10jt/transaksi & Rp20jt/bulan)
→ [[KB-Node-AkunMini-Margin-Equity-CallMargin]] (Call Margin Level, ABS)

**⚠️ Tiga angka yang sering tertukar — sudah dipisah jadi 3 node terpisah:** minimum SETORAN AWAL buka akun baru (IDR 5.000.000/USD 500) ≠ minimum TOP-UP ke akun aktif (Rp10.000) ≠ BATAS MAKSIMAL transaksi (Rp10jt/transaksi, Rp20jt/bulan). Lihat ketiga node di atas — masing-masing punya bagian "Jangan disamakan dengan" yang saling merujuk.

---

Dokumen terkait: [[SOLID_GOLD_BERJANGKA_MASTER_KB_v1_8_1]] (redirect) · sumber data resmi: [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]] · aturan operasional: [[Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026]] · khusus Akun Reguler (skala berbeda, jangan dicampur): [[KB_Tambahan_Akun_Reguler_v1_8]] (redirect)

Untuk aturan kapan/bagaimana chatbot boleh mengutip angka di atas, lihat [[System Prompt]].
