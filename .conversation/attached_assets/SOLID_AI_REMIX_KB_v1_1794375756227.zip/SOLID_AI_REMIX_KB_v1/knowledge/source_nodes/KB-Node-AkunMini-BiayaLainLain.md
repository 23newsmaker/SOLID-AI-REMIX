# KB Node — Akun Mini: Biaya Lain-lain (Belum Ada Data Resmi)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** biaya-biaya lain yang datanya belum resmi tersedia.

| Item | Nilai/Ketentuan |
|---|---|
| Biaya deposit | Belum ada data resmi |
| Biaya withdrawal | Belum ada data resmi |
| Biaya inaktif akun | Belum ada data resmi |

Kalau user tanya soal biaya-biaya ini, pakai safe answer (belum tersedia, arahkan ke tim resmi) — JANGAN mengarang angka atau menebak berdasarkan biaya lain yang sudah ada.

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Minimum-TopUp]] (minimum top-up Rp10.000 — SUDAH ada datanya, beda dari "biaya deposit" yang masih TBD di node ini), [[KB-Node-AkunMini-Komisi-Transaksi]] (komisi transaksi — sudah ada datanya).

---
**Node terkait (navigasi KB):** [[KB-Node-Withdrawal-Prosedur-dan-Estimasi-Waktu]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Initial-Margin]] · [[KB-Node-AkunMini-Margin-Equity-CallMargin]] · [[KB-Node-AkunMini-StorageRolloverFee]] · [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]] · [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]]
