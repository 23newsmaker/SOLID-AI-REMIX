# KB Node — Produk Bilateral: Indeks Hong Kong (HKK50_BBJ & HKK5U_BBJ)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak & biaya (margin, komisi, rollover) untuk produk Indeks Hong Kong — tersedia di **Akun Reguler**, kategori Bilateral (SPA). Dua varian: kurs tetap (IDR) dan kurs mengambang (USD).

| Item | HKK50_BBJ (Kurs Tetap, IDR) | HKK5U_BBJ (Kurs Mengambang, USD) |
|---|---|---|
| Ukuran Kontrak | IDR 50.000/poin | USD 5/poin |
| Jam Perdagangan | Senin–Jumat: Pagi 08:15–11:00, Siang 12:00–15:30, AHFT 16:15–02:00 WIB | Senin–Jumat: Pagi 08:15–11:00, Siang 12:00–15:30, AHFT 16:15–02:00 WIB |
| Margin Transaksi Harian | IDR 10.000.000/lot | USD 1.000/lot |
| Margin Transaksi Menginap | IDR 20.000.000/lot | USD 2.000/lot |
| Komisi | IDR 150.000/lot/sisi | USD 15/lot/sisi |
| Biaya Menginap Buy/Sell | IDR 30.000/lot/malam | USD 3/lot/malam |
| PPN | 11% dari komisi & biaya menginap | 11% dari komisi & biaya menginap |
| Maintenance Margin | 70% dari kebutuhan margin | 70% dari kebutuhan margin |
| Auto Liquidasi | 30% dari kebutuhan margin | 30% dari kebutuhan margin |
| Spread Kuotasi Minimum | 8 poin/sisi | 8 poin/sisi |
| Pergerakan Harga Minimum | 1 poin | 1 poin |
| Rentang Limit & Stop Order | 20–500 poin | 20–500 poin |
| Penyelesaian | Cash Settlement | Cash Settlement |

**Jangan disamakan dengan:**
- **Bukan** Indeks Jepang (HKK ≠ JPK, kode & jam perdagangan berbeda) — lihat [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]].
- Ini produk **Akun Reguler** (Bilateral/SPA), margin & komisi milik PT Solid Gold Berjangka sendiri (bukan sekadar spesifikasi bursa) — beda dari produk Multilateral yang margin/komisinya belum tercakup, lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]].

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 2.1.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] · [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]] · [[KB-Node-AkunReguler-Bilateral-GBPUSD]] · [[KB-Node-AkunReguler-Bilateral-EURUSD]] · [[KB-Node-AkunReguler-Bilateral-AUDUSD]] · [[KB-Node-AkunReguler-Bilateral-USDCHF]] · [[KB-Node-AkunReguler-Bilateral-USDJPY]]
