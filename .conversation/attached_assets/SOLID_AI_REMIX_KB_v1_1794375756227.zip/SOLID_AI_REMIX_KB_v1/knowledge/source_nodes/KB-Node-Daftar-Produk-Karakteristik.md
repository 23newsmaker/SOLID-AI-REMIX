# KB Node — Daftar Produk & Karakteristik Umum

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** karakteristik umum tiap kategori produk (edukatif, bukan spesifikasi kontrak/biaya).

**Produk yang benar-benar tersedia:** Akun Mini → Gold (XUL10) & Brent Oil (BCO10_BBJ). Akun Reguler → Multilateral (Olein, Emas 250 Gram, Emas 1 Kg, Kopi Arabika, Kopi Robusta) & Bilateral (Indeks Hong Kong, Indeks Jepang, Emas Loco London, Minyak Brent, GBP/USD, EUR/USD, AUD/USD, USD/CHF, USD/JPY). Kalau user tanya produk di luar daftar ini (mis. Silver), sampaikan bahwa produk itu belum tersedia.

| Produk | Karakteristik |
|---|---|
| Gold/Emas | Familiar bagi user Indonesia; dipengaruhi dolar AS, suku bunga, inflasi, data ekonomi, geopolitik, sentimen risk-on/off |
| Silver | Logam mulia seperti Gold, umumnya lebih volatil; dipengaruhi faktor industri/manufaktur. **Catatan: saat ini TIDAK ada produk Silver di Akun Mini maupun Akun Reguler** — karakteristik ini hanya edukasi umum, jangan ditawarkan atau dijelaskan seolah produknya tersedia |
| Brent Oil | Harga minyak mentah global; dipengaruhi konflik geopolitik, keputusan OPEC+, suplai-demand energi, data persediaan, ekonomi global, kurs USD |
| Forex | Pasangan populer: EUR/USD, GBP/USD, AUD/USD, USD/JPY, USD/CHF; dipengaruhi suku bunga, inflasi, data tenaga kerja, kebijakan bank sentral, geopolitik |
| Indeks | Contoh: Hang Seng, Nikkei 225; representasi kumpulan saham suatu bursa |

*(Cara menyampaikan karakteristik ini ke customer dengan aman ada di System Prompt — jangan katakan "paling aman", "pasti naik", atau "cocok untuk semua orang".)*

**Jangan disamakan dengan:** node spesifikasi kontrak per produk (mis. [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]], [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]]) — node ini hanya karakteristik edukatif umum, bukan angka kontrak/biaya.

---
**Node terkait (navigasi KB):** [[KB-Node-Perbandingan-AkunMini-vs-AkunReguler]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] · [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] · [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]] · [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]] · [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]] · [[KB-Node-AkunReguler-Bilateral-EURUSD]]
