# KB Node — Akun Mini: Komisi/Biaya Transaksi

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** komisi/biaya per transaksi untuk Akun Mini. Di Trade Table resmi, biaya ini disebut **Facility Fee**.

**Facility Fee (komisi): USD 1,5/lot/sisi + PPN 11% dari Facility Fee.** Berlaku untuk Gold (XUL10) dan Brent Oil (BCO10_BBJ).

Sumber: Trade Table resmi ([[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]]).

**Jangan disamakan dengan:** [[KB-Node-AkunMini-StorageRolloverFee]] (biaya menahan posisi overnight, beda dari komisi transaksi), dan komisi Akun Reguler (USD 15/lot/sisi atau IDR 150.000/lot/sisi di node produk Bilateral — skala berbeda).

---
**Node terkait (navigasi KB):** [[KB-Node-Program-Referral]] · [[KB-Node-Istilah-Trading-Dasar]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Initial-Margin]] · [[KB-Node-AkunMini-Margin-Equity-CallMargin]] · [[KB-Node-AkunMini-BiayaLainLain]] · [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] · [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]]
