# KB Node — Edukasi: Buy/Sell dan Jenis Order

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** penjelasan edukatif umum tentang posisi buy/sell dan jenis order. Bukan saran transaksi.

**Buy dan Sell:**
- **Buy (long):** membuka posisi beli. Untung sementara (floating) jika harga naik dari harga masuk, rugi jika harga turun.
- **Sell (short):** membuka posisi jual. Untung sementara jika harga turun dari harga masuk, rugi jika harga naik.
- Posisi tetap terbuka sampai ditutup. Selama terbuka, untung/rugi masih floating dan berubah mengikuti harga.

**Jenis order (konsep umum):**
- **Market order:** dieksekusi pada harga berjalan saat itu.
- **Pending order (limit/stop):** dieksekusi jika harga mencapai level yang ditentukan.
- **Stop Loss dan Take Profit:** batas rugi dan target mengunci keuntungan (definisi di [[KB-Node-Istilah-Trading-Dasar]]).

Spesifikasi kontrak per produk mencantumkan "Range Limit & Stop Order" (contoh Gold Akun Mini: USD 6–USD 20) — lihat node spesifikasi produk. Akun Mini membatasi net open posisi maksimal 0,9 lot.

**Belum ada data resmi:** daftar fitur order yang tersedia di Aplikasi Solid dan cara memakainya.

**Jangan disamakan dengan:** [[KB-Node-Istilah-Trading-Dasar]] (definisi istilah), atau arahan kapan harus buy/sell — node ini tidak memberi sinyal atau target harga.

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Edukasi-Manajemen-Risiko]] · [[KB-Node-Edukasi-Ebook]] · [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] · [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]]
