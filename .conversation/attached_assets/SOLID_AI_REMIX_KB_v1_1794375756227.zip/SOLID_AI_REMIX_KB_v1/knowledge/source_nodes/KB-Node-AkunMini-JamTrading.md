# KB Node — Akun Mini: Jam Trading

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** jam perdagangan Gold & Brent Oil untuk Akun Mini.

| Item | Gold/Emas (XUL10) | Brent Oil (BCO10_BBJ) |
|---|---|---|
| Hari Trading | Senin – Jumat | Senin – Jumat |
| Jam Trading (Waktu Panas/DST/Summer) | 06:00 – 03:30 WIB | 07:00 – 03:45 WIB |
| Jam Trading (Waktu Dingin/Winter) | 06:00 – 04:30 WIB | 08:00 – 03:45 WIB |

Jam perdagangan dapat berubah sewaktu-waktu — sumber resmi & terbaru: [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]].

**Jangan disamakan dengan:** node spesifikasi kontrak ([[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]], [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]]) — node ini murni jam trading, bukan margin/spread/storage fee.

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]]
