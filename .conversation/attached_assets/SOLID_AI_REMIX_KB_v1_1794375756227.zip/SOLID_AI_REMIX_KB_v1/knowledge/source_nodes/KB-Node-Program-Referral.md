# KB Node — Program Referral SG Solid

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** cara kerja program referral SG Solid (ajak teman daftar).

**Kata kunci pencarian:** referral, kode referral, link referral, ajak teman, undang teman, bonus referral, komisi referral.

**Cara kerja:**
1. Nasabah mendapatkan link atau kode referral dari akun SG Solid miliknya.
2. Link/kode itu dibagikan ke calon nasabah yang memenuhi ketentuan.
3. Calon nasabah mendaftar akun trading melalui link/kode referral tersebut (pendaftaran tetap lewat Aplikasi Solid — lihat [[KB-Node-Alur-Pendaftaran-Akun-Real]]).
4. Benefit/komisi referral diberikan **sesuai syarat, ketentuan, dan kebijakan program yang berlaku**.

**Penting:** benefit referral adalah benefit program, **bukan imbal hasil investasi** dan tidak terkait hasil trading. Jangan menyebutnya sebagai "penghasilan pasif" atau "keuntungan pasti".

**Belum ada data resmi:** besaran benefit/komisi referral, syarat penerima referral, di menu mana kode referral ditemukan di aplikasi, dan kapan benefit dibayarkan. Kalau user tanya detail ini, jangan menebak — arahkan ke tim resmi.

Sumber: materi banner Program Referral SG Solid (dokumen internal Knowledge Promosi/Banner v1.0, Bagian 3).

**Jangan disamakan dengan:** komisi transaksi ([[KB-Node-AkunMini-Komisi-Transaksi]]) — itu biaya yang dibayar nasabah saat bertransaksi, bukan benefit referral.

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Profil-Perusahaan]] · [[KB-Node-Sumber-Resmi-Kontak]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]]
