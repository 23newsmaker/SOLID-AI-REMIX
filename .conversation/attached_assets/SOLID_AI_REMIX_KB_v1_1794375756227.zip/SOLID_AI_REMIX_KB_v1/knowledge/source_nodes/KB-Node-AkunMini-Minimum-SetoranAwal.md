# KB Node — Akun Mini: Minimum Setoran Awal (Buka Akun Baru)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** minimum dana yang wajib disetor untuk MEMBUKA Akun Mini baru (bukan top-up ke akun yang sudah aktif — lihat node berbeda di bawah).

**Minimum Setoran Awal Akun Mini: IDR 5.000.000, setara USD 500 (Fixed Rate 1 USD = IDR 10.000).**

Sumber: dokumen internal "Spesifikasi Produk Mini Mikro Solid"; juga tercantum di Trading Rules Bagian VIII.1 — *"Pembukaan Account Mini wajib melalui Pendaftaran Online dengan Deposit Margin awal minimum sebesar USD 500 (lima ratus dolar Amerika) dengan Fixed Rate (1 USD = IDR 10.000)."*

Berlaku untuk pertanyaan seperti: "modal awal berapa?", "minimal deposit buat buka akun berapa?", "berapa buat mulai/daftar?".

**PENTING — jangan disamakan dengan:**
- [[KB-Node-AkunMini-Minimum-TopUp]] — Rp10.000, untuk NAMBAH DANA ke akun yang **sudah aktif**, bukan untuk buka akun baru. Ini fakta yang paling sering tertukar dengan node ini — cek dulu apakah user tanya soal BUKA akun baru (pakai node ini) atau NAMBAH dana ke akun yang sudah ada (pakai node top-up).
- [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] — Rp10.000.000/transaksi & Rp20.000.000/bulan, ini batas ATAS, topik berbeda dari minimum setoran awal.

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Kurs-FixedRate-USD-IDR]] · [[KB-Node-AkunMini-Contoh-Perhitungan]] · [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]] · [[KB-Node-AkunMini-Initial-Margin]]
