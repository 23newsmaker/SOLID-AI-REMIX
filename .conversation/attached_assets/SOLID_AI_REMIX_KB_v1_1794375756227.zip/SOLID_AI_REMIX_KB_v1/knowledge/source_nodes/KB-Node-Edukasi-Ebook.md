# KB Node — Edukasi: Ebook Resmi

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** materi edukasi trading dalam bentuk ebook, resmi dari PT Solid Gold Berjangka.

**Kata kunci pencarian:** ebook, e-book, buku panduan, materi belajar, bahan bacaan, belajar trading.

**Link resmi ebook edukasi:** https://mini.sg-berjangka.com/id/education/ebook

**Kapan boleh dipakai:** kalau user minta materi belajar tambahan, bahan bacaan, panduan trading yang lebih lengkap, atau bertanya apakah ada ebook/e-book/buku panduan — chatbot cukup membagikan link di atas.

**Contoh jawaban:** *"Ada, kak. {{organizationName}} punya ebook edukasi trading yang bisa kakak baca di sini: https://mini.sg-berjangka.com/id/education/ebook. Bisa dipelajari dulu sebelum mulai trading."*

Kalau user tanya judul atau isi ebook secara spesifik, arahkan ke link di atas — jangan menebak atau merangkum isinya.

**Jangan disamakan dengan:**
- [[KB-Node-Sumber-Resmi-Kontak]] — kumpulan link resmi lain (website utama, legalitas, Aplikasi Solid); link ebook juga dicatat di sana.
- [[KB-Node-Istilah-Trading-Dasar]], [[KB-Node-Edukasi-Buy-Sell-dan-Jenis-Order]], [[KB-Node-Edukasi-Manajemen-Risiko]] — materi edukasi yang sudah tertulis langsung di KB.

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]]
