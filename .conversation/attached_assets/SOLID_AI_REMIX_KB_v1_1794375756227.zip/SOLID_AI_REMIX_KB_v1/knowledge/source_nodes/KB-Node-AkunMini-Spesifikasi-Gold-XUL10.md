# KB Node — Akun Mini: Spesifikasi Kontrak Gold (XUL10)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** spesifikasi kontrak Gold/Emas Akun Mini (Trade Code XUL10, Fixed Rate).

| Item | Ketentuan |
|---|---|
| Contract Size | 10 Troy Ounce |
| Initial Margin (Day Trade) | USD 100/lot |
| Spread Kuotasi | Min. USD 0,40 dan maks. USD 1,00 per Troy Ounce per sisi. Saat pasar sangat bergejolak (hectic), mengikuti pasar |
| Minimum Pergerakan Harga | USD 0,01/Troy Ounce |
| Range Limit & Stop Order | USD 6 – USD 20. Saat hectic, mengikuti pasar |
| Sumber Harga | Telequote (Price Guidance: Last Trade) |
| Penyelesaian | Cash Settlement |
| Lot mini per transaksi | 0,1–0,9 |
| Maks. Net Open Posisi | 0,9 Lot |

Sumber: Trade Table resmi ([[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]]). Lot mini 0,1–0,9 dan maks. net open posisi bersumber dari dokumen internal Spesifikasi Produk Akun Mini (tidak tercantum di Trade Table).

Facility fee (komisi) dan rollover: lihat [[KB-Node-AkunMini-Komisi-Transaksi]] dan [[KB-Node-AkunMini-StorageRolloverFee]]. Margin: [[KB-Node-AkunMini-Initial-Margin]]. Jam trading: [[KB-Node-AkunMini-JamTrading]].

**⚠️ PENTING — kode kontrak "XUL10" dipakai untuk DUA produk berbeda:** kode **XUL10** juga dipakai untuk produk **Emas Loco London di Akun Reguler** (skala penuh, margin & komisi jauh lebih besar) — lihat [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]]. **Jangan pernah pakai angka margin/komisi dari node Akun Reguler itu untuk menjawab pertanyaan Akun Mini, atau sebaliknya** — selalu pastikan dulu ke user itu Akun Mini atau Akun Reguler sebelum menjawab angka.

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] (produk berbeda), atau spesifikasi Gold Akun **Reguler** skala penuh di [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] (angka jauh lebih besar, jangan dicampur — lihat peringatan di atas).

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Daftar-Produk-Karakteristik]] · [[KB-Node-Edukasi-Buy-Sell-dan-Jenis-Order]]
