# 🔒 AUDIENCE: INTERNAL — Ringkasan Restrukturisasi Node KB (17 September 2026)

Dokumen ringkasan untuk tim BD/Product/Compliance. Ini adalah rekap lengkap hasil kerja pemecahan Knowledge Base jadi node-node kecil, sesuai permintaan: *"knowledge dipecah pecah node node kecil untuk mempermudah dan memperjelas knowledgenya"*.

**Catatan tentang dokumen ini:** ini BUKAN pengganti field "Context"/custom instructions Project (field itu tidak bisa diedit lewat tool yang saya pakai — lihat catatan di bagian paling bawah). Ini adalah dokumen ringkasan biasa yang tersimpan di Project, isinya laporan hasil kerja.

---

## 1. Apa yang berubah

Seluruh isi 4 dokumen KB lama (Master KB + 3 KB Tambahan) dipecah jadi **33 dokumen node** — satu node = satu topik/fakta spesifik — supaya lebih mudah dicari, diverifikasi, dan diupdate satu-satu tanpa risiko mengubah dokumen besar.

4 dokumen lama **tidak dihapus** (supaya tidak merusak sync eksternal yang mungkin masih merujuk nama file-nya), tapi isinya sudah diganti jadi halaman **redirect** — cuma berisi daftar pointer ke node pengganti:
- `SOLID-GOLD-BERJANGKA-MASTER-KB-v1-8-1.md`
- `KB-Tambahan-Legalitas-Perizinan-v1-1.md`
- `KB-Tambahan-Akun-Reguler-v1-8.md`
- `KB-Tambahan-Biaya-Swap-Margin-v1-2-1.md`

`System Prompt` (Bagian 17, plus referensi di 0A/16.1/19/20/21) sudah diupdate merujuk ke node baru, bukan lagi ke nomor bagian dokumen lama. [[00-INDEX-Peta-Dokumen-KB-1]] dan `INTERNAL-Catatan-Compliance-BD.md` juga sudah diupdate mengikuti struktur baru ini.

## 2. Peta 33 Node (7 klaster)

**A. Profil & Sumber Resmi (2 node)**
[[KB-Node-Profil-Perusahaan]], [[KB-Node-Sumber-Resmi-Kontak]]

**B. Legalitas (2 node)**
[[KB-Node-Legalitas-Lembaga-Pengawas]], [[KB-Node-Legalitas-Daftar-Izin]]

**C. Overview Jenis Akun & Istilah (4 node)**
[[KB-Node-JenisAkun-Mini-Overview]], [[KB-Node-JenisAkun-Reguler-Overview]], [[KB-Node-Daftar-Produk-Karakteristik]], [[KB-Node-Istilah-Trading-Dasar]]

**D. Akun Mini — Biaya/Margin/Spesifikasi (9 node)**
[[KB-Node-AkunMini-Minimum-SetoranAwal]], [[KB-Node-AkunMini-Minimum-TopUp]], [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]], [[KB-Node-AkunMini-Margin-Equity-CallMargin]], [[KB-Node-AkunMini-Komisi-Transaksi]], [[KB-Node-AkunMini-StorageRolloverFee]], [[KB-Node-AkunMini-BiayaLainLain]], [[KB-Node-AkunMini-JamTrading]], [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] ⚠️, [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] ⚠️

**E. Akun Reguler — Multilateral (6 node)**
[[KB-Node-AkunReguler-Multilateral-Olein-OLE]], `-Emas250Gram-GOL250`, `-Emas1Kg-GOL`, `-KopiArabika-ACF`, `-KopiRobusta-RCF`, `-CatatanMarginKomisi` (catatan: margin/komisi Multilateral belum ada data resmi)

**F. Akun Reguler — Bilateral (9 node)**
[[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]], `-IndeksJepang-JPK`, `-EmasLocoLondon-XUL10-XULF` ⚠️, `-MinyakBrent-BCO10-BCOF` ⚠️, `-GBPUSD`, `-EURUSD`, `-AUDUSD`, `-USDCHF`, `-USDJPY`

⚠️ = node yang saling terkait dengan risiko tertukar kode produk (lihat poin 4).

**Catatan teknis:** semua 33 node di atas otomatis tersimpan dengan prefix `claude/` di path-nya (mis. path aslinya `claude/KB-Node-Profil-Perusahaan.md`) — ini efek teknis dari sistem penyimpanan dokumen Project saat menulis file baru, bukan penamaan yang saya sengaja. Dokumen lama (yang sudah ada sebelumnya) tetap di path root tanpa prefix. Tidak mempengaruhi isi/retrieval, cuma relevan kalau nanti ada yang mengatur struktur folder Project.

## 3. Diskrepansi data yang masih perlu keputusan Compliance (4 item)

| # | Topik | Dua angka yang beda | Status |
|---|---|---|---|
| 1 | Ukuran kontrak Gold XUL10 | Trade Table: 10 Troy Ounce vs Dok internal: 100 Troy Ounce | Belum direkonsiliasi — dipakai 100 Troy Ounce (angka live) |
| 2 | Ukuran kontrak Brent Oil BCO10_BBJ | Trade Table: 100 Barrel vs Dok internal: framing USD 1.000/Barrel | Belum direkonsiliasi — dipakai angka live |
| 3 | Komisi Akun Mini | KB lama: USD 1/0,1 Lot + PPN 11% vs Trade Table: Facility Fee USD 1,5/lot/side + PPN 11% | Belum direkonsiliasi — dipakai angka live |
| 4 | **[Baru ditemukan saat restrukturisasi]** Kode kontrak XUL10 & BCO10_BBJ dipakai identik di Akun Mini DAN Akun Reguler Bilateral, dengan angka margin yang jauh berbeda (contoh: XUL10 Akun Mini = USD 100/Lot daytrade; XUL10 Reguler Bilateral = USD 1.000/lot harian, USD 3.000/lot menginap) | — | Mitigasi sudah dipasang di chatbot (node + System Prompt), tapi perlu keputusan Compliance apakah perlu penyesuaian di sistem trading/UI juga supaya CS dan customer di luar chatbot juga tidak tertukar |

Detail lengkap tiap item ada di `INTERNAL-Catatan-Compliance-BD.md` Bagian 6a.

## 4. Soal permintaan "hapus Context yang ada, masukin yang baru"

Sudah saya cek — Project ini punya field description/custom instructions terpisah dari daftar dokumen (yang biasanya disebut "Project instructions" di claude.ai), dan field itu memang **masih kosong**. Tapi tool yang saya pakai untuk kerja di Project ini cuma bisa baca/tulis/hapus DOKUMEN, tidak punya akses untuk mengubah field description/instructions tersebut secara langsung.

Jadi kalau BD mau field itu diisi dengan ringkasan restrukturisasi ini, tolong copy-paste isi dokumen ini (atau minta saya buatkan versi lebih ringkas) ke field "Project instructions"/description di halaman setting Project di claude.ai secara manual. Saya sudah simpan versi lengkapnya di dokumen ini supaya tinggal disalin.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]]
