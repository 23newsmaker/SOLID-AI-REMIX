# KB Node — Deposit dan Withdrawal: Data yang Tersedia dan Belum Tersedia

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** apa saja yang sudah dan belum ada datanya soal deposit dan withdrawal.

**Data yang tersedia (Akun Mini):**

| Item | Ketentuan | Node |
|---|---|---|
| Minimum setoran awal buka akun baru | IDR 5.000.000 / USD 500 | [[KB-Node-AkunMini-Minimum-SetoranAwal]] |
| Minimum top-up akun aktif | Rp10.000 via transfer bank, semua jenis akun | [[KB-Node-AkunMini-Minimum-TopUp]] |
| Batas maksimal setoran/top-up | Rp10.000.000 per transaksi, Rp20.000.000 per bulan | [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] |
| Withdrawal: estimasi waktu, syarat, tahapan | Standar sampai T+3 hari kerja, diupayakan T+1 (bukan jaminan); diajukan di jam perbankan, maks. sebesar effective margin, rekening tujuan atas nama nasabah | [[KB-Node-Withdrawal-Prosedur-dan-Estimasi-Waktu]] |
| Kanal deposit | Hanya lewat kanal resmi perusahaan (termasuk Aplikasi Solid) atau instruksi tim resmi; jangan transfer ke rekening pribadi atau pihak yang tidak jelas | — |

**Belum ada data resmi:**
- Biaya deposit, biaya withdrawal, biaya akun inaktif (lihat [[KB-Node-AkunMini-BiayaLainLain]])
- Nomor rekening tujuan deposit resmi
- Batas minimum/maksimum nominal withdrawal dan jam perbankan persisnya

Untuk item yang belum ada datanya, jangan menebak angka atau waktu.

**Jangan disamakan dengan:** minimum setoran awal vs minimum top-up vs batas maksimal — tiga angka berbeda, pakai yang sesuai konteks pertanyaan.

---
**Node terkait (navigasi KB):** [[KB-Node-Withdrawal-Prosedur-dan-Estimasi-Waktu]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Kurs-FixedRate-USD-IDR]] · [[KB-Node-AkunMini-Contoh-Perhitungan]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]]
