# KB Node — Produk Bilateral: AUD/USD (AU1010_BBJ & AU10F_BBJ)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak & biaya (margin, komisi, rollover) untuk pasangan forex AUD/USD — tersedia di **Akun Reguler**, kategori Bilateral (SPA). Dua varian: kurs tetap (IDR) dan kurs mengambang (USD).

| Item | AU1010_BBJ (Kurs Tetap, IDR) | AU10F_BBJ (Kurs Mengambang, USD) |
|---|---|---|
| Satuan Kontrak | AUD 100.000 | AUD 100.000 |
| Jam Perdagangan | Senin–Jumat. Summer 07:00–03:00 WIB; Winter 07:00–04:00 WIB | Senin–Jumat. Summer 07:00–03:00 WIB; Winter 07:00–04:00 WIB |
| Margin Transaksi Harian | IDR 10.000.000/lot | USD 1.000/lot |
| Margin Transaksi Menginap | IDR 20.000.000/lot | USD 2.000/lot |
| Komisi | IDR 150.000/lot/sisi | USD 15/lot/sisi |
| Biaya Rollover Jual/Beli | IDR 50.000/lot/malam | USD 5/lot/malam |
| PPN | 11% dari komisi & biaya | 11% dari komisi & biaya |
| Maintenance Margin | 70% dari kebutuhan margin | 70% dari kebutuhan margin |
| Auto Liquidasi | 30% dari kebutuhan margin | 30% dari kebutuhan margin |
| Spread Kuotasi Minimum | 4 pips/sisi | 4 pips/sisi |
| Pergerakan Harga Minimum | 0,0001 pip (tick value USD 10) | 0,0001 pip (tick value USD 10) |
| Rentang Limit & Stop Order | 20–2.000 poin/pips | 20–2.000 poin/pips |
| Penyelesaian | Cash Settlement | Cash Settlement |

**Jangan disamakan dengan:**
- Pasangan forex lain di Akun Reguler Bilateral: [[KB-Node-AkunReguler-Bilateral-GBPUSD]], [[KB-Node-AkunReguler-Bilateral-EURUSD]], [[KB-Node-AkunReguler-Bilateral-USDCHF]], [[KB-Node-AkunReguler-Bilateral-USDJPY]].
- Tidak ada produk forex di Akun Mini.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 2.7.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]] · [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]] · [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] · [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]]
