# KB Node — Kendala Login: OTP Tidak Masuk, Lupa Password & Akun Terkunci

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** apa yang bisa dicek sendiri oleh nasabah kalau OTP tidak masuk, dan kapan harus dibantu tim CS (lupa password, akun terkunci).

**Kata kunci pencarian:** OTP tidak masuk, OTP belum masuk, kode OTP, kode verifikasi tidak terkirim, tidak dapat OTP, lupa password, lupa kata sandi, akun terkunci, akun terblokir, tidak bisa login, gagal login.

**Ke mana OTP dikirim:** OTP (One Time Password, kata sandi sekali pakai saat login) dikirim melalui **SMS** ke nomor HP dan **E-Mail** sesuai data saat pembukaan rekening (Trading Rules); default OTP Akun Mini **via E-Mail** (lihat [[KB-Node-AkunMini-Margin-Equity-CallMargin]]).

**Kalau OTP tidak masuk — langkah yang bisa dicek sendiri:**
1. **Periksa folder Spam/Junk** (dan tab Promosi/Updates kalau pakai Gmail) di email yang terdaftar.
2. Pastikan yang dicek adalah **email dan nomor HP yang didaftarkan** saat pembukaan rekening.
3. Untuk OTP via SMS: pastikan sinyal HP baik dan kotak masuk SMS tidak penuh.
4. Tunggu beberapa saat, lalu minta kirim ulang OTP kalau tersedia di aplikasi.

Kalau setelah dicek OTP tetap tidak masuk → hubungkan ke tim CS di chat ini (eskalasi sesuai System Prompt Bagian 10).

**Lupa password / akun terkunci:** belum ada data resmi soal langkah reset mandiri — langsung hubungkan ke tim CS di chat ini, jangan menebak langkah reset.

**Keamanan (dari Trading Rules):** User ID, Password, dan OTP bersifat **pribadi dan rahasia** — jangan diberikan ke pihak lain, termasuk pihak yang mengaku dari PT Solid Gold Berjangka. Chatbot dan tim CS **tidak pernah** meminta password, PIN, atau kode OTP lewat chat. Kalau user mau mengetik OTP/password di chat, ingatkan untuk tidak mengirimnya.

**Contoh jawaban:** *"Coba cek dulu folder Spam/Junk di email yang kakak daftarkan ya, kadang OTP masuk ke sana. Pastikan juga email dan nomor HP yang dicek sama dengan yang didaftarkan, dan kalau lewat SMS, cek sinyalnya. Kalau sudah dicek tapi tetap belum masuk, aku bantu hubungkan ke tim CS di sini. Satu lagi kak, kode OTP jangan dikirim ke siapa pun termasuk di chat ini ya."*

**Belum ada data resmi:** berapa lama OTP berlaku, berapa kali boleh kirim ulang, langkah reset password di aplikasi, dan penyebab/cara membuka akun terkunci.

Sumber: arahan BD (13 Okt 2026) untuk OTP tidak masuk; kanal OTP & aturan kerahasiaan dari [[Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026]] (Bagian ketentuan transaksi poin 4 & ketentuan User ID/Password/OTP).

**Jangan disamakan dengan:** [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]] (tanda penipuan, termasuk pihak yang meminta OTP) dan [[KB-Node-Alur-Pendaftaran-Akun-Real]] (proses daftar akun, bukan kendala login).

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Sumber-Resmi-Kontak]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]]
