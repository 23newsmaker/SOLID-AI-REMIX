# KNOWLEDGE BASE TAMBAHAN — Legalitas & Perizinan (REDIRECT — lihat Node)

> **AUDIENCE: PUBLIC.** **Isi lengkap dokumen ini sudah dipecah menjadi node-node kecil per topik** (restrukturisasi September 2026). Gunakan node-node di bawah sebagai evidence utama. Peta lengkap seluruh node: [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan kapan boleh sebut nomor izin, safe answer, dan larangan interpretasi ("legal = pasti aman") ada di [[System Prompt]]

**PT Solid Gold Berjangka — Redirect Legalitas**

## Node Pengganti Bagian 1 (Lembaga Pengawas)
→ [[KB-Node-Legalitas-Lembaga-Pengawas]]

## Node Pengganti Bagian 2 (Tabel Legalitas & Perizinan — 10 baris nomor izin)
→ [[KB-Node-Legalitas-Daftar-Izin]]

---

Dokumen terkait: [[SOLID_GOLD_BERJANGKA_MASTER_KB_v1_8_1]] (redirect), [[Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026]] (izin No. 10 di [[KB-Node-Legalitas-Daftar-Izin]] adalah landasan legal mekanisme CDD Sederhana yang diatur teknisnya di sana).

Untuk aturan kapan/bagaimana chatbot boleh mengutip nomor izin, lihat [[System Prompt]].
