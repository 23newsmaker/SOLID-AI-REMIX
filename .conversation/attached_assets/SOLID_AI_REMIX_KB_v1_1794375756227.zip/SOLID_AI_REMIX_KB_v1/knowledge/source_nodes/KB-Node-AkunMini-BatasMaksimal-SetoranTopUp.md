# KB Node — Akun Mini: Batas Maksimal Setoran/Top-Up

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** batas ATAS/maksimal untuk setoran margin awal maupun top-up margin — topik berbeda dari minimum (lihat node lain di bawah).

Dari Trading Rules Bagian VIII.9 (kutipan resmi): *"Nasabah dalam melakukan setoran margin awal (deposit margin) maupun penambahan dana (top-up margin) dapat dilakukan melalui pemindahbukuan antar rekening bank atas nama Nasabah bersangkutan ke Rekening Terpisah (segregated account) PT Solid Gold Berjangka, dengan ketentuan paling banyak Rp10.000.000,- (sepuluh juta rupiah) dalam satu kali transaksi dan total nilai transaksi maksimal Rp20.000.000,- (dua puluh juta rupiah) dalam 1 (satu) bulan."*

**Ringkas:**
- Maksimal **Rp10.000.000 per transaksi**.
- Maksimal **Rp20.000.000 total per bulan**.
- Berlaku untuk setoran margin awal maupun top-up margin (penambahan dana), via pemindahbukuan antar rekening bank.

Berlaku untuk pertanyaan seperti: "ada batas maksimal top-up?", "boleh transfer berapa sekali jalan?".

**PENTING — jangan disamakan dengan:**
- [[KB-Node-AkunMini-Minimum-SetoranAwal]] — IDR 5.000.000/USD 500, minimum untuk buka akun baru.
- [[KB-Node-AkunMini-Minimum-TopUp]] — Rp10.000, minimum untuk nambah dana ke akun aktif.
- Node ini soal batas ATAS, bukan minimum — jangan campur dalam satu jawaban kalau user cuma tanya salah satunya.

Sumber resmi lengkap: `Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026` Bagian VIII poin 9.

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Kurs-FixedRate-USD-IDR]] · [[KB-Node-AkunMini-Contoh-Perhitungan]] · [[KB-Node-Deposit-Withdrawal-Status-Data]]
