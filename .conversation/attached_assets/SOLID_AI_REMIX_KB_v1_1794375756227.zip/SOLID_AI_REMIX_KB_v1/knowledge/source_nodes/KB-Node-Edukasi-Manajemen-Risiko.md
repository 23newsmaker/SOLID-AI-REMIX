# KB Node — Edukasi: Manajemen Risiko Dasar

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** prinsip dasar mengelola risiko dalam trading berjangka.

- **Leverage memperbesar untung dan rugi.** Perubahan harga kecil bisa berdampak besar pada modal.
- **Pakai dana dingin,** yaitu dana yang siap menanggung risiko. Bukan uang pinjaman dan bukan dana kebutuhan harian.
- **Mulai kecil.** Akun Mini memakai lot mini 0,1–0,9, dan mewajibkan latihan di akun demo (minimal 2 kali transaksi) sebelum akun real.
- **Stop Loss membantu membatasi rugi,** tetapi tidak menjamin bebas rugi karena market bisa bergerak cepat.
- **Ketahui batas akun.** Akun Mini punya call margin 70% equity dan auto liquidation 30% equity, sehingga posisi bisa ditutup otomatis. Detail: [[KB-Node-AkunMini-Margin-Equity-CallMargin]].
- **Hindari all-in dan mengejar rugi.** Menambah lot untuk membalas kerugian memperbesar risiko.
- **Tidak ada jaminan profit.** Hasil bergantung pada market, strategi, ukuran transaksi, dan disiplin manajemen risiko.

**Jangan disamakan dengan:** [[KB-Node-Istilah-Trading-Dasar]] (definisi istilah) dan sinyal atau arahan transaksi — node ini prinsip umum, bukan saran untuk transaksi tertentu.

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Edukasi-Buy-Sell-dan-Jenis-Order]] · [[KB-Node-Edukasi-Ebook]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]]
