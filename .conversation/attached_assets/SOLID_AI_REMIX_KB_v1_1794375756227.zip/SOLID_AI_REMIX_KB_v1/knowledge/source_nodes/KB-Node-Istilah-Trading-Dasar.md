# KB Node — Istilah Trading Dasar

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** definisi istilah trading dasar (edukatif umum, bukan angka spesifik produk).

- **Margin** — dana jaminan untuk membuka posisi; besarnya tergantung produk dan ketentuan akun.
- **Leverage** — fasilitas mengakses nilai transaksi lebih besar dari modal disetor; memperbesar peluang sekaligus risiko.
- **Lot** — satuan ukuran transaksi; makin besar lot, makin besar potensi hasil dan risiko.
- **Spread** — selisih harga beli dan jual; berbeda tergantung produk dan kondisi market.
- **Floating Profit/Loss** — untung/rugi sementara selama posisi masih terbuka.
- **Auto Liquidation** — penutupan posisi otomatis saat margin/ekuitas turun ke batas tertentu (detail batas per jenis akun: lihat [[KB-Node-AkunMini-Margin-Equity-CallMargin]] untuk Akun Mini).
- **Stop Loss** — batas rugi untuk kontrol risiko; tidak menjamin bebas rugi karena market bisa bergerak cepat.
- **Per side (per sisi)** — biaya dikenakan di tiap sisi transaksi: membuka posisi = 1 sisi, menutup posisi = 1 sisi. Contoh: komisi Akun Mini tercatat USD 1,5/lot/sisi, jadi satu kali buka + tutup posisi = 2 sisi = 2 × USD 1,5 = USD 3 per lot (+ PPN 11%). Cara penghitungan untuk lot mini 0,1–0,9 belum ada data resmi — jangan dihitung sendiri. Angka komisi resmi: [[KB-Node-AkunMini-Komisi-Transaksi]].
- **Take Profit** — target harga mengunci keuntungan; penentuan target harus berdasarkan rencana dan risiko.

**Jangan disamakan dengan:** angka margin/auto-liquidation spesifik per jenis akun — istilah di sini definisi umum saja, angka pastinya ada di node biaya masing-masing jenis akun.

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Edukasi-Buy-Sell-dan-Jenis-Order]] · [[KB-Node-Edukasi-Manajemen-Risiko]] · [[KB-Node-Edukasi-Ebook]] · [[KB-Node-AkunMini-Initial-Margin]]
