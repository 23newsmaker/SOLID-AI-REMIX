# KB Node — Topik yang Belum Ada Data Resminya

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** daftar topik yang sering ditanya tetapi datanya belum ada di KB, dan apa yang sudah bisa dijawab untuk tiap topik.

| Topik | Status data | Yang sudah tersedia |
|---|---|---|
| Minimum setoran awal Akun Reguler | Belum ada data resmi | Ketentuan Akun Mini: IDR 5.000.000 / USD 500 (jangan dipakai untuk Akun Reguler) |
| Margin dan komisi produk Multilateral | Belum ada data resmi | Spesifikasi kontrak resmi bursa, lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]] |
| Jam operasional CS dan live chat | Belum ada data resmi | Kontak resmi: +62 821-2665-636 (WA Only), email opt.mini@solidgold.co.id, live chat ini (lihat [[KB-Node-Sumber-Resmi-Kontak]]) |
| Jadwal libur trading | Belum ada data resmi | Jam trading harian per produk (lihat node jam trading) |
| Prosedur pengaduan dan penyelesaian perselisihan | Belum ada data resmi | Kontak resmi perusahaan dan lembaga pengawas, lihat [[KB-Node-Legalitas-Lembaga-Pengawas]] |
| Perlindungan/pemisahan dana nasabah | Belum ada data resmi | Daftar lembaga pengawas dan bursa/kliring, lihat [[KB-Node-Legalitas-Lembaga-Pengawas]] |
| Daftar dokumen pendaftaran dan estimasi waktu verifikasi | Belum ada data resmi | Tahapan pendaftaran, lihat [[KB-Node-Alur-Pendaftaran-Akun-Real]] |
| Langkah reset password, membuka akun terkunci, masa berlaku OTP | Belum ada data resmi | Langkah cek OTP tidak masuk (spam, dst.) & eskalasi ke CS, lihat [[KB-Node-Kendala-Login-OTP-Password]] |
| Biaya deposit/withdrawal, batas nominal withdrawal | Belum ada data resmi | Prosedur & estimasi waktu withdrawal sudah ada: [[KB-Node-Withdrawal-Prosedur-dan-Estimasi-Waktu]]; ringkasan lain di [[KB-Node-Deposit-Withdrawal-Status-Data]] |

Untuk topik di tabel ini, jangan mengarang angka, jam, atau prosedur.

**Jangan disamakan dengan:** node yang datanya sudah lengkap — cek node produk/biaya terkait dulu sebelum menyimpulkan datanya tidak ada.

---
**Node terkait (navigasi KB):** [[KB-Node-AkunMini-BiayaLainLain]] · [[KB-Node-Sumber-Resmi-Kontak]] · [[KB-Node-AkunMini-JamTrading]]
