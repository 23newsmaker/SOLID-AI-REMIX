# KB Node — Produk Bilateral: Indeks Jepang (JPK50_BBJ & JPK5U_BBJ)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak & biaya (margin, komisi, rollover) untuk produk Indeks Jepang — tersedia di **Akun Reguler**, kategori Bilateral (SPA). Dua varian: kurs tetap (IDR) dan kurs mengambang (USD).

| Item | JPK50_BBJ (Kurs Tetap, IDR) | JPK5U_BBJ (Kurs Mengambang, USD) |
|---|---|---|
| Ukuran Kontrak | IDR 50.000/poin | USD 5/poin |
| Jam Perdagangan | Senin–Jumat: Sesi I 06:30–13:55, Sesi II 14:10–03:45 WIB | Senin–Jumat: Sesi I 06:30–13:55, Sesi II 14:10–03:45 WIB |
| Margin Transaksi Harian | IDR 10.000.000/lot | USD 1.000/lot |
| Margin Transaksi Menginap | IDR 20.000.000/lot | USD 2.000/lot |
| Komisi | IDR 150.000/lot/sisi | USD 15/lot/sisi |
| Biaya Menginap Jual/Beli | IDR 20.000/lot/malam | USD 2/lot/malam |
| PPN | 11% dari komisi & biaya menginap | 11% dari komisi & biaya menginap |
| Maintenance Margin | 70% dari kebutuhan margin | 70% dari kebutuhan margin |
| Auto Liquidasi | 30% dari kebutuhan margin | 30% dari kebutuhan margin |
| Spread Kuotasi Minimum | 10 poin/sisi | 10 poin/sisi |
| Pergerakan Harga Minimum | 5 poin | 5 poin |
| Rentang Limit & Stop Order | 20–500 poin | 20–500 poin |
| Penyelesaian | Cash Settlement | Cash Settlement |

**Jangan disamakan dengan:**
- **Bukan** Indeks Hong Kong (JPK ≠ HKK, jam perdagangan & biaya menginap berbeda) — lihat [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]].
- Ini produk **Akun Reguler** (Bilateral/SPA), margin & komisi milik PT Solid Gold Berjangka sendiri.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 2.2.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] · [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]] · [[KB-Node-AkunReguler-Bilateral-GBPUSD]] · [[KB-Node-AkunReguler-Bilateral-EURUSD]] · [[KB-Node-AkunReguler-Bilateral-AUDUSD]] · [[KB-Node-AkunReguler-Bilateral-USDCHF]] · [[KB-Node-AkunReguler-Bilateral-USDJPY]]
