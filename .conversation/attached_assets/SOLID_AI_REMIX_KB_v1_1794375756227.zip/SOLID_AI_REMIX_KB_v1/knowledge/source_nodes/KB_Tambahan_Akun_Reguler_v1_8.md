# KNOWLEDGE BASE TAMBAHAN — Spesifikasi Produk Multilateral & Bilateral (Akun Reguler) (REDIRECT — lihat Node)

> **AUDIENCE: PUBLIC.** **Isi lengkap dokumen ini sudah dipecah menjadi node-node kecil per produk** (restrukturisasi September 2026) — termasuk penandaan tegas untuk produk yang kodenya sama dengan Akun Mini tapi skalanya berbeda total (Emas Loco London "XUL10" & Minyak Brent "BCO10_BBJ"). Gunakan node-node di bawah sebagai evidence utama. Peta lengkap seluruh node: [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). **Bukan** dokumen untuk Akun Mini — untuk Akun Mini lihat `KB_Tambahan_Biaya_Swap_Margin_v1_2_1` (redirect).

**PT Solid Gold Berjangka — Redirect Akun Reguler**

## Node Pengganti Bagian 1 (Produk Multilateral/JFX)
→ [[KB-Node-AkunReguler-Multilateral-Olein-OLE]]
→ [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]]
→ [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]]
→ [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]]
→ [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]]
→ [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]] (catatan: margin/komisi Multilateral belum tercakup data resmi)

## Node Pengganti Bagian 2 (Produk Bilateral/SPA)
→ [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]]
→ [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]]
→ [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] (⚠️ kode XUL10 sama dengan Gold Akun Mini — skala beda total)
→ [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]] (⚠️ kode BCO10_BBJ sama dengan Brent Oil Akun Mini — skala beda total)
→ [[KB-Node-AkunReguler-Bilateral-GBPUSD]]
→ [[KB-Node-AkunReguler-Bilateral-EURUSD]]
→ [[KB-Node-AkunReguler-Bilateral-AUDUSD]]
→ [[KB-Node-AkunReguler-Bilateral-USDCHF]]
→ [[KB-Node-AkunReguler-Bilateral-USDJPY]]

---

Dokumen terkait: [[SOLID_GOLD_BERJANGKA_MASTER_KB_v1_8_1]] (redirect, Bagian 3.1) · Akun Mini: `KB_Tambahan_Biaya_Swap_Margin_v1_2_1` (redirect), [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]], [[Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026]]

Untuk aturan kapan/bagaimana chatbot boleh mengutip angka di atas, dan kenapa jangan mencampur dengan angka Akun Mini, lihat [[System Prompt]].
