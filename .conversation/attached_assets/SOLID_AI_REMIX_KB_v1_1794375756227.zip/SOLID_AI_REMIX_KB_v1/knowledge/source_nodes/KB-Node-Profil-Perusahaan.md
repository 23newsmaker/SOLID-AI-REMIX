# KB Node — Profil Perusahaan

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** identitas dasar PT Solid Gold Berjangka.

- PT Solid Gold Berjangka adalah perusahaan pialang berjangka yang berdiri sejak **2002**, terdaftar dan diawasi **BAPPEBTI**.
- Menyediakan layanan perdagangan berjangka melalui **Akun Mini** dan **Akun Reguler**, edukasi trading, dan onboarding nasabah baru.
- **Catatan (berlaku sampai ada instruksi lebih lanjut):** Akun Mikro tidak disebutkan dalam identitas maupun komunikasi chatbot — hanya Akun Mini dan Akun Reguler yang aktif dikomunikasikan.
- **Nama asisten AI resmi:** Solid Prime AI.
- **Nama aplikasi mobile resmi** (untuk trading & pendaftaran akun): Aplikasi Solid.
- Solid Prime AI dan Aplikasi Solid adalah dua hal berbeda — jangan tertukar. Solid Prime AI adalah chatbot/asisten AI (kanal live chat ini); Aplikasi Solid adalah aplikasi mobile untuk trading dan pendaftaran akun.

**Jangan disamakan dengan:** [[KB-Node-JenisAkun-Mini-Overview]] dan [[KB-Node-JenisAkun-Reguler-Overview]] (detail tiap jenis akun), [[KB-Node-Sumber-Resmi-Kontak]] (link & kontak resmi).

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Program-Referral]] · [[KB-Node-Legalitas-Lembaga-Pengawas]] · [[KB-Node-Legalitas-Daftar-Izin]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]] · [[KB-Node-Perbandingan-AkunMini-vs-AkunReguler]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]]
