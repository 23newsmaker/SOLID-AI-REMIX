# KB Node — Akun Mini: Storage/Rollover Fee

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** biaya menahan posisi trading terbuka melewati jam tutup pasar harian (overnight), untuk produk Akun Mini.

**Konsep:** Swap (kadang disebut rollover fee) adalah biaya/kredit yang dikenakan saat posisi dibiarkan terbuka melewati batas waktu penutupan pasar harian. Di broker forex konvensional, besarnya biasanya berubah tiap hari mengikuti selisih suku bunga antar mata uang.

**Fakta khusus PT Solid Gold Berjangka:** biaya ini disebut **Storage/Rollover Fee** (di Trade Table resmi: **Rollover Facility**) dan ditetapkan sebagai nilai **tetap (flat)** oleh perusahaan per produk — bukan mengikuti selisih suku bunga harian seperti swap forex konvensional. PT Solid Gold Berjangka tidak memakai mekanisme swap forex konvensional. Trading Gold/Emas (XUL10) dan Brent Oil (BCO10_BBJ) adalah produk komoditas (logam mulia dan minyak), bukan produk forex — jadi istilah "swap" (dari mekanisme forex) memang tidak berlaku secara kategori untuk kedua produk ini. Istilah resmi: **Storage/Rollover Fee**.

**Angka (Akun Mini, Gold & Brent Oil):**

| Produk | Rollover Buy | Rollover Sell |
|---|---|---|
| Gold/Emas (XUL10) | USD 0,5/lot/malam + PPN 11% dari Rollover Facility | USD 0,5/lot/malam + PPN 11% dari Rollover Facility |
| Brent Oil (BCO10_BBJ) | USD 0,5/lot/malam + PPN 11% dari Rollover Facility | USD 0,5/lot/malam + PPN 11% dari Rollover Facility |

Sumber: Trade Table resmi ([[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]]), baris Rollover Facility.

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Komisi-Transaksi]] (komisi per transaksi, dikenakan tiap buka posisi — bukan biaya menahan posisi overnight).

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Initial-Margin]] · [[KB-Node-AkunMini-Margin-Equity-CallMargin]] · [[KB-Node-AkunMini-BiayaLainLain]] · [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] · [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]]
