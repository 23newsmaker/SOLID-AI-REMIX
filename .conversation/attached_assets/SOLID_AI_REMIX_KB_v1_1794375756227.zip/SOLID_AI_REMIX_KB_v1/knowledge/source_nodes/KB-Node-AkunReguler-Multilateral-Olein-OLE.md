# KB Node — Produk Multilateral: Kontrak Berjangka Olein (OLE)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak resmi Bursa Berjangka Jakarta (JFX) untuk produk Olein (kode kontrak OLE) — tersedia di **Akun Reguler**, kategori Multilateral.

| Item | Ketentuan |
|---|---|
| Kode Kontrak | OLE |
| Dasar Kontrak | Olein dengan kualitas Standar Pasar |
| Satuan Kontrak | 20 ton (20.000 Kg) |
| Bulan Kontrak | 6 bulan berturut-turut (setiap hari perdagangan ada 6 Bulan Kontrak) |
| Hari & Jam Perdagangan | Setiap hari perdagangan, pukul 09.30–17.30 WIB |
| Perubahan Harga Minimum | Rp 5/kg (termasuk PPN) = Rp 100.000/lot (termasuk PPN) |
| Batas Perubahan Harga | Rp 150/kg di atas/bawah Harga Penyelesaian hari sebelumnya (tidak berlaku untuk Bulan Berjalan/Bulan Terdekat) |
| Penyelesaian Akhir | Penyerahan DO Terdaftar kualitas Standar Pasar |
| Satuan Penyerahan | 20 ton, toleransi + 2% |
| Posisi Wajib Lapor | 150 lot |
| Batas Posisi | 500 lot |

**Catatan margin/komisi:** margin dan komisi khusus PT Solid Gold Berjangka untuk produk Multilateral (termasuk Olein) belum tercakup di data resmi yang tersedia. Kalau user tanya margin/komisi spesifik produk ini, jawab spesifikasi kontraknya saja (tabel di atas) dan eskalasikan — lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]].

**Jangan disamakan dengan:**
- Ini produk **Akun Reguler** (kategori Multilateral/JFX) — beda dari **Akun Mini**, yang hanya mencakup Gold (XUL10) & Brent Oil (BCO10_BBJ) skala mini lot 0,1–0,9. Lihat [[KB-Node-JenisAkun-Reguler-Overview]] vs [[KB-Node-JenisAkun-Mini-Overview]].
- Produk Multilateral lain (beda komoditas, jangan tertukar): [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]], [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]], [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]], [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]].

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 1.1.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]]
