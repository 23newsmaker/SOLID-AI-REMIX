# KB Node — Akun Mini: Equity, Call Margin & Auto Liquidation

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** batas equity, call margin, dan prosedur auto liquidation untuk Akun Mini. (Untuk minimum setoran awal, lihat [[KB-Node-AkunMini-Minimum-SetoranAwal]] — angka itu TIDAK diulang di sini supaya tidak ada dua sumber untuk fakta yang sama.)

| Item | Ketentuan |
|---|---|
| Maks. Equity | IDR 25.000.000 / USD 2.500 |
| Maks. Warning Equity | IDR 23.000.000 / USD 2.300 |
| Call Margin Level | 70% Equity |
| ABS Level (Auto Liquidation) | 30% Equity |
| Prosedur ABS | Locking → Hold → Open → ABS → FIFO |
| CBS (Clear By Sistem) | Berdasarkan rasio equity |
| Default OTP | Via Email |

Sumber: dokumen internal "Spesifikasi Produk Mini Mikro Solid". Definisi regulatori lengkap (Maintenance Margin, Margin Call, Auto Liquidation) ada di `Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026` Bagian III.

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Minimum-SetoranAwal]] (minimum setoran buka akun, bukan batas equity berjalan).

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Initial-Margin]] · [[KB-Node-AkunMini-Komisi-Transaksi]] · [[KB-Node-AkunMini-StorageRolloverFee]] · [[KB-Node-AkunMini-BiayaLainLain]] · [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]] · [[KB-Node-Edukasi-Manajemen-Risiko]] · [[KB-Node-Istilah-Trading-Dasar]]
