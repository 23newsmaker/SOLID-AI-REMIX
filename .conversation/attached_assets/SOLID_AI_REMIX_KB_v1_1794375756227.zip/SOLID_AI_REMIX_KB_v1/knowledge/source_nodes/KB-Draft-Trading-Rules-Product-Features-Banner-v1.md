# 🔒 AUDIENCE: INTERNAL — Knowledge Promosi (Materi Banner & Fitur SG Solid)

**PT Solid Gold Berjangka (SG Solid) — Knowledge Base: Trading Rules, Product Features & Transaction Procedures**

> **Tentang dokumen ini:** disusun dari kompilasi 12 banner promosi SG Solid + informasi tambahan yang diberikan tim, untuk mendokumentasikan pesan dan klaim yang ada di materi promosi secara konsisten. **Ketentuan resmi tetap merujuk ke dokumen pembukaan rekening, spesifikasi kontrak, kebijakan perusahaan, bursa/kliring, dan regulasi yang berlaku** — dokumen ini adalah knowledge seputar materi promosi, bukan sumber utama angka biaya/kontrak.
>
> Versi 1.0 | 11 September 2026 | Sumber: kompilasi 12 banner SG Solid + info tambahan.
>
> **Dokumen terkait (Cluster A–G):** [[KB-Node-Profil-Perusahaan]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-AkunMini-Minimum-SetoranAwal]] · [[KB-Node-AkunMini-Komisi-Transaksi]] · [[KB-Node-AkunMini-StorageRolloverFee]] · peta lengkap ada di [[00-INDEX-Peta-Dokumen-KB-1]] (Cluster H).

> **Update 8 Okt 2026 — sudah dipecah ke node PUBLIC:** Withdrawal → [[KB-Node-Withdrawal-Prosedur-dan-Estimasi-Waktu]] · Referral → [[KB-Node-Program-Referral]] · Market Overview, TradePilot, Akun Demo → [[KB-Node-Fitur-Aplikasi-Solid]] · arti "per side" → [[KB-Node-Istilah-Trading-Dasar]]. ⚠️ Komisi USD 0,5/side (Bagian 11) dan spread 0,2/side (Bagian 9) **bertentangan** dengan [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]] (komisi USD 1,5/lot/side; spread Gold USD 0,40–1,00, Brent USD 0,10–0,30) — tidak dimasukkan ke node sampai dikonfirmasi.

---

## Ringkasan (At a Glance)

Ringkasan ini memisahkan aturan transaksi, fitur aplikasi, program pendukung, dan informasi korporat agar tidak tercampur.

| Topik | Ketentuan / Informasi Utama | Kategori |
|---|---|---|
| Akun Reguler | Forex, komoditas, dan indeks. | Produk/akun |
| Akun Mini | Komoditas Emas dan Brent Crude Oil; produk lain direncanakan menyusul. Ukuran transaksi mulai 0,1 lot; materi tambahan menyebut akses awal sekitar Rp5 juta. | Produk/akun |
| Market Overview | Berita dan informasi pergerakan pasar di aplikasi secara realtime, 24 jam/5 hari. | Fitur |
| Biaya inap | Posisi yang melewati batas waktu perdagangan dapat dikenakan biaya inap flat 0,5 per side. | Trading rule |
| Spread | Materi banner mencantumkan spread 0,2/side. | Trading cost |
| Komisi | USD 0,5 per side + PPN 11%. | Trading cost |
| Withdrawal | Saat jam perbankan; tidak melebihi effective margin; rekening tujuan harus atas nama nasabah; standar T+3, diupayakan T+1. | Prosedur |
| Demo | Latihan transaksi tanpa deposit menggunakan akun demo. | Fitur |
| Referral | Program referral dengan link/kode referral dan benefit sesuai syarat dan ketentuan yang berlaku. | Program |
| TradePilot | Sarana analisis/informasi pendukung untuk membantu memahami kondisi pasar. | Tools |

**Cara membaca dokumen ini** — tiap item ditandai salah satu kategori: **RULE** (aturan transaksi/biaya), **FEATURE** (fitur aplikasi), **PROGRAM** (program & S&K), **CORPORATE** (informasi perusahaan).

---

## 1–3. Akun, Produk & Program Referral

### 1. Market Dinamis — Pilih Akun Sesuai Kebutuhan `FEATURE`

- SG Solid menyediakan dua pendekatan akun dengan cakupan produk berbeda:
  - **Akun Reguler**: akses transaksi pada produk forex, komoditas, dan indeks. Detail lengkap: [[KB-Node-JenisAkun-Reguler-Overview]].
  - **Akun Mini**: saat ini berfokus pada komoditas Emas dan Brent Crude Oil; produk lain direncanakan rilis bertahap. Detail lengkap: [[KB-Node-JenisAkun-Mini-Overview]].
  - Materi banner juga menonjolkan eksekusi cepat, spread yang lebih terukur, keamanan data, serta analisa dan edukasi sebagai fitur layanan.
- **Penggunaan yang tepat:** jenis akun dan produk yang tersedia harus dicek kembali pada aplikasi dan dokumen spesifikasi produk terbaru — lihat [[KB-Node-Daftar-Produk-Karakteristik]]. Jangan menganggap materi promosi sebagai jaminan hasil transaksi.

### 2. Akun Mini Mulai 0,1 Lot `RULE`

- Akun Mini memungkinkan transaksi mulai dari ukuran 0,1 lot.
- Informasi tambahan menyebut akses awal sekitar **Rp5 juta**. Nominal aktual tetap mengikuti kebutuhan margin, harga pasar, dan ketentuan produk — angka resmi & rincian syarat buka akun ada di [[KB-Node-AkunMini-Minimum-SetoranAwal]] (IDR 5.000.000 / USD 500).
- Ukuran lot yang lebih kecil memberi fleksibilitas pengaturan eksposur, tetapi tidak menghilangkan risiko kerugian.

### 3. Program Referral SG Solid `PROGRAM`

- Pengguna memperoleh link atau kode referral dari akun SG Solid.
- Link/kode referral dapat dibagikan kepada calon pengguna yang memenuhi ketentuan.
- Calon pengguna mendaftar akun trading melalui referral tersebut.
- Benefit/komisi referral mengikuti syarat, ketentuan, dan kebijakan program yang berlaku.
- **Catatan compliance:** materi referral sebaiknya tidak dikomunikasikan sebagai imbal hasil investasi. Pisahkan jelas antara benefit program referral dan hasil aktivitas trading.

---

## 4–7. Informasi Pasar, Posisi Menginap & Fleksibilitas Transaksi

### 4. Realtime Market Overview `FEATURE`

- Market Overview menyediakan informasi berita ekonomi, komoditas, indeks, forex, dan pergerakan pasar di dalam aplikasi.
- Informasi tersedia secara realtime dengan cakupan operasional 24 jam/5 hari.
- Fungsi utama: membantu pengguna memantau konteks pasar tanpa harus berpindah platform.
- **Bukan sinyal transaksi:** Market Overview adalah informasi/edukasi pendukung. Keputusan transaksi tetap perlu mempertimbangkan kondisi pasar, profil risiko, dan analisis pengguna.

### 5. Posisi Menginap & Biaya Inap `RULE`

- Posisi yang melewati batas waktu perdagangan dapat dikenakan biaya inap.
- Biaya inap disebut flat **0,5 per side** pada informasi tambahan yang diberikan.
- Karena istilah "per side" berarti biaya pada masing-masing sisi transaksi, detail satuan dan metode perhitungan harus mengikuti spesifikasi kontrak yang berlaku — lihat [[KB-Node-AkunMini-StorageRolloverFee]] untuk angka resmi Storage/Rollover Fee Akun Mini.
- **Perbedaan istilah:** biaya inap (overnight/swap) berbeda dari spread dan komisi transaksi. Ketiganya perlu dijelaskan terpisah agar nasabah memahami komponen biaya. Definisi umum istilah-istilah ini ada di [[KB-Node-Istilah-Trading-Dasar]].

### 6. Margin Terukur, Lot Lebih Fleksibel `RULE`

- Kapasitas transaksi dapat dimulai dari 0,1 lot untuk produk/akun yang mendukung.
- Margin adalah dana yang diperlukan untuk membuka dan mempertahankan posisi, bukan biaya yang otomatis hilang.
- Kebutuhan margin dapat berubah mengikuti harga, ukuran posisi, dan spesifikasi produk. Angka margin resmi Akun Mini ada di [[KB-Node-AkunMini-Margin-Equity-CallMargin]].

### 7. Lebih dari 20 Tahun Melayani `CORPORATE`

- Materi banner menyebut SG Solid telah beroperasi sejak 2002 dan memiliki pengalaman lebih dari 20 tahun — konsisten dengan [[KB-Node-Profil-Perusahaan]].
- Informasi ini merupakan profil perusahaan dan tidak boleh diposisikan sebagai jaminan keuntungan atau bebas risiko.

---

## 8. Withdrawal yang Transparan

Prosedur penarikan dana perlu dijelaskan secara konsisten karena menyangkut akses dana nasabah dan validasi rekening.

**Informasi umum:** Penarikan dana dapat diajukan oleh nasabah selama jam perbankan dengan ketentuan jumlah penarikan tidak melebihi effective margin yang tercantum pada laporan transaksi harian (statement report).

**Tahapan penarikan dana:**

| # | Tahap | Detail |
|---|---|---|
| 1 | Masuk ke menu Withdrawal | Masuk ke menu withdrawal pada akun transaksi riil dan ajukan permohonan sesuai syarat/ketentuan. |
| 2 | Isi formulir | Lengkapi formulir penarikan dan pastikan data rekening tujuan benar. |
| 3 | Validasi rekening | Rekening tujuan wajib atas nama nasabah yang sama dengan Dokumen Aplikasi Pembukaan Rekening Nasabah. |
| 4 | Proses | Standar proses sampai T+3 hari kerja; perusahaan mengupayakan penyelesaian T+1. |

**Checklist sebelum submit:** nama rekening sama dengan nama nasabah; nilai penarikan tidak melampaui effective margin; pengajuan pada jam perbankan; estimasi dihitung dalam hari kerja.

**Terminologi:** "Diupayakan T+1" bukan jaminan setiap withdrawal selesai T+1. SLA final mengikuti kondisi operasional dan ketentuan yang berlaku.

*(Belum ada node KB-Node terpisah untuk withdrawal saat ini — kalau nanti dipecah jadi node PUBLIC, topik ini jadi kandidat node baru di Cluster D/klaster biaya Akun Mini.)*

---

## 9–11. Biaya Transaksi & Akun Demo

Tiga komponen yang perlu dibedakan: spread, komisi, dan biaya inap.

### 9. Spread 0,2/Side `RULE`

- Materi banner mencantumkan spread **0,2/side** sebagai biaya trading yang lebih terukur.
- Spread adalah selisih harga jual (bid) dan beli (ask). Nilai aktual harus mengacu pada spesifikasi produk dan kondisi pasar — lihat [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] dan [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] untuk angka spread resmi per produk.

### 10. Akun Demo — Mulai Tanpa Deposit `FEATURE`

- Akun demo digunakan untuk mempelajari alur transaksi dan fitur platform tanpa melakukan deposit dana riil.
- Hasil simulasi demo tidak selalu identik dengan kondisi akun riil, termasuk dari sisi eksekusi, likuiditas, dan psikologi transaksi.

### 11. Komisi USD 0,5/Side + PPN 11% `RULE`

- Komisi transaksi: **USD 0,5 per side + PPN 11%**, sesuai informasi tambahan yang diberikan.
- Istilah "per side" menunjukkan pembebanan pada tiap sisi transaksi. Total biaya aktual tetap mengikuti volume transaksi dan metode perhitungan resmi — lihat [[KB-Node-AkunMini-Komisi-Transaksi]] untuk angka komisi resmi Akun Mini yang sudah dipakai chatbot.
- Komisi berbeda dari spread dan biaya inap — jangan menggabungkannya menjadi satu angka tanpa dasar perhitungan.

**Ringkasan komponen biaya (menurut dokumen ini):**

| Komponen | Angka pada materi | Kapan relevan | Catatan |
|---|---|---|---|
| Spread | 0,2/side | Saat transaksi | Nilai aktual mengikuti spesifikasi/kondisi pasar. |
| Komisi | USD 0,5/side + PPN 11% | Saat transaksi | Metode total mengikuti volume dan ketentuan resmi. |
| Biaya inap | Flat 0,5/side | Jika posisi melewati batas waktu perdagangan | Satuan dan cut-off harus mengikuti spesifikasi kontrak. |

**Wajib verifikasi:** istilah singkat seperti "0,2/side" atau "0,5/side" harus dilengkapi spesifikasi kontrak resmi yang menjelaskan satuan, basis perhitungan, dan waktu pembebanan.

---

## 12. TradePilot & Tools Pendukung `FEATURE`

Tools pendukung membantu memahami pasar, tetapi tidak menggantikan keputusan dan manajemen risiko pengguna.

- TradePilot diposisikan sebagai sarana untuk memantau perkembangan pasar dan informasi pendukung di luar sekadar melihat chart.
- Platform dapat digunakan sebagai alat bantu analisis/insight untuk memahami kondisi pasar sebelum mengambil keputusan.
- Output analisis bukan jaminan arah pasar dan tidak boleh diperlakukan sebagai kepastian profit.

**Fitur pendukung lain dari banner:**

| Fitur | Deskripsi |
|---|---|
| Eksekusi cepat `FEATURE` | Banner utama menonjolkan pengalaman eksekusi cepat. Klaim performa teknis harus mengikuti kondisi sistem dan konektivitas aktual. |
| Keamanan data `FEATURE` | Keamanan data ditampilkan sebagai salah satu nilai layanan. Detail standar keamanan mengikuti kebijakan dan implementasi perusahaan. |
| Analisa & edukasi `FEATURE` | Materi edukasi dan analisa disediakan untuk membantu pemahaman pasar; bukan ajakan transaksi. |
| 24/5 market news `FEATURE` | Informasi pasar tersedia lima hari dalam seminggu mengikuti hari perdagangan pasar global. |

**Prinsip penggunaan tools:** semua insight, berita, market overview, atau tools analisis merupakan informasi pendukung. Pengguna tetap perlu menilai risiko, ukuran posisi, kemampuan keuangan, dan kesesuaian strategi.

---

## FAQ Internal — Cara Menjelaskan Rules ke Pengguna

*(Panduan operasional — bahasa sederhana untuk CS, edukasi, konten, atau knowledge base internal.)*

**Apa bedanya Akun Reguler dan Akun Mini?**
Akun Reguler memiliki cakupan produk forex, komoditas, dan indeks. Akun Mini saat ini berfokus pada Emas dan Brent Crude Oil dengan ukuran transaksi mulai 0,1 lot. (Detail: [[KB-Node-JenisAkun-Reguler-Overview]], [[KB-Node-JenisAkun-Mini-Overview]].)

**Apakah Rp5 juta adalah biaya?**
Bukan. Informasi yang diberikan menyebut akses awal sekitar Rp5 juta untuk Akun Mini. Kebutuhan dana aktual dipengaruhi margin, harga pasar, dan ukuran posisi. (Angka resmi: [[KB-Node-AkunMini-Minimum-SetoranAwal]].)

**Apa arti per side?**
Per side berarti per sisi transaksi. Pembukaan dan penutupan posisi merupakan sisi yang berbeda; perhitungan final tetap mengikuti ketentuan produk.

**Apakah biaya inap sama dengan komisi?**
Tidak. Biaya inap berlaku pada posisi yang melewati batas waktu perdagangan, sedangkan komisi merupakan biaya transaksi. Spread juga komponen yang berbeda. (Lihat [[KB-Node-AkunMini-StorageRolloverFee]] vs [[KB-Node-AkunMini-Komisi-Transaksi]].)

**Apakah withdrawal pasti T+1?**
Tidak. Mekanisme standar disebut T+3, sementara perusahaan mengupayakan T+1. Penyelesaian aktual mengikuti hari kerja dan proses operasional.

**Bolehkah tarik dana ke rekening orang lain?**
Tidak. Rekening tujuan harus atas nama nasabah yang sama dengan dokumen pembukaan rekening.

**Apakah Market Overview atau TradePilot adalah sinyal pasti?**
Tidak. Keduanya merupakan informasi/alat bantu analisis. Keputusan transaksi dan risikonya tetap menjadi tanggung jawab pengguna.

**Apakah akun demo sama dengan akun riil?**
Tidak sepenuhnya. Demo membantu latihan alur dan fitur, tetapi kondisi eksekusi dan psikologi pengguna pada akun riil dapat berbeda.

**Kalimat yang sebaiknya dihindari:** hindari frasa yang menjanjikan "pasti untung", "tanpa risiko", "withdrawal pasti T+1", "spread selalu tetap", atau "analisis pasti benar". Gunakan bahasa yang sesuai ketentuan dan kondisi aktual.

---

## Governance — Sumber Materi, Disclaimer & Kontrol Versi

Bagian ini menjaga agar knowledge tetap konsisten dan mudah diperbarui ketika ada perubahan produk atau biaya.

**Pemetaan 12 banner ke knowledge:**

| No. | Tema Banner | Informasi yang Masuk Knowledge |
|---|---|---|
| 01 | Market Dinamis | Akun Reguler & Akun Mini; cakupan produk; fitur layanan. |
| 02 | Akun Mini 0,1 Lot | Ukuran transaksi minimum; fleksibilitas akun. |
| 03 | Referral | Alur referral dan benefit sesuai S&K. |
| 04 | Realtime Market Overview | Berita/informasi pasar realtime 24 jam/5 hari. |
| 05 | Posisi Menginap | Biaya inap flat untuk posisi yang melewati batas waktu. |
| 06 | Margin Terukur | Margin dan fleksibilitas lot. |
| 07 | 20+ Tahun | Informasi profil perusahaan sejak 2002. |
| 08 | Withdrawal | Syarat, rekening tujuan, dan SLA penarikan dana. |
| 09 | Spread | Spread 0,2/side pada materi banner. |
| 10 | Demo | Latihan trading tanpa deposit. |
| 11 | Komisi | USD 0,5/side + PPN 11%. |
| 12 | TradePilot | Tools analisis/informasi pendukung. |

**Disclaimer risiko:** Perdagangan berjangka memiliki risiko tinggi. Informasi dalam dokumen ini bersifat edukasi dan referensi, bukan ajakan transaksi atau jaminan keuntungan. Pengguna wajib memahami karakteristik produk, biaya, margin, dan risiko sebelum melakukan transaksi. Setiap keputusan transaksi menjadi tanggung jawab nasabah.

**Hierarki rujukan ketika ada perbedaan informasi (dari dokumen sumber):**

1. Dokumen pembukaan rekening/perjanjian nasabah
2. Spesifikasi kontrak & biaya terbaru
3. Kebijakan perusahaan serta bursa/kliring/regulator
4. Knowledge internal ini (dokumen ini)
5. Materi banner/promosi

**Kontrol versi:** Versi 1.0 | 11 Sep 2026 | Draft Internal | Kompilasi 12 banner + informasi tambahan. Final check diperlukan sebelum penggunaan eksternal.

**Posisi dalam peta KB:** dokumen ini adalah Cluster H di [[00-INDEX-Peta-Dokumen-KB-1]] — terhubung ke node Cluster A–G lewat referensi silang di seluruh bagian di atas, tapi tetap berstatus INTERNAL dan belum masuk Data Source chatbot.

---

*Dokumen ini dikonversi dari PDF "SG_Solid_Knowledge_Trading_Rules.pdf" (upload BD, 21 September 2026) tanpa mengubah isi/urutan aslinya — berfungsi sebagai knowledge promosi (dokumentasi materi banner & fitur SG Solid), bukan sumber angka biaya/kontrak resmi. Referensi silang ke node lain ditambahkan 21 September 2026 supaya dokumen ini terhubung ke peta Knowledge Base yang sudah ada.*