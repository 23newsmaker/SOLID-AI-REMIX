# KB Node — Akun Mini: Contoh Perhitungan

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** contoh hitung angka Akun Mini dari ketentuan yang sudah ada di KB. Ini ilustrasi perhitungan, bukan proyeksi hasil trading. Contoh mencakup konversi setoran, batas top-up, dan batas equity.

**1. Konversi setoran awal.** Minimum setoran awal USD 500 x Rp10.000 (Fixed Rate 1 USD = IDR 10.000) = Rp5.000.000.

**2. Batas top-up bulanan.** Batas maksimal Rp10.000.000 per transaksi dan Rp20.000.000 per bulan.
- Top-up Rp8.000.000, lalu Rp8.000.000 lagi = Rp16.000.000 dalam sebulan. Masih di bawah batas bulanan.
- Menambah Rp5.000.000 lagi jadi Rp21.000.000, melewati batas Rp20.000.000. Sisa ruang bulan itu Rp4.000.000.
- Top-up USD 300 = Rp3.000.000, sudah memenuhi minimum top-up Rp10.000 dan di bawah batas per transaksi.

**3. Batas equity.** Maks. Equity USD 2.500 = Rp25.000.000 dengan Fixed Rate 1 USD = IDR 10.000.

Contoh biaya dan margin per lot (Initial Margin, Facility Fee, Rollover Facility) belum disertakan di node ini. Angka per lot-nya ada di [[KB-Node-AkunMini-Initial-Margin]], [[KB-Node-AkunMini-Komisi-Transaksi]], dan [[KB-Node-AkunMini-StorageRolloverFee]].

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Margin-Equity-CallMargin]] (aturan call margin dan auto liquidation), [[KB-Node-Kurs-FixedRate-USD-IDR]] (sumber Fixed Rate). Contoh ini hanya untuk Akun Mini, bukan Akun Reguler.

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Minimum-SetoranAwal]] · [[KB-Node-AkunMini-Minimum-TopUp]] · [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] · [[KB-Node-Deposit-Withdrawal-Status-Data]]
