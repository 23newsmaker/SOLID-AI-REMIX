# KB Node — TradePilot: Alat Bantu Analisis Berbasis AI di Aplikasi Solid

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** apa itu TradePilot dan batas pemakaiannya di akun demo vs akun real.

**Kata kunci pencarian:** TradePilot, Trade Pilot, AI analisis, analisa AI, alat bantu analisis, token TradePilot, kuota TradePilot, limit TradePilot, TradePilot demo, TradePilot akun real.

**Apa itu TradePilot:** TradePilot adalah **alat bantu analisis berbasis AI** di Aplikasi Solid, untuk membantu memantau perkembangan pasar dan memahami kondisi pasar di luar sekadar melihat chart.

**Batas pemakaian (token):**

| Jenis akun | Batas token TradePilot |
|---|---|
| Akun Demo | **10 token** |
| Akun Real | **Unlimited (tanpa batas)** |

**Batasan penting (wajib disampaikan kalau relevan):**
- Hasil analisis TradePilot adalah **informasi pendukung**, **bukan sinyal buy/sell**, **bukan jaminan arah pasar**, dan **bukan kepastian profit**.
- Keputusan transaksi dan risikonya tetap di tangan nasabah.
- Jangan membingkai akses unlimited di akun real sebagai alasan untuk segera membuka akun real atau deposit — sampaikan sebagai fakta saja, tanpa dorongan/urgensi.

**Contoh jawaban:** *"TradePilot itu alat bantu analisis berbasis AI di Aplikasi Solid, kak, buat bantu memahami kondisi pasar. Di akun demo jatahnya 10 token, sedangkan di akun real tidak dibatasi. Tapi perlu diingat, hasil analisisnya bukan sinyal buy/sell dan bukan jaminan profit ya — keputusan transaksinya tetap di tangan kakak."*

**Belum ada data resmi:** 1 token dipakai untuk apa (mis. per satu analisis/pertanyaan), apakah 10 token di akun demo berlaku sekali saja atau di-reset berkala, cara mengakses/letak menu TradePilot di aplikasi, instrumen apa saja yang bisa dianalisis, dan apakah ada biaya. Kalau user tanya detail ini, jangan menebak — sampaikan belum ada infonya dan tawarkan hubungkan ke tim CS di chat ini.

Sumber: informasi dari BD (13 Okt 2026); deskripsi umum juga dari materi banner (dokumen internal Knowledge Promosi/Banner v1.0, Bagian 12).

**Jangan disamakan dengan:**
- **Solid Prime AI** — asisten AI di live chat ini (menjawab pertanyaan seputar perusahaan, produk, dan proses), bukan TradePilot. TradePilot adalah fitur analisis pasar di dalam Aplikasi Solid. Lihat [[KB-Node-Profil-Perusahaan]].
- **Market Overview** — berita/pergerakan pasar realtime, fitur berbeda di aplikasi yang sama. Lihat [[KB-Node-Fitur-Aplikasi-Solid]].
- Sinyal trading/rekomendasi transaksi — TradePilot bukan sinyal. Lihat [[KB-Node-Edukasi-Buy-Sell-dan-Jenis-Order]].

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]] · [[KB-Node-Edukasi-Manajemen-Risiko]] · [[KB-Node-Istilah-Trading-Dasar]]
