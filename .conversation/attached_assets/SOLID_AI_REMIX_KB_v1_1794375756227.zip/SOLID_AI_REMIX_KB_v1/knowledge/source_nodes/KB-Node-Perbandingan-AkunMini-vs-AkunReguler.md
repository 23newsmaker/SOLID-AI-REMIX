# KB Node — Perbandingan Akun Mini vs Akun Reguler

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** ringkasan perbedaan Akun Mini dan Akun Reguler di PT Solid Gold Berjangka. Hanya dua jenis akun ini yang aktif dikomunikasikan.

| Aspek | Akun Mini | Akun Reguler |
|---|---|---|
| Gambaran | Nilai transaksi lebih ringan; cocok untuk mulai belajar dengan nominal lebih kecil | Untuk nasabah yang lebih siap secara pengalaman dan modal; skala transaksi lebih besar, dukungan penuh tim |
| Skala lot | Lot mini 0,1–0,9 per transaksi; maks. net open posisi 0,9 lot | Skala lot penuh |
| Produk | Gold/Emas (XUL10) dan Brent Oil (BCO10_BBJ) | Multilateral (JFX): Olein, Emas 250 Gram, Emas 1 Kg, Kopi Arabika, Kopi Robusta. Bilateral (SPA): Indeks Hong Kong, Indeks Jepang, Emas Loco London, Minyak Brent, GBP/USD, EUR/USD, AUD/USD, USD/CHF, USD/JPY |
| Produk forex | Tidak ada | Ada (Bilateral) |
| Minimum setoran awal | IDR 5.000.000 / USD 500 | Belum ada data resmi |
| Margin | Initial Margin USD 100/lot (day trade), lihat [[KB-Node-AkunMini-Initial-Margin]] | Per produk dan jauh lebih besar. Bilateral: ada di node produk (contoh Indeks Hong Kong margin harian IDR 10.000.000/lot atau USD 1.000/lot). Multilateral: belum ada data |
| Komisi | Facility Fee USD 1,5/lot/sisi + PPN 11% | Per produk. Bilateral, contoh: USD 15/lot/sisi atau IDR 150.000/lot/sisi |

Akun Reguler bisa mengakses produk Multilateral maupun Bilateral dalam satu akun.

**Peringatan kode kontrak:** kode XUL10 (Gold) dan BCO10_BBJ (Brent Oil) dipakai di kedua jenis akun dengan skala margin dan komisi yang sangat berbeda. Selalu pastikan jenis akunnya sebelum menyebut angka.

**Jangan disamakan dengan:** angka detail masing-masing akun — lihat [[KB-Node-JenisAkun-Mini-Overview]], [[KB-Node-JenisAkun-Reguler-Overview]], dan node produk masing-masing. Node ini hanya ringkasan perbandingan.

---
**Node terkait (navigasi KB):** [[KB-Node-Daftar-Produk-Karakteristik]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] · [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] · [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] · [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]]
