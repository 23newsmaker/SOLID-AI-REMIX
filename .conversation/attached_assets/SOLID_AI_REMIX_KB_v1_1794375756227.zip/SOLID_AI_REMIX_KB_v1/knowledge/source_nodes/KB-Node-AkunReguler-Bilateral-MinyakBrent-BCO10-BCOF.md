# KB Node — Produk Bilateral: Minyak Brent (BCO10_BBJ & BCOF_BBJ)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak & biaya (margin, komisi, rollover) untuk produk Minyak Brent — tersedia di **Akun Reguler**, kategori Bilateral (SPA), skala penuh. Dua varian: kurs tetap (IDR, kode BCO10_BBJ) dan kurs mengambang (USD, kode BCOF_BBJ).

| Item | BCO10_BBJ (Kurs Tetap, IDR) | BCOF_BBJ (Kurs Mengambang, USD) |
|---|---|---|
| Satuan Kontrak | 1.000 Barrel | 1.000 Barrel |
| Jam Perdagangan | Senin–Jumat. Summer 07:00–03:45 WIB; Winter 08:00–03:45 WIB | Senin–Jumat. Summer 07:00–03:45 WIB; Winter 08:00–03:45 WIB |
| Margin Transaksi Harian | IDR 10.000.000/lot | USD 1.000/lot |
| Margin Transaksi Menginap | IDR 20.000.000/lot | USD 2.000/lot |
| Komisi | IDR 150.000/lot/sisi | USD 15/lot/sisi |
| Biaya Menginap Jual/Beli | IDR 50.000/lot/malam | USD 5/lot/malam |
| PPN | 11% dari komisi & biaya menginap | 11% dari komisi & biaya menginap |
| Maintenance Margin | 70% dari kebutuhan margin | 70% dari kebutuhan margin |
| Auto Liquidasi | 30% dari kebutuhan margin | 30% dari kebutuhan margin |
| Spread Kuotasi Min–Maks | USD 0,10–0,30/barrel/sisi | USD 0,10–0,30/barrel/sisi |
| Pergerakan Harga Minimum | USD 0,01/barrel | USD 0,01/barrel |
| Rentang Limit & Stop Order | USD 1–20 | USD 1–20 |
| Penyelesaian | Cash Settlement | Cash Settlement |

**⚠️ PENTING — Risiko tertukar kode produk (perlu perhatian khusus):**

Kode **BCO10_BBJ** di atas adalah untuk produk **Minyak Brent di Akun Reguler** (skala penuh: satuan kontrak 1.000 Barrel, margin harian USD 1.000/lot, komisi USD 15/lot/sisi). Ini **BUKAN** produk Brent Oil yang sama dengan yang dipakai di **Akun Mini** — meski kode kontraknya identik (BCO10_BBJ), produk Akun Mini punya skala dan biaya yang jauh berbeda (menurut Trade Table resmi Akun Mini: Contract Size 100 Barrel, Initial Margin Day Trade USD 100/lot, Facility Fee USD 1,5/lot/sisi). **Jangan pernah menjawab pertanyaan soal margin/komisi Akun Mini pakai angka dari tabel ini, atau sebaliknya** — selalu konfirmasi dulu ke user itu Akun Mini atau Akun Reguler. Lihat [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] untuk versi Akun Mini.

**Jangan disamakan dengan:**
- [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] — Brent Oil Akun Mini, kode sama (BCO10_BBJ) tapi skala & biaya SANGAT berbeda (lihat peringatan di atas).
- [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]] — produk Bilateral lain, komoditas beda.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 2.4.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]] · [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]] · [[KB-Node-AkunReguler-Bilateral-GBPUSD]] · [[KB-Node-AkunReguler-Bilateral-EURUSD]] · [[KB-Node-AkunReguler-Bilateral-AUDUSD]] · [[KB-Node-AkunReguler-Bilateral-USDCHF]] · [[KB-Node-AkunReguler-Bilateral-USDJPY]]
