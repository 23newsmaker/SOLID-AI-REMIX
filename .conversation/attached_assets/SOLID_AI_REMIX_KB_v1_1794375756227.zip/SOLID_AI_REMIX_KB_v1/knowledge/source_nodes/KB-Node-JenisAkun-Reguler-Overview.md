# KB Node — Jenis Akun: Akun Reguler (Overview)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** gambaran umum Akun Reguler (bukan detail spesifikasi produk — lihat node terkait di bawah).

Akun Reguler untuk nasabah yang sudah lebih siap secara pengalaman dan modal, dengan skala transaksi lebih besar dan dukungan penuh dari tim PT Solid Gold Berjangka. Bisa mengakses produk **Multilateral** (kontrak resmi Bursa Berjangka Jakarta/JFX) maupun **Bilateral** (Sistem Perdagangan Alternatif/SPA) dalam satu akun.

**Node detail Produk Multilateral (JFX):**
- [[KB-Node-AkunReguler-Multilateral-Olein-OLE]]
- [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]]
- [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]]
- [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]]
- [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]]
- [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]] — catatan margin/komisi belum tercakup

**Node detail Produk Bilateral (SPA):**
- [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]]
- [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]]
- [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]]
- [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]]
- [[KB-Node-AkunReguler-Bilateral-GBPUSD]]
- [[KB-Node-AkunReguler-Bilateral-EURUSD]]
- [[KB-Node-AkunReguler-Bilateral-AUDUSD]]
- [[KB-Node-AkunReguler-Bilateral-USDCHF]]
- [[KB-Node-AkunReguler-Bilateral-USDJPY]]

**Website khusus Akun Reguler:** https://reguler.sg-berjangka.com — arahkan user ke sini kalau bertanya apakah ada halaman/website Akun Reguler (daftar link resmi lain ada di [[KB-Node-Sumber-Resmi-Kontak]]).

**Jangan disamakan dengan:** [[KB-Node-JenisAkun-Mini-Overview]] (Akun Mini — skala lot mini 0,1–0,9, beda angka margin/komisi). Margin & komisi Akun Reguler jauh lebih besar (skala lot penuh) dibanding Akun Mini — jangan mencampur angka kedua jenis akun ini dalam satu jawaban tanpa menyebut jenis akunnya secara eksplisit.

---
**Node terkait (navigasi KB):** [[KB-Node-Perbandingan-AkunMini-vs-AkunReguler]] · [[KB-Node-Daftar-Produk-Karakteristik]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]]
