# KB Node — Jenis Akun: Akun Mini (Overview)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** gambaran umum Akun Mini (bukan detail biaya/spesifikasi — lihat node terkait di bawah).

Akun Mini adalah jenis akun dengan nilai transaksi lebih ringan dibanding Akun Reguler. Cocok untuk yang ingin mulai belajar trading dengan nominal lebih kecil, tapi tetap perlu memahami risiko leverage dan pergerakan harga.

**Catatan (berlaku sampai ada instruksi lebih lanjut):** Akun Mikro tidak dijelaskan/ditawarkan.

**Node detail Akun Mini lainnya:**
- [[KB-Node-AkunMini-Minimum-SetoranAwal]] — minimum setoran awal buka akun baru
- [[KB-Node-AkunMini-Minimum-TopUp]] — minimum top-up ke akun yang sudah aktif
- [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] — batas maksimal per transaksi & per bulan
- [[KB-Node-AkunMini-Margin-Equity-CallMargin]] — maks equity, call margin, auto liquidation
- [[KB-Node-AkunMini-Komisi-Transaksi]] — komisi per transaksi
- [[KB-Node-AkunMini-StorageRolloverFee]] — biaya menahan posisi overnight
- [[KB-Node-AkunMini-BiayaLainLain]] — biaya deposit/withdrawal/inaktif (belum ada data resmi)
- [[KB-Node-AkunMini-JamTrading]] — jam trading Gold & Brent Oil
- [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]], [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]] — spesifikasi kontrak per produk
- Dokumen regulatori resmi (tidak dipecah): [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]], `Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026`

**Jangan disamakan dengan:** [[KB-Node-JenisAkun-Reguler-Overview]] (Akun Reguler — skala lot penuh, beda produk & beda angka).

---
**Node terkait (navigasi KB):** [[KB-Node-Perbandingan-AkunMini-vs-AkunReguler]] · [[KB-Node-Daftar-Produk-Karakteristik]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-Kurs-FixedRate-USD-IDR]] · [[KB-Node-AkunMini-Contoh-Perhitungan]] · [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-AkunMini-Initial-Margin]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]]
