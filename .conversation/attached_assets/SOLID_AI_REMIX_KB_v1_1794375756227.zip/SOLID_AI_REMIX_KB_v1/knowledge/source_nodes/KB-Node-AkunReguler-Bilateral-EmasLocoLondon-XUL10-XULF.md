# KB Node — Produk Bilateral: Emas Loco London (XUL10 & XULF)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak & biaya (margin, komisi, rollover) untuk produk Emas Loco London — tersedia di **Akun Reguler**, kategori Bilateral (SPA), skala penuh. Dua varian: kurs tetap (IDR, kode XUL10) dan kurs mengambang (USD, kode XULF).

| Item | XUL10 (Kurs Tetap, IDR) | XULF (Kurs Mengambang, USD) |
|---|---|---|
| Satuan Kontrak | 100 Troy Ons | 100 Troy Ons |
| Jam Perdagangan | Senin–Jumat. Summer 06:00–03:30 WIB; Winter 06:00–04:30 WIB | Senin–Jumat. Summer 06:00–03:30 WIB; Winter 06:00–04:30 WIB |
| Margin Transaksi Harian | IDR 10.000.000/lot | USD 1.000/lot |
| Margin Transaksi Menginap | IDR 30.000.000/lot | USD 3.000/lot |
| Komisi | IDR 150.000/lot/sisi | USD 15/lot/sisi |
| Biaya Menginap Jual/Beli | IDR 50.000/lot/malam | USD 5/lot/malam |
| PPN | 11% dari komisi & biaya menginap | 11% dari komisi & biaya menginap |
| Maintenance Margin | 70% dari kebutuhan margin | 70% dari kebutuhan margin |
| Auto Liquidasi | 30% dari kebutuhan margin | 30% dari kebutuhan margin |
| Spread Kuotasi Min–Maks | USD 0,40–1,00/troy ons/sisi | USD 0,40–1,00/troy ons/sisi |
| Pergerakan Harga Minimum | USD 0,01/troy ons | USD 0,01/troy ons |
| Rentang Limit & Stop Order | IDR 60.000–200.000 | USD 6–20 |
| Penyelesaian | Cash Settlement | Cash Settlement |

**⚠️ PENTING — Risiko tertukar kode produk (perlu perhatian khusus):**

Kode **XUL10** di atas adalah untuk produk **Emas Loco London di Akun Reguler** (skala penuh: satuan kontrak 100 Troy Ons, margin harian USD 1.000/lot, margin menginap USD 3.000/lot, komisi USD 15/lot/sisi). Ini **BUKAN** produk Gold yang sama dengan yang dipakai di **Akun Mini** — meski kode kontraknya sama-sama disebut "XUL10", produk Akun Mini punya skala dan biaya yang jauh berbeda (menurut Trade Table resmi Akun Mini: Contract Size 10 Troy Ounce, Initial Margin Day Trade USD 100/lot, Facility Fee USD 1,5/lot/sisi). **Jangan pernah menjawab pertanyaan soal margin/komisi Akun Mini pakai angka dari tabel ini, atau sebaliknya** — selalu konfirmasi dulu ke user itu Akun Mini atau Akun Reguler. Lihat [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] untuk versi Akun Mini.

**Jangan disamakan dengan:**
- [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] — Gold Akun Mini, kode sama (XUL10) tapi skala & biaya SANGAT berbeda (lihat peringatan di atas).
- [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]] dan [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]] — produk emas fisik JFX Multilateral, kode & mekanisme beda total (bukan Loco London/SPA).
- [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]] — produk Bilateral lain, komoditas beda.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 2.3.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]] · [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]] · [[KB-Node-AkunReguler-Bilateral-GBPUSD]] · [[KB-Node-AkunReguler-Bilateral-EURUSD]] · [[KB-Node-AkunReguler-Bilateral-AUDUSD]] · [[KB-Node-AkunReguler-Bilateral-USDCHF]] · [[KB-Node-AkunReguler-Bilateral-USDJPY]]
