# KB Node — Alamat Kantor, Kontak & Link Resmi PT Solid Gold Berjangka

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** alamat kantor, nomor kontak, email, dan link resmi perusahaan.

**Kata kunci pencarian:** alamat, alamat kantor, kantor, kantornya di mana, lokasi kantor, kantor pusat, datang ke kantor, nomor telepon, nomor WA, WhatsApp, email, kontak, hubungi, customer service, website resmi, link aplikasi.

**Ringkas:** Kantor PT Solid Gold Berjangka beralamat di **Equity Tower Lt. 23 Unit D, Kawasan SCBD, Jl. Jenderal Sudirman Kav. 52-53, Jakarta Selatan 12190**. Kontak: **+62 821-2665-636 (WA Only)** dan **opt.mini@solidgold.co.id**. Detail lengkap di bawah.

**Link Resmi**

| Sumber | URL |
|---|---|
| Website utama | https://www.sg-berjangka.com/ |
| Profil perusahaan | https://www.sg-berjangka.com/tentangkami/profil |
| Legalitas bisnis | https://www.sg-berjangka.com/tentangkami/legalitas-bisnis |
| BAPPEBTI — detail pialang | https://bappebti.go.id/pialang_berjangka/detail/049 |
| Aplikasi Solid — Android | https://play.google.com/store/apps/details?id=com.solidgoldberjangka.minimicro&hl=id |
| Aplikasi Solid — iOS | https://apps.apple.com/id/app/solid/id6756168987?l=id |
| Ebook edukasi trading | https://mini.sg-berjangka.com/id/education/ebook |
| Website khusus Akun Reguler | https://reguler.sg-berjangka.com |

**Website Akun Reguler:** kalau user bertanya apakah ada halaman/website khusus Akun Reguler, arahkan ke **reguler.sg-berjangka.com**.

**Kontak & Alamat**

- Nomor: +62 821-2665-636 (WA Only)
- Email: opt.mini@solidgold.co.id
- Fax: Tidak Ada
- Alamat: Equity Tower Lt. 23 Unit D, Kawasan Niaga Terpadu Sudirman (SCBD) Jalan Jenderal Sudirman Kaveling 52-53, nomor Lot 9, Kel. Senayan, Kec. Kebayoran Baru, Kota Administrasi Jakarta Selatan, DKI Jakarta - 12190
- Kantor/layanan operasional disebutkan berada di Jakarta, Semarang, dan Makassar (medium confidence — cek ulang untuk kepastian terbaru)
- Aplikasi Solid tersedia di Google Play Store & Apple App Store (medium confidence — cek ulang ketersediaan/versi terbaru secara berkala)

**Jangan disamakan dengan:** [[KB-Node-Profil-Perusahaan]] (identitas & nama resmi), [[KB-Node-Legalitas-Daftar-Izin]] (nomor izin, bukan link/kontak), [[KB-Node-Edukasi-Ebook]] (penjelasan khusus kapan & bagaimana membagikan link ebook ke user).

---
**Node terkait (navigasi KB):** [[KB-Node-Legalitas-Lembaga-Pengawas]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]] · [[KB-Node-Alur-Pendaftaran-Akun-Real]]
