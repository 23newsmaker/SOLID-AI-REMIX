# PT SOLID GOLD BERJANGKA — MASTER KNOWLEDGE BASE (REDIRECT — lihat Node)

> **AUDIENCE: PUBLIC.** Dokumen ini boleh dipakai sebagai evidence jawaban chatbot. **Isi lengkap dokumen ini sudah dipecah menjadi node-node kecil per topik** (restrukturisasi September 2026) agar lebih mudah dirujuk & tidak ambigu. Gunakan node-node di bawah sebagai evidence utama — dokumen ini tinggal peta pengalihan. Peta lengkap seluruh node: [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku/script jawaban chatbot: [[System Prompt]].

**Version 2.0 (Redirect ke Node — September 2026) — PT Solid Gold Berjangka**

---

## Node Pengganti Bagian 1 (Tentang PT Solid Gold Berjangka)
→ [[KB-Node-Profil-Perusahaan]]

## Node Pengganti Bagian 2 (Sumber Resmi & Fakta Terverifikasi)
→ [[KB-Node-Sumber-Resmi-Kontak]] (link resmi, alamat, telepon, email, kantor operasional, ketersediaan aplikasi)
→ Daftar lengkap izin & nomor legalitas: [[KB-Node-Legalitas-Daftar-Izin]] (lihat juga [[KB-Node-Legalitas-Lembaga-Pengawas]])

## Node Pengganti Bagian 3.1 (Jenis Akun)
→ [[KB-Node-JenisAkun-Mini-Overview]] (Akun Mini)
→ [[KB-Node-JenisAkun-Reguler-Overview]] (Akun Reguler)

## Node Pengganti Bagian 3.2 (Daftar Produk — Karakteristik Umum)
→ [[KB-Node-Daftar-Produk-Karakteristik]]

## Node Pengganti Bagian 3.3 (Istilah Trading Dasar)
→ [[KB-Node-Istilah-Trading-Dasar]]

---

Dokumen fakta tambahan yang dulu melengkapi Master KB ini (juga sudah dipecah jadi node, lihat [[00-INDEX-Peta-Dokumen-KB-1]]):
- `KB_Tambahan_Legalitas_Perizinan_v1` (redirect)
- `KB_Tambahan_Akun_Reguler_v1_8` (redirect)
- `KB_Tambahan_Biaya_Swap_Margin_v1_2_1` (redirect)

Untuk aturan jawaban, script, dan compliance gate, lihat [[System Prompt]].
