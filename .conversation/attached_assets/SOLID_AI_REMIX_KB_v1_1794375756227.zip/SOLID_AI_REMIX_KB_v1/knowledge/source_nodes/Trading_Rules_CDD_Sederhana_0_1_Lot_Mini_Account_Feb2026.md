# PT. SOLID GOLD BERJANGKA
**Member of Jakarta Futures Exchange**
**Member of Indonesian Derivatives Clearing House**

> **AUDIENCE: PUBLIC.** Dokumen resmi/regulatori — boleh dipakai sebagai evidence jawaban chatbot ke customer. Aturan kapan/bagaimana chatbot mengutip angka di sini ada di [[System Prompt]].

---

> **📎 Dokumen Terkait** (lihat peta lengkap & alur data di [[00-INDEX-Peta-Dokumen-KB-1]] — INTERNAL):
> - Angka spesifikasi kontrak yang dirujuk sebagai "Trade Table terlampir" di seluruh dokumen ini = [[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]]
> - Landasan izin untuk mekanisme CDD Sederhana (Bagian I.5, VIII.2, VIII.6–7) = izin No. 10 di [[KB_Tambahan_Legalitas_Perizinan_v1]]
> - Versi ringkas biaya/margin untuk chatbot: [[KB_Tambahan_Biaya_Swap_Margin_v1_2_1]]
> - Dokumen induk: [[SOLID_GOLD_BERJANGKA_MASTER_KB_v1_8_1]]

## DAFTAR KONTRAK DERIVATIF DALAM SISTEM PERDAGANGAN ALTERNATIF DENGAN VOLUME MINIMUM 0,1 LOT (MINI ACCOUNT)

| NO | NAMA KONTRAK | JENIS KONTRAK | KODE KONTRAK |
|----|--------------|---------------|--------------|
| 1 | Kontrak Gulir Harian Emas Loco London | Fixed Rated (1 USD = IDR 10.000) | XUL10 |
| 2 | Kontrak Derivatif Gulir Berkala Brent Crude Oil | Fixed Rated (1 USD = IDR 10.000) | BCO10_BBJ |

---

# PERATURAN DAN KETENTUAN PERDAGANGAN
# TRADING RULES AND REGULATIONS
# MINI ACCOUNT

---

## I. KETENTUAN UMUM

**1. Sistem Perdagangan Alternatif (SPA)**
Adalah sistem perdagangan yang berkaitan dengan jual beli kontrak derivatif selain kontrak berjangka dan kontrak derivatif syariah yang dilakukan di luar Bursa Berjangka, secara bilateral dengan penarikan margin yang didaftarkan ke Lembaga Kliring Berjangka. PT. SOLID GOLD BERJANGKA sebagai Pialang Berjangka Peserta SPA telah memiliki perjanjian kerjasama dengan PT. Royal Assetindo sebagai Pedagang Berjangka Penyelenggara SPA.

**2. Rolling Contract (Kontrak Gulir)**
Adalah kontrak derivatif dalam Sistem Perdagangan Alternatif yang pada penutupan jam perdagangan seluruh posisi terbuka akan diperpanjang secara otomatis ke hari perdagangan berikutnya sampai posisi terbuka tersebut ditutup.

**3. Overnight Trading**
Adalah pengambilan posisi terbuka jual (sell) atau beli (buy) dengan mempertahankan posisi tersebut tetap terbuka hingga memasuki hari perdagangan berikutnya. Setiap posisi terbuka Overnight Trading ini akan dikenakan denda transaksi (Storage/Rollover) per malamnya dengan pengenaan Pajak Pertambahan Nilai (PPN) sesuai Trade Table terlampir.

**4. Day Trading**
Adalah pengambilan posisi terbuka jual (sell) atau beli (buy) yang ditutup atau dilikuidasi pada hari yang sama, sehingga tidak ada posisi terbuka satupun dari Nasabah Pialang Berjangka Peserta SPA. Istilah ini juga dikenal dengan Intraday Trading.

**5. Open Position (Posisi Terbuka)**
Adalah posisi terbuka jual (sell) atau beli (buy) yang belum ditutup atau dilikuidasi. Nasabah dengan sistem penerimaan CDD sederhana akan dilakukan CDD standar, apabila posisi terbuka lebih dari 1 lot selama transaksi berjalan.

**6. Liquidation (Likuidasi)**
Adalah menutup posisi terbuka jual (sell) atau beli (buy) dengan posisi yang berlawanan.

**7. Settlement Price**
Adalah harga penyelesaian yang ditentukan oleh Bursa Berjangka pada akhir hari perdagangan sesuai dengan spesifikasi kontrak derivatif masing-masing.

**8. Spread**
Adalah selisih dalam poin antara harga jual (sell) atau beli (buy). Ketentuan spread untuk setiap kontrak sesuai Trade Table terlampir.

**9. Point (Poin) / PIP**
Adalah satuan terkecil antara suatu harga dengan harga sebelumnya yang dapat dinyatakan dalam satuan angka penuh atau satuan angka desimal.

**10. Contract Size**
Adalah nilai kontrak standar. Nilai kontrak untuk setiap produk sesuai Trade Table terlampir.

**11. Quotation (Kuotasi)**
Adalah harga jual (sell) atau beli (buy) yang didistribusikan secara elektronik ke dalam sistem transaksi Pro Trader. Kuotasi tersebut mengacu pada harga terakhir (last trade) pada sistem Telequote sebagai penyedia data harga yang sudah dikenakan spread untuk masing-masing kontrak sesuai dengan Trade Table terlampir.

**12. Facility Fee (Biaya Komisi)**
Adalah biaya yang harus dibayarkan Nasabah kepada Pialang Berjangka Peserta SPA untuk setiap pengambilan posisi transaksi. Biaya komisi untuk setiap pengambilan posisi transaksi jual (sell) atau beli (buy), dan pengenaan Pajak Pertambahan Nilai (PPN) dari Biaya Komisi tersebut sesuai Trade Table terlampir.

**13. Pro Trader**
Adalah sistem transaksi secara online yang dimiliki PT. Royal Assetindo sebagai Pedagang Berjangka Penyelenggara SPA yang digunakan oleh Pialang Berjangka Peserta SPA dengan Aplikasi berbasis Web Browser, Android dan iOS.

**14. Keadaan Hectic Market**
Adalah keadaan ketika pasar dalam kondisi yang tidak diharapkan. Pada situasi ini spread akan didasarkan pada kondisi pergerakan harga sebagaimana kuotasi yang disampaikan oleh provider yang digunakan oleh Pedagang Penyelenggara Sistem Perdagangan Alternatif. Yang dimaksud dengan kondisi hectic apabila dipenuhi minimal salah satu dari situasi di bawah ini, dan tidak disebabkan karena wrong quote, sebagai berikut:
   a. Bid atau Offer hanya ada satu sisi;
   b. Spread antara bid dan offer melebihi dari spread minimum yang ditentukan oleh Penyelenggara Sistem Perdagangan Alternatif di dalam Trade Table terlampir;
   c. Terjadi fluktuasi harga lebih dari 30 (tiga puluh) poin, karena adanya berita politik, ekonomi, terorisme, bencana alam dan hal-hal yang berpengaruh pada kondisi pasar finansial.

**15. Wrong Quote**
Adalah ketika harga yang terjadi pada tampilan sistem transaksi tidak akurat atau tidak sesuai dengan harga pasar yang sebenarnya. Disebabkan karena berbagai faktor, termasuk kesalahan harga dari provider penyedia harga (source price), masalah koneksi, atau karena tidak adanya likuiditas di pasar. Harga yang terjadi bersifat indikatif dan tidak dapat digunakan untuk melakukan transaksi. Apabila terjadi transaksi dengan harga Wrong Quote, maka transaksi tersebut akan dibatalkan oleh Penyelenggara SPA. Wrong Quote dapat terjadi disebabkan karena adanya kesalahan harga dari provider penyedia harga (source price) yang dijadikan sebagai acuan atau adanya gangguan dan masalah koneksi jaringan.

**16. One Time Password (OTP)**
Adalah kata sandi unik yang hanya dapat digunakan satu kali pada saat login ke dalam sistem aplikasi trading Pro Trader.

---

## II. JAM PERDAGANGAN

| PRODUK | KONTRAK | HARI PERDAGANGAN (SENIN-JUMAT) — SUMMER | HARI PERDAGANGAN (SENIN-JUMAT) — WINTER |
|--------|---------|------------------------------------------|------------------------------------------|
| GOLD (EMAS) | XUL10 | 06.00 - 03.30 WIB | 06.00 - 04.30 WIB |
| BRENT CRUDE OIL (MINYAK MENTAH BRENT) | BCO10_BBJ | 07:00 – 03:45 WIB | 08:00 – 03:45 WIB |

> - Jam perdagangan dapat berubah sewaktu-waktu
> - Perubahan jam perdagangan dapat dilihat pada lampiran trade table

---

## III. KETENTUAN MARGIN

Margin adalah sejumlah uang atau surat berharga yang harus ditempatkan oleh Nasabah pada Pialang Berjangka, Pialang Berjangka kepada Anggota Kliring Berjangka untuk menjamin pelaksanaan transaksi. Dalam hal ini margin menggunakan Fix Rate (USD 1 = IDR 10.000), adapun jenis-jenis margin antara lain:

**1. Deposit Margin**
Adalah dana yang disetorkan oleh Nasabah ke Pialang Berjangka Peserta SPA yang jumlahnya harus lebih besar dari Initial Margin.

**2. Initial Margin**
Adalah dana yang wajib disetorkan oleh Pialang Berjangka Peserta SPA ke Lembaga Kliring Berjangka sebagai jaminan atas transaksi terbuka Nasabah. Initial Margin juga dikenal dengan Margin Requirement atau Necessary Margin. Ketentuan Initial Margin untuk Day Trading sesuai dengan Trade Table terlampir.

**3. Maintenance Margin**
Adalah dana untuk memelihara posisi transaksi apabila terjadi kerugian yang belum terealisasi (Unrealized Loss), yaitu sebesar **70% (tujuh puluh persen)** dari Initial Margin.

**4. Variation Margin**
Adalah laba rugi akibat penilaian ulang setiap posisi terbuka dengan Harga Penyelesaian pada akhir hari perdagangan (Marked-to-Market). Besaran nilai variation margin dapat berubah setiap hari, tergantung fluktuasi harga pasar dan akan dihitung pada akhir sesi perdagangan oleh PT. Kliring Berjangka Indonesia berdasarkan harga penyelesaian (Settlement Price) yang diberikan oleh PT. Bursa Berjangka Jakarta.

**5. Margin Call**
Adalah suatu kondisi dimana dana Nasabah berada dibawah **70% (tujuh puluh persen)** dari Initial Margin. Kondisi ini Nasabah harus segera memenuhi Margin Call tersebut hingga **100% (seratus persen)** dari Initial Margin.

**6. Auto Liquidation**
Adalah suatu tindakan apabila Nasabah tidak memenuhi prosedur Margin Call dan ketika dana menyentuh atau melewati minimum **30% (tiga puluh persen)** dari Initial Margin, maka Pialang Berjangka Peserta SPA berhak melikuidasi seluruh posisi dengan atau tanpa pemberitahuan kepada Nasabah.

**7. Penarikan Dana (Withdrawal)**
Nasabah dapat melakukan penarikan dana (Withdrawal) apabila dananya mencukupi (posisi keuangan terakhir lebih besar dari Initial Margin), dengan terlebih dahulu mengisi Formulir Penarikan Dana (Withdrawal) di dalam sistem aplikasi trading Pro Trader dan/atau melalui formulir cetak.

**8. Pencairan Dana**
Pencairan dana dilakukan paling lambat tiga hari setelah Nasabah melengkapi Formulir Penarikan Dana **(T+3)**.

**9. Penutupan Rekening**
Apabila Nasabah bermaksud menutup rekeningnya pada Pialang Berjangka Peserta SPA, maka harus menutup semua posisi terbuka yang ada dan dana dibayarkan setelah Nasabah menyelesaikan semua kewajiban keuangannya terhadap Pialang Berjangka Peserta SPA.

---

## IV. KETENTUAN AMANAT ORDER

**1. Market Order (MO)**
Adalah order jual (sell) atau beli (buy) pada harga terbaik yang telah tersedia di dalam sistem aplikasi trading Pro Trader dalam hal ini menggunakan metode Market Execution dengan ketentuan sebagai berikut:
   a. Waktu eksekusi paling lama 1 (satu) detik sejak order diterima sampai dengan order direspon oleh sistem Pedagang Berjangka Penyelenggara Sistem Perdagangan Alternatif (SPA).
   b. Tidak ada requote. Jika dalam waktu eksekusi tersebut terjadi perubahan harga (price has changed) maka sistem akan memberikan harga baru sesuai dengan poin a.
   c. Harga yang terjadi sesuai dengan harga pasar dan dalam rentang yang wajar.

**2. Limit Order (LO)**
Adalah order jual (sell) atau beli (buy) pada harga yang telah ditentukan sebelumnya atau lebih baik. Order ini dapat untuk mengambil posisi terbuka baru atau melikuidasi posisi terbuka yang ada, dengan ketentuan waktu eksekusi paling lama 1 (satu) detik sejak order diterima sampai dengan order direspon oleh sistem Pedagang Berjangka Penyelenggara Sistem Perdagangan Alternatif.

**3. Stop Order (SO)**
Adalah order jual (sell) atau beli (buy) pada harga yang telah ditentukan sebelumnya atau tidak lebih baik. Order ini biasanya digunakan untuk membatasi kerugian dan juga dapat digunakan untuk mengambil posisi terbuka baru, dengan ketentuan waktu eksekusi paling lama 1 (satu) detik sejak order diterima sampai dengan order direspon oleh sistem Pedagang Berjangka Penyelenggara Sistem Perdagangan Alternatif.

**4. One Cancels the Other Order (OCO)**
Adalah kombinasi antara limit dan stop order apabila salah satu order tersebut berhasil tereksekusi (done) maka secara otomatis order lain akan dibatalkan, dengan ketentuan waktu eksekusi paling lama 1 (satu) detik sejak order diterima sampai dengan order direspon oleh sistem Pedagang Berjangka Penyelenggara Sistem Perdagangan Alternatif.

**5. Masa Berlaku Limit dan Stop Order**
Masa berlaku limit dan stop order adalah Good Till Canceled (GTC) yang berarti akan tetap berlaku hingga order tersebut berhasil dieksekusi (done) atau dibatalkan.

**6. Rentang Harga Limit dan Stop Order**
Rentang harga limit dan stop order adalah batasan minimum dan maksimum dari harga yang berjalan (Running Price) pada saat pengambilan posisi jual (sell) atau beli (buy), dengan menggunakan limit dan stop order sesuai Trade Table terlampir.

**7. Status Transaksi Limit dan Stop Order**
Status transaksi menggunakan limit dan stop order tidak menjamin terlaksananya transaksi (done) sesuai pada harga yang dipesan. Kondisi tersebut bisa terjadi apabila:
   a. Terjadi gap antar sesi perdagangan, maka limit atau stop order akan terlaksana (done) diharga open sesi perdagangan.
   b. Terjadi lompatan harga per tick pada saat sesi perdagangan berjalan yang melampaui harga limit atau stop order, maka untuk kondisi tersebut harga akan terlaksana (done) di harga terdekat dari limit atau stop order yang tercatat.

**8. Locking**
Adalah pembukaan posisi baru yang berlawanan dengan posisi sebelumnya tanpa bermaksud untuk melikuidasi posisi.

**9. Split Order**
Larangan adanya pemecahan (split) order untuk setiap 1 (satu) kali klik transaksi yang dilakukan oleh Nasabah.

**10. Reject Order**
Larangan adanya reject oleh Penyelenggara Sistem Perdagangan Alternatif atas order Nasabah selain reject atas order yang melebihi batasan minimum dan maksimum lot yang diperkenankan, kecukupan margin, maksimum posisi terbuka, serta posisi baru terhadap ekuitas Nasabah melebihi USD 2.500 apabila Nasabah tidak melakukan pengkinian data.

---

## V. PELAPORAN DAN PENDAFTARAN TRANSAKSI

**1. PT. Bursa Berjangka Jakarta (Jakarta Futures Exchange)**
Seluruh transaksi yang sudah berhasil (Done) akan dilaporkan oleh PT Solid Gold Berjangka melalui Sistem Pelaporan Transaksi (JFX Web) yang dimiliki PT. Bursa Berjangka Jakarta dan melalui E-Mail ke PT. Kliring Berjangka Indonesia.

**2. PT. Kliring Berjangka Indonesia (Indonesian Derivatives Clearing House)**
Selanjutnya Transaksi yang sudah dilaporkan oleh PT Solid Gold Berjangka ke Bursa Berjangka akan secara otomatis didaftarkan ke PT. Kliring Berjangka Indonesia sebagai lembaga kliring berjangka melalui metode CTFS (Clearing Trade Feed System) yang dilakukan oleh PT. Bursa Berjangka Jakarta.

---

## VI. KETENTUAN PENGELOLAAN REKENING

**1. Previous Balance**
Adalah saldo terakhir pada hari perdagangan sebelumnya.

**2. New Balance**
Adalah saldo yang timbul setelah dilakukan penyesuaian, termasuk penambahan atau penarikan dana, laba atau rugi yang terealisasi, biaya komisi, denda transaksi (Storage/Rollover), Pajak Pertambahan Nilai (PPN), pengenaan bunga (jika ada), pengenaan premium atau diskon pada saat pergantian kontrak (jika ada) dan lain-lain. New Balance ini akan menjadi Previous Balance pada hari perdagangan berikutnya.

**3. Floating Profit atau Floating Loss (Floating P/L)**
Adalah keuntungan atau kerugian potensial yang belum terealisasi dan masih dapat mengalami perubahan seiring perubahan harga yang menjadi acuannya.

**4. Equity**
Adalah selisih yang timbul setelah New Balance ditambah atau dikurangi Floating P/L.

**5. Effective Margin**
Adalah margin yang tersedia setelah equity dikurangi Initial Margin. Nasabah sewaktu-waktu dapat melakukan penarikan dana (Withdrawal) dengan melihat variable effective margin ini, selain juga harus memperhatikan aspek ketahanan equity apabila masih memiliki posisi terbuka.

**6. Equity Ratio**
Adalah perbandingan antara Equity dengan Initial Margin yang berfungsi sebagai indikator ketahanan equity apabila memiliki posisi terbuka lebih dari 1 (satu) kontrak yang berbeda.

---

## VII. FORMULA PERHITUNGAN TRANSAKSI

1. Semua harga yang ditawarkan oleh Pedagang Berjangka Penyelenggara SPA berdasarkan data harga indeks yang tertera pada Telequote. Ketika Telequote memberikan laporan data harganya ke sistem Aplikasi Trading Pro Trader Pedagang Berjangka Penyelenggara SPA, sistem aplikasi tersebut secara terus-menerus akan menghasilkan harga yang otomatis ditambah dan dikurangi sesuai dengan data spesifikasi kontrak atau Trade Table, untuk kemudian menjadi harga sedia jual (Sell) atau menjadi harga sedia Beli (Buy).

2. Kontrak Derivatif Gulir Harian Emas Loco London (XUL10) dan Kontrak Derivatif Gulir Berkala Brent Crude Oil (BCO10_BBJ) adalah:

> **P/L = [ (Selling Price − Buying Price) × Contract Size × n Lot ] − [ (Facility Fee + VAT) × n Lot ]**

**Keterangan:**
| Simbol | Keterangan |
|--------|------------|
| P/L (Profit or Loss) | Besaran untung atau rugi, baik yang real maupun floating |
| Selling Price – Buying Price | Selisih poin dari harga jual dikurangi harga beli |
| Contract Size | Ukuran Kontrak Standar |
| n Lot | Jumlah Lot Transaksi |
| Facility Fee | Biaya Komisi |
| VAT (Value Added Tax) | Pajak Pertambahan Nilai (PPN) dari Biaya Komisi |
| Liquidation Price | Harga Likuidasi |

---

## VIII. KETENTUAN PELAKSANAAN TRANSAKSI

1. Pembukaan Account Mini wajib melalui Pendaftaran Online dengan **Deposit Margin awal minimum sebesar USD 500** (lima ratus dolar Amerika) dengan Fixed Rate (1 USD = IDR 10.000).

2. Setiap Nasabah hanya diperbolehkan membuka **1 (satu) akun** pada 1 (satu) Pialang Berjangka yang sama melalui Penerimaan Nasabah Secara Elektronik Online dengan **CDD Sederhana**, dan terbatas hanya untuk Nasabah perseorangan.

3. Nasabah dapat menyampaikan order melalui sistem aplikasi trading Pro Trader secara online menggunakan User ID dan Password yang dibuat oleh nasabah. Nasabah akan mendapatkan konfirmasi melalui E-Mail dan Short Message Service (SMS) sesuai data yang tertera di dalam Aplikasi Pembukaan Rekening.

4. Nasabah pada saat login ke dalam sistem aplikasi trading Pro Trader, akan menerima One Time Password (OTP) melalui SMS sesuai nomor handphone dan E-Mail yang tertera di dalam Aplikasi Pembukaan Rekening.

5. Nasabah harus memantau kecukupan dana dari waktu ke waktu sebelum melakukan transaksi dan hanya diperbolehkan mengambil posisi terbuka **minimum 0,1 (Mini) dan maksimum 0,9 Lot** selama transaksi berjalan.

6. Nasabah harus memantau kecukupan dana dari waktu ke waktu sebelum melakukan transaksi, terutama dalam hal equity Nasabah bertambah menjadi **lebih dari USD 2.500** dengan Fixed Rate (1 USD = IDR 10.000) ekuivalen sebesar **Rp25.000.000** berdasarkan harga penyelesaian hari akhir (settlement price end of day), maka wajib untuk melakukan pengkinian data Nasabah dengan melengkapi informasi dan data yang dibutuhkan untuk melakukan **CDD Standar**, termasuk melakukan pengisian kembali seluruh dokumen dalam rangka penerimaan Nasabah melalui penerimaan Nasabah secara elektronik online.

7. Dalam hal Nasabah menolak untuk dilakukan pengkinian data, maka:
   a. Nasabah yang bersangkutan tidak dapat melakukan penarikan dana (withdrawal); dan
   b. Nasabah tidak dapat membuka posisi baru.

8. Sistem Trading yang dimiliki oleh Pedagang Berjangka Penyelenggara SPA akan selalu menerima order atau transaksi Nasabah, dan hanya akan berlaku reject dengan memperhatikan:
   a. Kecukupan Margin yang harus dipenuhi dalam setiap transaksi;
   b. Maksimum ekuitas lebih dari USD 2.500 dengan Fixed Rate (1 USD = IDR 10.000) terhadap posisi baru dalam hal Nasabah menolak untuk dilakukan pengkinian data;
   c. Posisi terbuka maksimum batasan **0,9 Lot** selama transaksi berjalan.

9. Nasabah dalam melakukan setoran margin awal (deposit margin) maupun penambahan dana (top-up margin) dapat dilakukan melalui pemindahbukuan antar rekening bank atas nama Nasabah bersangkutan ke Rekening Terpisah (segregated account) PT Solid Gold Berjangka, dengan ketentuan **paling banyak Rp10.000.000,-** (sepuluh juta rupiah) dalam satu kali transaksi dan **total nilai transaksi maksimal Rp20.000.000,-** (dua puluh juta rupiah) dalam 1 (satu) bulan.

10. Transaksi atau order Jual (Sell) atau Beli (Buy) yang sudah berhasil (done) di dalam sistem aplikasi trading Pro Trader yang dimiliki Pedagang Berjangka Penyelenggara SPA, **tidak dapat dibatalkan**.

11. Order dengan batas harga (Limit Order dan Stop Order) dilaksanakan dengan ketentuan Limit Order dan Stop Order hanya diterima sistem jika memenuhi ketentuan pada spesifikasi kontrak yang tertera pada Trade Table terlampir.

12. PT. SOLID GOLD BERJANGKA selaku Pialang Berjangka Peserta SPA akan mengirimkan Laporan Transaksi Harian kepada Nasabah secara elektronik melalui E-Mail sesuai data yang tertera di dalam Aplikasi Pembukaan Rekening. Jika dalam waktu **2 x 24 jam** tidak ada sanggahan dari Nasabah, maka order tersebut dianggap benar dan sah.

---

## IX. SPESIFIKASI KONTRAK

Spesifikasi Kontrak yang diperdagangkan PT. SOLID GOLD BERJANGKA selaku Pialang Berjangka Peserta SPA yaitu Kontrak Gulir Harian Emas Loco London (XUL10) dan Kontrak Derivatif Gulir Berkala Brent Crude Oil (BCO10_BBJ) tertera pada Trade Table terlampir.

---

## X. KERAHASIAAN

User ID dan Password serta OTP bersifat **PRIBADI** dan **RAHASIA**. Nasabah **WAJIB** untuk mengubah password yang dikirim oleh PT. SOLID GOLD BERJANGKA melalui E-Mail dan SMS. Nasabah harus menjaga kerahasiaan User ID dan Password serta OTP, jangan diberikan kepada pihak lain, termasuk tidak terbatas kepada pihak yang memiliki kepentingan dengan PT. SOLID GOLD BERJANGKA. Segala akibat yang timbul atas pemindahtanganan serta penggunaannya, sepenuhnya menjadi tanggung jawab Nasabah.

---

## XI. KETENTUAN LAIN

Isi dari Peraturan dan Ketentuan Perdagangan (Trading Rules and Regulations) ini dapat berubah sewaktu-waktu menyesuaikan perkembangan dan dinamika di Industri Perdagangan Berjangka Komoditi (PBK) dengan adanya pemberitahuan secara resmi dari PT. SOLID GOLD BERJANGKA selaku Pialang Berjangka Peserta SPA.

---
*Sumber dokumen: Trading Rules & Regulations Mini Account (CDD Sederhana 0,1 Lot) — Februari 2026*
