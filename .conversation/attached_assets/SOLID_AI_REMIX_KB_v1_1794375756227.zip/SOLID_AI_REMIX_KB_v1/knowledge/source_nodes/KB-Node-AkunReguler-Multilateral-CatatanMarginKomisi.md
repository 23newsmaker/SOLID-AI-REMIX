# KB Node — Catatan: Margin/Komisi Produk Multilateral Belum Tersedia

**AUDIENCE: PUBLIC**

**Topik:** Status data margin & komisi untuk kelima produk Multilateral (Olein, Emas 250 Gram, Emas 1 Kg, Kopi Arabika, Kopi Robusta) di Akun Reguler.

**Fakta:** Data yang tersedia untuk produk Multilateral (JFX) hanya mencakup **spesifikasi kontrak resmi bursa** — satuan kontrak, bulan kontrak, jam perdagangan, tik harga, batas posisi, dsb. **Margin dan komisi khusus yang dikenakan PT Solid Gold Berjangka untuk produk Multilateral belum tercakup** di dokumen KB manapun saat ini.

Ini **berbeda** dari produk Bilateral (SPA) — Indeks Hong Kong/Jepang, Emas Loco London, Minyak Brent, dan pasangan forex — yang datanya LENGKAP termasuk margin, komisi, dan biaya menginap/rollover milik perusahaan. Lihat node-node Bilateral: [[KB-Node-AkunReguler-Bilateral-IndeksHongKong-HKK]], [[KB-Node-AkunReguler-Bilateral-IndeksJepang-JPK]], [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]], [[KB-Node-AkunReguler-Bilateral-MinyakBrent-BCO10-BCOF]], [[KB-Node-AkunReguler-Bilateral-GBPUSD]], [[KB-Node-AkunReguler-Bilateral-EURUSD]], [[KB-Node-AkunReguler-Bilateral-AUDUSD]], [[KB-Node-AkunReguler-Bilateral-USDCHF]], [[KB-Node-AkunReguler-Bilateral-USDJPY]].

**Cara jawab kalau user tanya margin/komisi produk Multilateral (Olein/Emas 250 Gram/Emas 1 Kg/Kopi Arabika/Kopi Robusta):**
- Jawab spesifikasi kontrak yang tersedia (satuan kontrak, dsb — lihat node produk masing-masing).
- Untuk angka margin/komisi spesifik, sampaikan bahwa info detail biaya untuk produk ini perlu dikonfirmasi ke tim terkait, dan eskalasikan sesuai Bagian 10 System Prompt. **Jangan mengarang angka** atau memakai angka margin/komisi dari produk Bilateral/Akun Mini untuk menjawab pertanyaan soal produk Multilateral — beda produk, beda struktur biaya.

**Jangan disamakan dengan:**
- Produk Multilateral: [[KB-Node-AkunReguler-Multilateral-Olein-OLE]], [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]], [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]], [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]], [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]].

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` catatan akhir Bagian 1. Catatan kerja/TODO Compliance: `INTERNAL_Catatan_Compliance_BD.md`.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]]
