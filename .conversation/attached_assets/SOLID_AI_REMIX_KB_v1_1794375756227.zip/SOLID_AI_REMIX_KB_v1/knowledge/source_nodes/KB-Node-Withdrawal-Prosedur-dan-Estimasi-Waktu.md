# KB Node — Withdrawal (Penarikan Dana): Prosedur, Syarat & Estimasi Waktu

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].

**Topik:** cara mengajukan withdrawal (penarikan dana), syaratnya, dan berapa lama prosesnya.

**Kata kunci pencarian:** withdrawal, WD, tarik dana, penarikan dana, cairkan dana, berapa lama WD, kapan dana masuk, T+1, T+3, rekening tujuan.

**Estimasi waktu proses:**
- Standar proses withdrawal **sampai T+3 hari kerja** (T = hari pengajuan).
- Perusahaan **mengupayakan selesai T+1 hari kerja**, tetapi T+1 **bukan jaminan**. Penyelesaian aktual mengikuti hari kerja dan proses operasional.
- Estimasi dihitung dalam **hari kerja** (Sabtu, Minggu, dan hari libur tidak dihitung).

**Syarat pengajuan:**
1. Diajukan **selama jam perbankan**.
2. Jumlah penarikan **tidak melebihi effective margin** yang tercantum di laporan transaksi harian (statement report).
3. Rekening tujuan **wajib atas nama nasabah sendiri**, sama dengan nama di dokumen pembukaan rekening. Penarikan ke rekening orang lain tidak diperbolehkan.

**Tahapan:**

| # | Tahap | Detail |
|---|---|---|
| 1 | Masuk ke menu Withdrawal | Di akun transaksi riil, ajukan permohonan penarikan |
| 2 | Isi formulir | Lengkapi formulir dan pastikan data rekening tujuan benar |
| 3 | Validasi rekening | Rekening tujuan dicek harus atas nama nasabah yang sama dengan dokumen pembukaan rekening |
| 4 | Proses | Standar sampai T+3 hari kerja, diupayakan T+1 |

**Contoh:** pengajuan hari Senin pada jam perbankan → standar paling lambat Kamis (T+3 hari kerja), diupayakan Selasa (T+1). Pengajuan hari Jumat → T+1 jatuh di Senin, T+3 di Rabu.

**Belum ada data resmi:** biaya withdrawal (lihat [[KB-Node-AkunMini-BiayaLainLain]]), batas minimum/maksimum nominal withdrawal, dan jam perbankan persisnya (jam berapa sampai jam berapa).

**Jangan disamakan dengan:**
- [[KB-Node-AkunMini-Minimum-TopUp]] dan [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] — itu aturan **memasukkan** dana (setoran/top-up), bukan menarik dana.
- Status withdrawal yang sudah diajukan tapi belum masuk — itu kasus akun spesifik, eskalasikan ke tim CS (bukan dijawab dari node ini).

Sumber: materi prosedur withdrawal SG Solid (dokumen internal Knowledge Promosi/Banner v1.0, Bagian 8), dikonfirmasi BD untuk dijadikan knowledge. Batas T+3 juga tercantum di dokumen resmi [[Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026]] Bagian III poin 8: *"Pencairan dana dilakukan paling lambat tiga hari setelah Nasabah melengkapi Formulir Penarikan Dana (T+3)."*

*Catatan perbedaan redaksi (menunggu konfirmasi Compliance):* Trading Rules menghitung T+3 sejak formulir penarikan **lengkap** dan tidak menyebut "hari kerja"; materi Banner menyebut "hari kerja" dan "diupayakan T+1". Sampai dikonfirmasi, sampaikan "sampai T+3 hari kerja sejak pengajuan yang lengkap" dan jangan menjanjikan T+1.

---
**Node terkait (navigasi KB):** [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Istilah-Trading-Dasar]]
