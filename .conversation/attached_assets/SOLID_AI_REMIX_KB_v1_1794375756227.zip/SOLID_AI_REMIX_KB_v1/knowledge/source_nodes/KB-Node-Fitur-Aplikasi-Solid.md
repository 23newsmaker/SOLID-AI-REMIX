# KB Node — Fitur Aplikasi Solid: Akun Demo, Market Overview & TradePilot

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** fitur-fitur pendukung di Aplikasi Solid (aplikasi trading & pendaftaran resmi — bukan Solid Prime AI).

**Kata kunci pencarian:** fitur aplikasi, akun demo, demo gratis, market overview, berita pasar, TradePilot, analisa, sinyal, tools trading.

| Fitur | Penjelasan | Batasan |
|---|---|---|
| **Akun Demo** | Latihan transaksi dan mengenal fitur platform **tanpa deposit dana riil**. Wajib dipakai minimal 2 kali transaksi sebelum mengajukan akun real (lihat [[KB-Node-Alur-Pendaftaran-Akun-Real]]) | Hasil demo tidak selalu sama dengan akun riil (eksekusi, likuiditas, psikologi transaksi berbeda) |
| **Market Overview** | Berita ekonomi, komoditas, indeks, forex, dan pergerakan pasar secara realtime di dalam aplikasi, tersedia 24 jam/5 hari (mengikuti hari perdagangan pasar global) | Informasi/edukasi pendukung, **bukan sinyal transaksi** |
| **TradePilot** | Alat bantu analisis **berbasis AI** untuk memantau perkembangan pasar dan memahami kondisi pasar di luar sekadar melihat chart. Batas pemakaian: **10 token di akun demo, unlimited di akun real** — detail lengkap di [[KB-Node-TradePilot]] | Output analisis **bukan jaminan arah pasar** dan bukan kepastian profit |
| **Analisa & edukasi** | Materi analisa dan edukasi untuk membantu pemahaman pasar (lihat juga [[KB-Node-Edukasi-Ebook]]) | Bukan ajakan transaksi |

Semua insight, berita, dan tools di atas hanya informasi pendukung — keputusan transaksi dan risikonya tetap di tangan nasabah.

**Belum ada data resmi:** cara pakai detail tiap fitur, letak menu di aplikasi, dan daftar jenis order yang tersedia di aplikasi.

Sumber: materi banner SG Solid (dokumen internal Knowledge Promosi/Banner v1.0, Bagian 4, 10, 12).

**Istilah "Pro Trader":** di dokumen resmi [[Trading_Rules_CDD_Sederhana_0_1_Lot_Mini_Account_Feb2026]], "Pro Trader" didefinisikan sebagai sistem transaksi online milik PT Royal Assetindo (Pedagang Berjangka Penyelenggara SPA) yang dipakai untuk order, login (OTP), dan formulir penarikan dana. Hubungan Pro Trader dengan Aplikasi Solid (apakah sistem di balik aplikasi, atau aplikasi terpisah) **belum ada data resmi** — kalau user menyebut "Pro Trader", jangan menyimpulkan sendiri; arahkan ke tim CS untuk kepastiannya.

**Jangan disamakan dengan:** Solid Prime AI (asisten AI di live chat ini, bukan fitur di dalam Aplikasi Solid) — lihat [[KB-Node-Profil-Perusahaan]]. Market Overview/TradePilot bukan sinyal buy/sell — lihat [[KB-Node-Edukasi-Buy-Sell-dan-Jenis-Order]].

---
**Node terkait (navigasi KB):** [[KB-Node-TradePilot]] · [[KB-Node-Program-Referral]] · [[KB-Node-Edukasi-Manajemen-Risiko]] · [[KB-Node-Istilah-Trading-Dasar]] · [[KB-Node-Sumber-Resmi-Kontak]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Daftar-Produk-Karakteristik]]
