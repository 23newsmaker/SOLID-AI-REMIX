# KB Node — Produk Multilateral: Kontrak Berjangka Kopi Robusta (RCF)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak resmi Bursa Berjangka Jakarta (JFX) untuk produk Kopi Robusta (kode kontrak RCF) — tersedia di **Akun Reguler**, kategori Multilateral.

| Item | Ketentuan |
|---|---|
| Kode Kontrak | RCF |
| Satuan Kontrak | 5 Metrik Ton (5.000 kg) |
| Bulan Kontrak | Januari, Maret, Mei, Juli, September, November |
| Hari & Jam Perdagangan | Senin–Jumat. Sesi 1: 09:30–11:30 WIB; Sesi 2: 14:00–23:00 WIB |
| Perubahan Harga Minimum (Tik) | Rp 10/kg = Rp 50.000/lot |
| Batas Perubahan Harga | < Rp 20.000/kg → limit Rp 1.000; ≥ Rp 20.000/kg → limit Rp 1.300 (tidak berlaku bulan spot) |
| Mutu | Tingkat mutu IV-B, SNI 01-2907-2008 |
| Tempat Penyerahan | Gudang Terdaftar Palembang, Bandar Lampung, Jakarta, Surabaya |
| Satuan Penyerahan | Minimal 8 lot atau kelipatannya, masing-masing 1 lot = 5 ton bersih |
| Posisi Wajib Lapor | 300 lot |
| Batas Posisi | 1.000 lot |

**Catatan margin/komisi:** margin dan komisi khusus PT Solid Gold Berjangka untuk produk Multilateral (termasuk Kopi Robusta) belum tercakup di data resmi yang tersedia. Kalau user tanya margin/komisi spesifik produk ini, jawab spesifikasi kontraknya saja (tabel di atas) dan eskalasikan — lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]].

**Jangan disamakan dengan:**
- **Bukan** Kopi Arabika (kode ACF, satuan 2 Metrik Ton, bulan kontrak berbeda) — lihat [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]]. Dua kontrak kopi ini punya satuan kontrak, jam sesi, dan bulan kontrak yang berbeda — jangan tertukar.
- Ini produk **Akun Reguler** (Multilateral/JFX), bukan produk Akun Mini.

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 1.5.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Multilateral-Olein-OLE]] · [[KB-Node-AkunReguler-Multilateral-Emas250Gram-GOL250]] · [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]]
