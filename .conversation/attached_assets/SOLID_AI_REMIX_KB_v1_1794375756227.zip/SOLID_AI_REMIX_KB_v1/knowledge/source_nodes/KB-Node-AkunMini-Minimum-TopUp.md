# KB Node — Akun Mini: Minimum Top-Up (Akun yang Sudah Aktif)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1.

**Topik:** minimum nominal top-up (menambah dana) ke Akun Mini yang **sudah aktif** — bukan setoran awal buka akun baru (lihat node berbeda di bawah).

**Minimal top-up via transfer bank: Rp 10.000, berlaku untuk semua jenis akun (Mini & Reguler).**

Angka ini boleh disebutkan langsung ke customer — bukan angka internal-only. Berlaku untuk pertanyaan seperti: "berapa minimal top-up?", "top-up $1 boleh nggak?" (hitung dulu pakai Fixed Rate 1 USD = IDR 10.000, lalu bandingkan ke Rp10.000 — kalau hasilnya sudah mencapai atau lebih, berarti boleh).

**PENTING — jangan disamakan dengan:**
- [[KB-Node-AkunMini-Minimum-SetoranAwal]] — IDR 5.000.000/USD 500, untuk MEMBUKA akun baru, bukan untuk menambah dana ke akun yang sudah ada. Kalau user belum punya akun / jelas-jelas tanya soal buka akun baru, pakai node itu, bukan node ini.
- [[KB-Node-AkunMini-BatasMaksimal-SetoranTopUp]] — Rp10.000.000/transaksi & Rp20.000.000/bulan, ini batas ATAS/limit, bukan minimum.

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Kurs-FixedRate-USD-IDR]] · [[KB-Node-AkunMini-Contoh-Perhitungan]] · [[KB-Node-Deposit-Withdrawal-Status-Data]]
