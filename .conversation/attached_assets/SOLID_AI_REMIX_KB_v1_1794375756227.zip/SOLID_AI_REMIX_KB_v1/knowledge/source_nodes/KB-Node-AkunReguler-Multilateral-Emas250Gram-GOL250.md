# KB Node — Produk Multilateral: Kontrak Berjangka Emas 250 Gram (GOL250)

**AUDIENCE: PUBLIC**

**Topik:** Spesifikasi kontrak resmi Bursa Berjangka Jakarta (JFX) untuk produk Emas 250 Gram (kode kontrak GOL250) — tersedia di **Akun Reguler**, kategori Multilateral.

| Item | Ketentuan |
|---|---|
| Kode Kontrak | GOL250 |
| Satuan Kontrak | 250 gram |
| Bulan Kontrak | 3 bulan berturut-turut |
| Hari & Jam Perdagangan | Setiap hari perdagangan, pukul 09:30–17:30 WIB |
| Perubahan Harga Minimum (Tik) | Rp 50/gram (termasuk PPN) = Rp 12.500/lot (termasuk PPN) |
| Batas Perubahan Harga | Rp 10.000/gram di atas/bawah Harga Penyelesaian hari sebelumnya (tidak berlaku untuk Bulan Berjalan/Bulan Terdekat) |
| Mutu | Kemurnian minimum 99,99%, refineri diakui LBMA |
| Tempat Penyerahan | Gudang Terdaftar di Jakarta, Surabaya, Bandung, Semarang, Solo, Yogyakarta, Medan, Makassar, Manado, Banjarmasin, Lampung, Denpasar |
| Satuan Penyerahan | Minimal 4 lot atau kelipatannya, masing-masing 250 gram bersih |
| Posisi Wajib Lapor | 600 lot |
| Batas Posisi | 2.000 lot |

**Catatan margin/komisi:** margin dan komisi khusus PT Solid Gold Berjangka untuk produk Multilateral (termasuk Emas 250 Gram) belum tercakup di data resmi yang tersedia. Kalau user tanya margin/komisi spesifik produk ini, jawab spesifikasi kontraknya saja (tabel di atas) dan eskalasikan — lihat [[KB-Node-AkunReguler-Multilateral-CatatanMarginKomisi]].

**Jangan disamakan dengan:**
- **Bukan** produk Gold Akun Mini (kode XUL10, Contract Size 10 Troy Ounce menurut Trade Table resmi) — lihat [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]]. Emas 250 Gram (GOL250) adalah kontrak emas fisik gram (JFX Multilateral), satuan & mekanisme berbeda total dari Gold XUL10.
- **Bukan** produk Emas Loco London Akun Reguler Bilateral (kode XUL10/XULF, satuan 100 Troy Ons) — lihat [[KB-Node-AkunReguler-Bilateral-EmasLocoLondon-XUL10-XULF]]. Tiga produk "emas" ini (GOL250, GOL, Emas Loco London) beda kode, beda satuan, beda mekanisme — jangan dicampur.
- Produk emas lain: [[KB-Node-AkunReguler-Multilateral-Emas1Kg-GOL]] (1 Kg, kode GOL — beda dari GOL250).

Dokumen sumber: `KB_Tambahan_Akun_Reguler_v1_8` Bagian 1.2.

---
**Node terkait (navigasi KB):** Peta KB: [[00-INDEX-Peta-Dokumen-KB-1]] — [[KB-Node-JenisAkun-Reguler-Overview]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]] · [[KB-Node-AkunReguler-Multilateral-Olein-OLE]] · [[KB-Node-AkunReguler-Multilateral-KopiArabika-ACF]] · [[KB-Node-AkunReguler-Multilateral-KopiRobusta-RCF]]
