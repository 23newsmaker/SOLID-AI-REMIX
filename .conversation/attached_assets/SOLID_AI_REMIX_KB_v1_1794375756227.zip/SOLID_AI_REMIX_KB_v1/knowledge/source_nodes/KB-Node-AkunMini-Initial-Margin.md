# KB Node — Akun Mini: Initial Margin (Margin Awal untuk Membuka Posisi)

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Topik:** besarnya Initial Margin untuk membuka posisi di Akun Mini, dan bedanya dengan setoran awal buka akun.

**Initial Margin (Day Trade) Akun Mini: USD 100/lot**, berlaku untuk Gold (XUL10) dan Brent Oil (BCO10_BBJ).

Sumber: Trade Table resmi ([[Trade_Table_Spesifikasi_Kontrak_Mini_Account_Feb2026]]), baris "Initial Margin — Day Trade".

Initial Margin adalah margin awal, yaitu dana jaminan yang dibutuhkan untuk membuka posisi (definisi margin ada di [[KB-Node-Istilah-Trading-Dasar]]).

**Bedanya dengan setoran awal buka akun:**

| Istilah | Artinya | Angka |
|---|---|---|
| Initial Margin | Margin yang dibutuhkan untuk membuka posisi | USD 100/lot (day trade) |
| Setoran/Deposit Margin awal buka akun | Dana minimum yang disetor untuk membuka Akun Mini baru | IDR 5.000.000 / USD 500 |

Trading Rules memakai istilah "Deposit Margin awal" untuk setoran buka akun. Itu bukan Initial Margin per lot.

**Akun Reguler:** produk Bilateral mencantumkan "Margin Transaksi Harian" dan "Margin Transaksi Menginap" per lot di node produk masing-masing. Istilah "Initial Margin" muncul di node GBP/USD dan EUR/USD sebagai dasar Maintenance Margin 70% dan Auto Liquidasi 30%. Jangan memakai USD 100/lot dari node ini untuk Akun Reguler.

**Jangan disamakan dengan:** [[KB-Node-AkunMini-Minimum-SetoranAwal]] (dana buka akun), [[KB-Node-AkunMini-Minimum-TopUp]] (tambah dana akun aktif), [[KB-Node-AkunMini-Margin-Equity-CallMargin]] (batas equity, call margin, auto liquidation).

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Komisi-Transaksi]] · [[KB-Node-AkunMini-StorageRolloverFee]] · [[KB-Node-AkunMini-BiayaLainLain]] · [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]] · [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]]
