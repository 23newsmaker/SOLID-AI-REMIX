# KB Node — Legalitas: Daftar Nomor Izin

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].2.

**Topik:** nomor izin/dokumen legal resmi PT Solid Gold Berjangka, per jenis izin.

| No | Jenis Dokumen / Izin | Nomor | Tahun / Periode | Instansi / Pihak Terkait |
|---|---|---|---|---|
| 1 | Pengesahan Badan Hukum PT (Akta Pendirian) | C-05612 HT.01.01.TH.2002 | 2002 | Kementerian Hukum dan HAM RI |
| 2 | Surat Persetujuan Anggota Bursa (SPAB) | SPAB-047/BBJ/07/02 | Juli 2002 | PT Bursa Berjangka Jakarta (BBJ) |
| 3 | Izin Usaha Pialang Berjangka | 161/BAPPEBTI/SI/IX/2002 | September 2002 | BAPPEBTI |
| 4 | Keanggotaan Lembaga Kliring Berjangka | 15/AK-KBI/V/2003 | Mei 2003 | PT Kliring Berjangka Indonesia (KBI) |
| 5 | Perjanjian Kerjasama dengan PT Royal Assetindo | 262/CO-BOD/SGB/VI/2005 | Juni 2005 | PT Royal Assetindo (Penyelenggara Sistem Perdagangan Alternatif) |
| 6 | Persetujuan sebagai Peserta Sistem Perdagangan Alternatif (SPA) | 1156/BAPPEBTI/SI/3/2007 | Maret 2007 | BAPPEBTI |
| 7 | Penerimaan Nasabah Secara Elektronik On-Line | 27/BAPPEBTI/KEP-PBK/09/2014 | September 2014 | BAPPEBTI |
| 8 | Perantara Perdagangan Efek Derivatif Keuangan | S-373/PM.02/2025 | 2025 | OJK (Otoritas Jasa Keuangan) |
| 9 | Peserta Sistem Perdagangan Alternatif Derivatif PUVA | 27/663/DPPK/Srt/B | Tidak dicantumkan (termasuk di web resmi) | Bank Indonesia |
| 10 | Penerimaan Nasabah Elektronik On-Line dgn CDD Sederhana | 004/BAPPEBTI/KEP-PBK/CDDS/007/2026 | 2026 | BAPPEBTI |

**Jangan disamakan dengan:** [[KB-Node-Legalitas-Lembaga-Pengawas]] (lembaga secara umum, bukan nomor izin spesifik).

---
**Node terkait (navigasi KB):** [[KB-Node-Profil-Perusahaan]] · [[KB-Node-Sumber-Resmi-Kontak]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]] · [[KB-Node-Multilateral-vs-Bilateral-dan-Varian-Kurs]]
