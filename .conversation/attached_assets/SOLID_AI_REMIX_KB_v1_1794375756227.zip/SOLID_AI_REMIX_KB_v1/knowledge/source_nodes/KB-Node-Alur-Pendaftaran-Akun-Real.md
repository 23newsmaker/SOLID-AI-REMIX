# KB Node — Alur Pendaftaran dan Pembukaan Akun Real

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].1 dan Bagian 10.

**Topik:** tahapan dari awal sampai akun real aktif, termasuk pertanyaan "berapa lama proses buka/pembuatan akun?".

**Kata kunci pencarian:** cara daftar, buka akun, pembuatan akun, registrasi, berapa lama proses, durasi, lama verifikasi, kapan akun aktif, aktivasi akun, video call WPB.

Pendaftaran dan pembukaan akun baru dilakukan **melalui Aplikasi Solid**, tidak lagi lewat website. Aplikasi Solid tersedia di Google Play Store (Android) dan App Store (iOS) — link resmi ada di [[KB-Node-Sumber-Resmi-Kontak]].

**Tahapan:**
1. Download Aplikasi Solid.
2. Buat akun demo.
3. Coba transaksi minimal 2 kali di akun demo (untuk membiasakan diri dengan platform).
4. Ajukan pembukaan akun real. Registrasi dan input dokumen dilakukan di dalam aplikasi.
5. Verifikasi data oleh tim WPB (Wakil Pialang Berjangka) melalui video call. Jadwalnya diatur setelah pengajuan; tim WPB yang menghubungi.
6. Aktivasi akun.

**Lama proses pembukaan akun:**
- Estimasi waktu resmi (total maupun per tahap) **belum ditetapkan** — jangan sebut angka jam/hari.
- Tahap 1–4 dikerjakan sendiri oleh calon nasabah di Aplikasi Solid, jadi kecepatannya tergantung seberapa cepat calon nasabah menyelesaikan demo (minimal 2 transaksi) dan registrasi.
- Tahap 5 tergantung jadwal video call yang diatur bersama tim WPB setelah pengajuan.
- Untuk menanyakan status/perkiraan waktu pengajuan yang sedang berjalan, calon nasabah bisa dihubungkan ke tim CS langsung di live chat ini.

**Setoran awal Akun Mini:** deposit margin awal minimum IDR 5.000.000 / USD 500 — lihat [[KB-Node-AkunMini-Minimum-SetoranAwal]].

**Belum ada data resmi di KB:** daftar dokumen persyaratan, estimasi lama proses verifikasi/aktivasi dalam satuan waktu, dan detail tampilan/fitur/cara upload di dalam aplikasi.

Sumber: alur pendaftaran internal PT Solid Gold Berjangka.

**Jangan disamakan dengan:** Solid Prime AI (asisten AI di live chat, tidak dipakai untuk mendaftar) — pendaftaran hanya lewat Aplikasi Solid. Juga bukan [[KB-Node-AkunMini-Minimum-TopUp]] (tambah dana ke akun yang sudah aktif).

---
**Node terkait (navigasi KB):** [[KB-Node-Fitur-Aplikasi-Solid]] · [[KB-Node-Program-Referral]] · [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-Topik-Belum-Ada-Data-Resmi]] · [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]]
