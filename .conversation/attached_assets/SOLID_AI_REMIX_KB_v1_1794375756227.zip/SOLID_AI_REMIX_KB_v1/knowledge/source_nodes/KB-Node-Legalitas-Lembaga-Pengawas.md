# KB Node — Legalitas: Lembaga Pengawas

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].2.

**Topik:** lembaga mana saja yang mengawasi PT Solid Gold Berjangka.

PT Solid Gold Berjangka diawasi secara berlapis oleh beberapa lembaga, sesuai dengan jenis layanan yang disediakan:

- **BAPPEBTI** (Badan Pengawas Perdagangan Berjangka Komoditi, saat ini bagian dari Kementerian Perdagangan) — pengawas utama untuk kegiatan pialang berjangka komoditi.
- **Bursa & Kliring** (PT Bursa Berjangka Jakarta / BBJ dan PT Kliring Berjangka Indonesia / KBI) — penyelenggara perdagangan dan penjaminan transaksi di bursa berjangka.
- **OJK** (Otoritas Jasa Keuangan) — relevan untuk kegiatan sebagai perantara perdagangan efek derivatif keuangan.
- **Bank Indonesia** — relevan untuk keikutsertaan dalam sistem perdagangan alternatif derivatif (PUVA/DNDF terkait valuta asing).

**Jangan disamakan dengan:** [[KB-Node-Legalitas-Daftar-Izin]] (nomor izin spesifik per lembaga di atas).

---
**Node terkait (navigasi KB):** [[KB-Node-Profil-Perusahaan]] · [[KB-Node-Sumber-Resmi-Kontak]] · [[KB-Node-Cara-Verifikasi-Legalitas-dan-Waspada-Penipuan]]
