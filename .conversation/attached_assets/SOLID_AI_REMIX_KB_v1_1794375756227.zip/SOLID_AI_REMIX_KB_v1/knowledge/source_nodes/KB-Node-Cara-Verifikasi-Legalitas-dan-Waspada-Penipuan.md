# KB Node — Cara Verifikasi Legalitas dan Waspada Penipuan

> **AUDIENCE: PUBLIC.** Node fakta tunggal, bagian dari Knowledge Base chatbot Solid Prime AI — boleh dipakai sebagai evidence jawaban ke customer. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL). Aturan perilaku umum chatbot ada di [[System Prompt]].2.

**Topik:** cara calon nasabah mengecek keaslian PT Solid Gold Berjangka dan tanda-tanda yang perlu diwaspadai.

**Cara mengecek sendiri:**
1. Buka halaman legalitas di website resmi: https://www.sg-berjangka.com/tentangkami/legalitas-bisnis
2. Cek data pialang di BAPPEBTI: https://bappebti.go.id/pialang_berjangka/detail/049
3. Cocokkan nomor izin dengan [[KB-Node-Legalitas-Daftar-Izin]] dan lembaga pengawas di [[KB-Node-Legalitas-Lembaga-Pengawas]].
4. Unduh Aplikasi Solid hanya dari Google Play Store atau App Store lewat link resmi di [[KB-Node-Sumber-Resmi-Kontak]].

**Tanda yang perlu diwaspadai:**
- Janji profit pasti, dijamin cuan, atau balik modal cepat.
- Diminta transfer ke rekening pribadi atau pihak yang tidak jelas.
- Diminta password, PIN, OTP, atau data akun lewat chat.
- Tekanan untuk buru-buru deposit (promo terbatas, urgensi palsu).

Status legal atau berizin menunjukkan pengawasan resmi, tidak menghilangkan risiko kerugian dalam trading.

**Jangan disamakan dengan:** [[KB-Node-Legalitas-Daftar-Izin]] (isi nomor izin) — node ini panduan cara mengecek, bukan daftar nomornya.

---
**Node terkait (navigasi KB):** [[KB-Node-Profil-Perusahaan]] · [[KB-Node-Deposit-Withdrawal-Status-Data]] · [[KB-Node-Edukasi-Manajemen-Risiko]]
