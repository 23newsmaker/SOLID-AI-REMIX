# Trade Table — Kontrak Derivatif Volume Minimum 0,1 Lot (Akun Mini) — PT Solid Gold Berjangka

> **AUDIENCE: PUBLIC.** Transkripsi dokumen resmi Trade Table PT Solid Gold Berjangka (file sumber: "0726-E-cop Trade Table CDD Sederhana 0.1 Lot - SGB"). Ini sumber data resmi angka Akun Mini untuk Gold (XUL10) dan Brent Oil (BCO10_BBJ). Dokumen ini tidak dipecah menjadi node. Peta lengkap seluruh node ada di [[00-INDEX-Peta-Dokumen-KB-1]] (INTERNAL).

**Judul dokumen asli:** Trade Table Kontrak Derivatif Syariah dan/atau Kontrak Derivatif Lainnya dengan Volume Minimum 0,1 (Nol Koma Satu) Lot yang Diperdagangkan.

**Kop:** PT Solid Gold Berjangka — Member of Jakarta Futures Exchange, Member of Indonesian Derivatives Clearing House.

| Specification | XUL10 (Fixed Rate) | BCO10_BBJ (Fixed Rate) |
|---|---|---|
| Trade Code | XUL10 (Fixed Rate) | BCO10_BBJ (Fixed Rate) |
| Contract Size | 10 Troy Ounce | 100 Barrel |
| Trading Hours — Day | Monday - Friday | Monday - Friday |
| Trading Hours — Summer | 06:00 – 03:30 WIB | 07:00 – 03:45 WIB |
| Trading Hours — Winter | 06:00 – 04:30 WIB | 08:00 – 03:45 WIB |
| Initial Margin — Day Trade | USD 100/lot | USD 100/lot |
| Facility Fee | USD 1.5/lot/side | USD 1.5/lot/side |
| V.A.T (Facility Fee) | 11% of Facility Fee | 11% of Facility Fee |
| Rollover Facility — Sell | USD 0.5/lot/night | USD 0.5/lot/night |
| Rollover Facility — Buy | USD 0.5/lot/night | USD 0.5/lot/night |
| V.A.T (Rollover Facility) | 11% of Rollover Facility | 11% of Rollover Facility |
| Price Source | Telequote | Telequote |
| Price Guidance | Last Trade | Last Trade |
| Minimum Price Spread Quote | USD 0.40/Troy Ounce/Side | USD 0.10 /pips/barrel/side |
| Maximum Price Spread Quote | USD 1.00/Troy Ounce/Side | USD 0.30 /pips/barrel/side |
| Hectic Price Spread Quote | Base On Market | Base On Market |
| Minimum Price Movement | USD 0.01 / Troy Ounce | USD 0.01 /barrel |
| Range For Limit & Stop Order | USD 6 – USD 20 | USD 1 – USD 20 |
| Hectic Range Price For Limit & Stop Order | Base On Market | Base On Market |
| Delivery By | Cash Settlement | Cash Settlement |

**Node turunan:** [[KB-Node-AkunMini-Spesifikasi-Gold-XUL10]], [[KB-Node-AkunMini-Spesifikasi-BrentOil-BCO10]], [[KB-Node-AkunMini-Initial-Margin]], [[KB-Node-AkunMini-Komisi-Transaksi]], [[KB-Node-AkunMini-StorageRolloverFee]], [[KB-Node-AkunMini-JamTrading]].

---
**Node terkait (navigasi KB):** [[KB-Node-JenisAkun-Mini-Overview]] · [[KB-Node-AkunMini-Margin-Equity-CallMargin]] · [[KB-Node-AkunMini-BiayaLainLain]]
