# COMPANY KB STARTER

Sumber utama awal: node `KB-Node-Profil-Perusahaan.md`, `KB-Node-Legalitas-Daftar-Izin.md`, `KB-Node-Legalitas-Lembaga-Pengawas.md`, `KB-Node-Sumber-Resmi-Kontak.md`, serta `DARVIS_NODE_SolidGroup.md`.

Aturan: gunakan setiap sumber sesuai cakupannya. Jangan menyimpulkan hubungan operasional antar entitas perusahaan hanya dari keterangan grup/governance. Untuk legalitas dan izin, tampilkan sumber dan tanggal dokumen; verifikasi ke kanal regulator resmi sebelum digunakan sebagai klaim publik.
