# PRODUCT FACTS MASTER — INITIAL
Status: Initial source-selected values; not a complete approved product master.

## Mini/Mikro — values selected by user from `Spesifikasi Mini Mikro.docx`
| Field | Gold XUL10 | Brent BCO10_BBJ |
|---|---:|---:|
| Contract size | 100 “Tray Once” (source spelling; verify terminology) | USD 1.000 per Barrel |
| Commission fee | USD 1/Lot | USD 1/Lot |
| Minimum spread | USD 0,20/Troy Once/Side (source spelling) | USD 0,10/pips/barrel/side |
| VAT commission | 11% | 11% |
| Currency | IDR 10.000 fixed rate | IDR 10.000 fixed rate |
| Quantity | 0,1–0,9 lot/trade | 0,1–0,9 lot/trade |
| Max net open position | 0,9 lot | 0,9 lot |
| Max equity | IDR 25.000.000 / USD 2.500 | IDR 25.000.000 / USD 2.500 |
| Margin new account Mini | IDR 5.000.000 / USD 500 | IDR 5.000.000 / USD 500 |
| Max warning equity | IDR 23.000.000 / USD 2.300 | IDR 23.000.000 / USD 2.300 |
| Initial margin daytrade | USD 100/lot | USD 100/lot |
| Call margin level | 70% equity | 70% equity |
| ABS level | 30% equity | 30% equity |

## Important
- Data di atas ditranskripsi dari dokumen sumber yang dipilih pengguna; bukan verifikasi bahwa dokumen masih merupakan product master aktif.
- Ejaan “Tray Once” dan “Troy Once” dipertahankan dari sumber. Jangan tampilkan sebagai istilah baku sebelum admin produk memvalidasi.
- Parameter lain pada dokumen sumber tersedia di dokumen asli dalam `source_documents/Spesifikasi Mini Mikro.docx`.
- Jangan mengisi produk/parameter Regular dari data Mini/Mikro.
- Untuk seluruh field yang belum terisi/terverifikasi, jawab `belum tersedia dalam Product Facts Master`.
