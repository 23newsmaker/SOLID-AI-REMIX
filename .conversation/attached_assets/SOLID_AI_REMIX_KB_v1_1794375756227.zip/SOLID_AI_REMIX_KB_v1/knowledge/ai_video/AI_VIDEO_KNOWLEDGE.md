# AI VIDEO KNOWLEDGE — INITIAL

## Tujuan
Mendukung workflow foto + prompt menjadi satu video vertikal 9:16 berdurasi target 10–15 detik.

## Prinsip kualitas
- Pertahankan identitas wajah dan ciri utama subjek foto.
- Gerakan harus sesuai prompt, tidak patah, tidak berubah bentuk secara ekstrem.
- Jangan mengklaim suatu model mampu menjaga identitas sebelum diuji.
- Simpan parameter model, versi, seed (jika tersedia), durasi, resolusi, waktu proses, dan biaya aktual.
- Satu permintaan menghasilkan satu video final pada MVP.

## Status pipeline identitas
`MULTI_CHARACTER_IDENTITY_PIPELINE.md` adalah proposal teknis eksperimental. Jangan jadikan pipeline produksi tanpa benchmark dan persetujuan teknis.

## Uji penerimaan minimum
1. Kemiripan wajah dengan foto sumber.
2. Stabilitas wajah sepanjang klip.
3. Kualitas tangan/tubuh dan gerakan.
4. Kesesuaian adegan dengan prompt.
5. Artefak visual dan flicker.
6. Waktu render dan biaya per video.
7. Konsistensi hasil pada beberapa foto dan prompt.

## Batas implementasi
Model/provider belum diputuskan. Aplikasi harus menggunakan adapter/provider abstraction agar GPU/API dapat diganti tanpa membangun ulang frontend. Jangan mengarang hasil video; bila provider belum terkonfigurasi, tampilkan status belum dikonfigurasi.
